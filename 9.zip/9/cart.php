<?php

session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>


<style>
  @media (max-width: 600px) {

    /*----- General Style -----*/
    
    .khan {
      margin-top: 10px;
      margin-left: -30px;
    }
    .khan1{
      margin-top: 10px;
    }
  }

  @media (max-width: 397px) {
    .khan{
      margin-left: 4px !important;
    }
  }
</style>
<!-- MAIN -->

<!-- Preloader Start -->
<div id="preloader" class="preloader">
  <div class="preloader-box">
    <img src="./m/images/preloader.svg" alt="preloader">
  </div>
</div>
<!-- Preloader End -->
<!-- Start Of Sub Banner -->
<section class="sub-banner bg-yellow overflow-h position-r">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-xl-6 col-lg-6 col-md-12">
        <div class="sub-banner-content wow fadeInLeft">
          <h1 class="sub-banner-title">Cart</h1>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
        </div>
      </div>

      <div class="col-xl-6 col-lg-6 col-md-12">
        <div class="bread-crumb wow fadeInRight">
          <ul>
            <li><a href="index.html">Home</a></li>
            <li>Cart</li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <div class="black-jamun wow fadeInLeft animation-delay-5">
    <img src="./m/images/black-jamun.png" alt="black-jamun">
  </div>

  <div class="onion-img wow fadeInUp animation-delay-6">
    <img src="./m/images/onion.png" alt="onion">
  </div>

  <div class="tamato-img wow fadeInUp animation-delay-7">
    <img src="./m/images/tamato.png" alt="tamato">
  </div>

  <div class="leaf-img wow fadeInRight animation-delay-8">
    <img src="./admin_area/product_images/book-leaf.png" alt="banner-leaf">
  </div>
</section>
<!-- End Of Sub Banner -->

<div id="content"><!-- content Starts -->
  <div class="container"><!-- container Starts -->



    <div class="col-md-9" id="cart"><!-- col-md-9 Starts -->

      <div class="box"><!-- box Starts -->

        <form action="cart.php" method="post" enctype="multipart-form-data"><!-- form Starts -->


          <?php

          $ip_add = getRealUserIp();

          $select_cart = "select * from cart where ip_add='$ip_add'";

          $run_cart = mysqli_query($con, $select_cart);

          $count = mysqli_num_rows($run_cart);

          ?>


          <div class="table-responsive" style="margin-top: 0px;"><!-- table-responsive Starts -->

            <table class="table"><!-- table Starts -->

              <thead><!-- thead Starts -->

                <tr>

                  <th colspan="2">Product</th>

                  <th>Quantity</th>

                  <th>Price</th>

                  <th>Size</th>

                  <th colspan="1">Delete</th>

                  <th colspan="2"> Total </th>


                </tr>

              </thead><!-- thead Ends -->

              <tbody><!-- tbody Starts -->

                <?php

                $total = 0;

                while ($row_cart = mysqli_fetch_array($run_cart)) {

                  $pro_id = $row_cart['p_id'];

                  $pro_size = $row_cart['size'];

                  $pro_qty = $row_cart['qty'];

                  $only_price = $row_cart['p_price'];

                  $get_products = "select * from products where product_id='$pro_id'";

                  $run_products = mysqli_query($con, $get_products);

                  while ($row_products = mysqli_fetch_array($run_products)) {

                    $product_title = $row_products['product_title'];

                    $product_img1 = $row_products['product_img1'];

                    $sub_total = $only_price * $pro_qty;

                    $_SESSION['pro_qty'] = $pro_qty;

                    $total += $sub_total;

                ?>


                    <section class="cart ptb-150"></section>
                    <tr><!-- tr Starts -->

                      <td>

                        <img src="admin_area/product_images/<?php echo $product_img1; ?>">

                      </td>

                      <td>

                        <a href="#"> <?php echo $product_title; ?> </a>

                      </td>

                      <td>
                        <input type="number" name="quantity" value="<?php echo $_SESSION['pro_qty']; ?>" data-product_id="<?php echo $pro_id; ?>" class="quantity form-control">
                      </td>

                      <td>

                        $<?php echo $only_price; ?>.00

                      </td>

                      <td>

                        <?php echo $pro_size; ?>

                      </td>

                      <td>
                        <input type="checkbox" name="remove[]" value="<?php echo $pro_id; ?>">
                      </td>

                      <td>

                        $<?php echo $sub_total; ?>.00

                      </td>

                    </tr><!-- tr Ends -->

                <?php }
                } ?>

              </tbody><!-- tbody Ends -->

              <tfoot><!-- tfoot Starts -->

                <tr>

                  <th colspan="5"> Total </th>

                  <th colspan="2"> $<?php echo $total; ?>.00 </th>

                </tr>

              </tfoot><!-- tfoot Ends -->

            </table><!-- table Ends -->


            <div class="row align-items-center"><!-- form-inline pull-right Starts -->

              <div class="col-xl-7 col-lg-7 col-md-7"><!-- form-group Starts -->
                <div class="apply-coupon">
                  <!-- <form class="position-r">

<input type="text" name="code" class="form-control">
<button class="btn-ct btn-small" type="submit" name="apply_coupon">Apply Coupon</button>

</form> -->
                </div><!-- form-group Ends -->
              </div>

            </div><!-- form-inline pull-right Ends -->

          </div><!-- table-responsive Ends -->


          <div class="box-footer"><!-- box-footer Starts -->

            <div class="pull-left"><!-- pull-left Starts -->

              <a href="index.php">

                <i class=" btn-ct btn-small">Continue Shopping</i>

              </a>

            </div><!-- pull-left Ends -->

            <div class="pull-right"><!-- pull-right Starts -->

              <button class=" btn-ct btn-small khan" type="submit" name="update" value="Update Cart">

                <i class="fa fa-refresh"></i> Update Cart

              </button>

              <a href="checkout.php" class=" btn-ct btn-small khan1">

                Proceed to Checkout <i class="fa fa-chevron-right"></i>

              </a>

            </div><!-- pull-right Ends -->

          </div><!-- box-footer Ends -->

        </form><!-- form Ends -->


      </div><!-- box Ends -->

      <?php

      if (isset($_POST['apply_coupon'])) {

        $code = $_POST['code'];

        if ($code == "") {
        } else {

          $get_coupons = "select * from coupons where coupon_code='$code'";

          $run_coupons = mysqli_query($con, $get_coupons);

          $check_coupons = mysqli_num_rows($run_coupons);

          if ($check_coupons == 1) {

            $row_coupons = mysqli_fetch_array($run_coupons);

            $coupon_pro = $row_coupons['product_id'];

            $coupon_price = $row_coupons['coupon_price'];

            $coupon_limit = $row_coupons['coupon_limit'];

            $coupon_used = $row_coupons['coupon_used'];


            if ($coupon_limit == $coupon_used) {

              echo "<script>alert('Your Coupon Code Has Been Expired')</script>";
            } else {

              $get_cart = "select * from cart where p_id='$coupon_pro' AND ip_add='$ip_add'";

              $run_cart = mysqli_query($con, $get_cart);

              $check_cart = mysqli_num_rows($run_cart);


              if ($check_cart == 1) {

                $add_used = "update coupons set coupon_used=coupon_used+1 where coupon_code='$code'";

                $run_used = mysqli_query($con, $add_used);

                $update_cart = "update cart set p_price='$coupon_price' where p_id='$coupon_pro' AND ip_add='$ip_add'";

                $run_update = mysqli_query($con, $update_cart);

                echo "<script>alert('Your Coupon Code Has Been Applied')</script>";

                echo "<script>window.open('cart.php','_self')</script>";
              } else {

                echo "<script>alert('Product Does Not Exist In Cart')</script>";
              }
            }
          } else {

            echo "<script> alert('Your Coupon Code Is Not Valid') </script>";
          }
        }
      }


      ?>

      <?php

      function update_cart()
      {

        global $con;

        if (isset($_POST['update'])) {

          foreach ($_POST['remove'] as $remove_id) {


            $delete_product = "delete from cart where p_id='$remove_id'";

            $run_delete = mysqli_query($con, $delete_product);

            if ($run_delete) {
              echo "<script>window.open('cart.php','_self')</script>";
            }
          }
        }
      }

      echo @$up_cart = update_cart();



      ?>



      <div id="row same-height-row"><!-- row same-height-row Starts -->

        <div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Starts -->

          <div class="box same-height headline"><!-- box same-height headline Starts -->

            <h3 class="text-center" style="color:transparent;"> You may like these Products </h3>

          </div><!-- box same-height headline Ends -->

        </div><!-- col-md-3 col-sm-6 Ends -->

        <?php

        $get_products = "select * from products order by rand() LIMIT 0,3";

        $run_products = mysqli_query($con, $get_products);

        while ($row_products = mysqli_fetch_array($run_products)) {


          $get_manufacturer = "select * from manufacturers where manufacturer_id='$manufacturer_id'";

          $run_manufacturer = mysqli_query($db, $get_manufacturer);

          $row_manufacturer = mysqli_fetch_array($run_manufacturer);




          if ($pro_label == "") {
          } else {

            $product_label = "


<div class=''></div>



";
          }


          echo "

<div class='' >

<div class='' >

<a href='' >


</a>

<div class='' >




<h3><a href='' ></a></h3>


<p class='buttons' >


<a href='' class='r'>


</a>


</p>

</div>



</div>

</div>

";
        }




        ?>


      </div><!-- row same-height-row Ends -->


    </div><!-- col-md-9 Ends -->
  </div><!-- col-md-9 Ends -->



  <script src="js/jquery.min.js"> </script>

  <script src="js/bootstrap.min.js"></script>

  <script>
    $(document).ready(function(data) {

      $(document).on('keyup', '.quantity', function() {

        var id = $(this).data("product_id");

        var quantity = $(this).val();

        if (quantity != '') {

          $.ajax({

            url: "change.php",

            method: "POST",

            data: {
              id: id,
              quantity: quantity
            },

            success: function(data) {

              $("body").load('cart_body.php');

            }




          });


        }




      });




    });
  </script>
  <?php

  include("includes/footer.php");

  ?>
  </body>

  </html>