<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=<div data-elementor-type=" wp-page" data-elementor-id="111" class="elementor elementor-111">
    <section class="elementor-section elementor-top-section elementor-element elementor-element-050ade7 tmpcoder-custom-section-position-unset elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no" data-id="050ade7" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
        <div class="elementor-container elementor-column-gap-default">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6ccb0e4 tmpcoder-custom-column-position-unset" data-id="6ccb0e4" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
                <div class="elementor-widget-wrap elementor-element-populated">
                    <section class="elementor-section elementor-inner-section elementor-element elementor-element-55a1447 elementor-section-content-middle tmpcoder-custom-section-position-unset elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no" data-id="55a1447" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-a8920b2 tmpcoder-custom-column-position-unset" data-id="a8920b2" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div class="elementor-element elementor-element-2f3137a elementor-widget elementor-widget-tmpcoder-page-title animated fadeInLeft" data-id="2f3137a" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInLeft&quot;}" data-widget_type="tmpcoder-page-title.default">
                                        <div class="elementor-widget-container">
                                            <h1 class="tmpcoder-post-title">Cart</h1>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-1a91d53 elementor-widget__width-initial elementor-widget elementor-widget-text-editor animated fadeInLeft" data-id="1a91d53" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInLeft&quot;}" data-widget_type="text-editor.default">
                                        <div class="elementor-widget-container">
                                            <style>
                                                /*! elementor - v3.19.0 - 28-02-2024 */
                                                .elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap {
                                                    background-color: #69727d;
                                                    color: #fff
                                                }

                                                .elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap {
                                                    color: #69727d;
                                                    border: 3px solid;
                                                    background-color: transparent
                                                }

                                                .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap {
                                                    margin-top: 8px
                                                }

                                                .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter {
                                                    width: 1em;
                                                    height: 1em
                                                }

                                                .elementor-widget-text-editor .elementor-drop-cap {
                                                    float: left;
                                                    text-align: center;
                                                    line-height: 1;
                                                    font-size: 50px
                                                }

                                                .elementor-widget-text-editor .elementor-drop-cap-letter {
                                                    display: inline-block
                                                }
                                            </style> Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-40cefce tmpcoder-custom-column-position-unset" data-id="40cefce" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div class="elementor-element elementor-element-60a78e7 elementor-widget elementor-widget-Breadcrumb animated fadeInRight" data-id="60a78e7" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="Breadcrumb.default">
                                        <div class="elementor-widget-container">

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="page-banner">

                                                        <h2 class="sub-banner-title notshow">Cart</h2>
                                                        <nav class="woocommerce-breadcrumb" aria-label="Breadcrumb"><span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02">Home</a></span> / <span>Cart</span></nav>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section class="elementor-section elementor-inner-section elementor-element elementor-element-f41631a elementor-section-content-middle tmpcoder-custom-section-position-unset elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no" data-id="f41631a" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-8c83443 tmpcoder-custom-column-position-unset" data-id="8c83443" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div class="elementor-element elementor-element-a90e3fa elementor-widget__width-initial elementor-absolute elementor-widget-tablet__width-initial elementor-widget elementor-widget-image animated fadeInRight" data-id="a90e3fa" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;fadeInRight&quot;,&quot;_animation_delay&quot;:0.5}" data-widget_type="image.default">
                                        <div class="elementor-widget-container">
                                            <style>
                                                /*! elementor - v3.19.0 - 28-02-2024 */
                                                .elementor-widget-image {
                                                    text-align: center
                                                }

                                                .elementor-widget-image a {
                                                    display: inline-block
                                                }

                                                .elementor-widget-image a img[src$=".svg"] {
                                                    width: 48px
                                                }

                                                .elementor-widget-image img {
                                                    vertical-align: middle;
                                                    display: inline-block
                                                }
                                            </style> <img loading="lazy" decoding="async" width="112" height="115" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion.png" class="attachment-full size-full wp-image-88" alt="">
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-79a5f6b elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-image animated fadeInUp" data-id="79a5f6b" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:1}" data-widget_type="image.default">
                                        <div class="elementor-widget-container">
                                            <img loading="lazy" decoding="async" width="97" height="99" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/tamato.png" class="attachment-full size-full wp-image-102" alt="">
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-c26f222 elementor-widget__width-initial elementor-absolute black-jam-img elementor-widget elementor-widget-image animated fadeInLeft" data-id="c26f222" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;fadeInLeft&quot;,&quot;_animation_delay&quot;:2}" data-widget_type="image.default">
                                        <div class="elementor-widget-container">
                                            <img loading="lazy" decoding="async" width="153" height="277" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/black-jamun.png" class="attachment-full size-full wp-image-87" alt="">
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-642a63b elementor-widget__width-initial elementor-absolute elementor-widget elementor-widget-image animated fadeInRight" data-id="642a63b" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;fadeInRight&quot;,&quot;_animation_delay&quot;:1.5}" data-widget_type="image.default">
                                        <div class="elementor-widget-container">
                                            <img loading="lazy" decoding="async" width="119" height="204" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/banner-leaf.png" class="attachment-full size-full wp-image-1576" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </section>
    <section class="elementor-section elementor-top-section elementor-element elementor-element-14d5aa35 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no" data-id="14d5aa35" data-element_type="section">
        <div class="elementor-container elementor-column-gap-default">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-37832326" data-id="37832326" data-element_type="column">
                <div class="elementor-widget-wrap elementor-element-populated">
                    <div class="elementor-element elementor-element-6d3f4795 elementor-widget elementor-widget-text-editor" data-id="6d3f4795" data-element_type="widget" data-widget_type="text-editor.default">
                        <div class="elementor-widget-container">
                            <!-- wp:shortcode -->
                            <div class="woocommerce">
                                <div class="woocommerce-notices-wrapper"></div>
                                <form class="woocommerce-cart-form" action="https://themes.templatescoder.com/pizzon/wp/demo-02/cart/" method="post">

                                    <table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th class="product-remove"><span class="screen-reader-text">Remove item</span></th>
                                                <th class="product-thumbnail"><span class="screen-reader-text">Thumbnail image</span></th>
                                                <th class="product-name">Product</th>
                                                <th class="product-price">Price</th>
                                                <th class="product-quantity">Quantity</th>
                                                <th class="product-subtotal">Subtotal</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <tr class="woocommerce-cart-form__cart-item cart_item">

                                                <td class="product-remove">
                                                    <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/cart/?remove_item=68a9750337a418a86fe06c1991a1d64c&amp;_wpnonce=a4338d7ab3" class="remove" aria-label="Remove French mayos from cart" data-product_id="3193" data-product_sku="">×</a>
                                                </td>

                                                <td class="product-thumbnail">
                                                    <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product/french-mayos/"><img loading="lazy" decoding="async" width="300" height="300" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french-300x300.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french-300x300.jpg 300w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french-150x150.jpg 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french-100x100.jpg 100w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french.jpg 513w" sizes="(max-width: 300px) 100vw, 300px"></a>
                                                </td>

                                                <td class="product-name" data-title="Product">
                                                    <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product/french-mayos/">French mayos</a>
                                                </td>

                                                <td class="product-price" data-title="Price">
                                                    <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span>65.00</bdi></span>
                                                </td>

                                                <td class="product-quantity" data-title="Quantity">
                                                    <div class="quantity">
                                                        <i class="fas fa-minus minus"></i> <label class="screen-reader-text" for="quantity_66617fa56130e">French mayos quantity</label>
                                                        <input type="number" id="quantity_66617fa56130e" class="input-text qty text" name="cart[68a9750337a418a86fe06c1991a1d64c][qty]" value="1" aria-label="Product quantity" size="4" min="0" max="" step="1" placeholder="" inputmode="numeric" autocomplete="off">
                                                        <i class="fas fa-plus plus"></i>
                                                    </div>
                                                </td>

                                                <td class="product-subtotal" data-title="Subtotal">
                                                    <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span>65.00</bdi></span>
                                                </td>
                                            </tr>
                                            <tr class="woocommerce-cart-form__cart-item cart_item">

                                                <td class="product-remove">
                                                    <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/cart/?remove_item=6c4bb406b3e7cd5447f7a76fd7008806&amp;_wpnonce=a4338d7ab3" class="remove" aria-label="Remove Seafood burger from cart" data-product_id="3196" data-product_sku="">×</a>
                                                </td>

                                                <td class="product-thumbnail">
                                                    <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product/seafood-burger/"><img loading="lazy" decoding="async" width="300" height="300" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/burger-300x300.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/burger-300x300.jpg 300w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/burger-150x150.jpg 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/burger-100x100.jpg 100w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/burger.jpg 513w" sizes="(max-width: 300px) 100vw, 300px"></a>
                                                </td>

                                                <td class="product-name" data-title="Product">
                                                    <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product/seafood-burger/">Seafood burger</a>
                                                </td>

                                                <td class="product-price" data-title="Price">
                                                    <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span>75.00</bdi></span>
                                                </td>

                                                <td class="product-quantity" data-title="Quantity">
                                                    <div class="quantity">
                                                        <i class="fas fa-minus minus"></i> <label class="screen-reader-text" for="quantity_66617fa5615bf">Seafood burger quantity</label>
                                                        <input type="number" id="quantity_66617fa5615bf" class="input-text qty text" name="cart[6c4bb406b3e7cd5447f7a76fd7008806][qty]" value="16" aria-label="Product quantity" size="4" min="0" max="" step="1" placeholder="" inputmode="numeric" autocomplete="off">
                                                        <i class="fas fa-plus plus"></i>
                                                    </div>
                                                </td>

                                                <td class="product-subtotal" data-title="Subtotal">
                                                    <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span>1,200.00</bdi></span>
                                                </td>
                                            </tr>


                                            <tr>
                                                <td colspan="6" class="actions">

                                                    <div class="coupon">
                                                        <label for="coupon_code" class="screen-reader-text">Coupon:</label> <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="Coupon code"> <button type="submit" class="button" name="apply_coupon" value="Apply coupon">Apply coupon</button>
                                                    </div>

                                                    <button type="submit" class="button" name="update_cart" value="Update cart" disabled="">Update cart</button>


                                                    <input type="hidden" id="woocommerce-cart-nonce" name="woocommerce-cart-nonce" value="a4338d7ab3"><input type="hidden" name="_wp_http_referer" value="/pizzon/wp/demo-02/cart/">
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </form>


                                <div class="cart-collaterals">
                                    <div class="cart_totals calculated_shipping">


                                        <h2>Cart totals</h2>

                                        <table cellspacing="0" class="shop_table shop_table_responsive">

                                            <tbody>
                                                <tr class="cart-subtotal">
                                                    <th>Subtotal</th>
                                                    <td data-title="Subtotal"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span>1,265.00</bdi></span></td>
                                                </tr>




                                                <tr class="woocommerce-shipping-totals shipping">
                                                    <th>Shipping</th>
                                                    <td data-title="Shipping">
                                                        <ul id="shipping_method" class="woocommerce-shipping-methods">
                                                        </ul>
                                                        <p class="woocommerce-shipping-destination">
                                                            Shipping to <strong>m block, apartment, Arifwale, Islamabad Capital Territory, 90788, Pakistan</strong>. </p>



                                                        <form class="woocommerce-shipping-calculator" action="https://themes.templatescoder.com/pizzon/wp/demo-02/cart/" method="post">

                                                            <a href="#" class="shipping-calculator-button">Change address</a>
                                                            <section class="shipping-calculator-form" style="display:none;">

                                                                <p class="form-row form-row-wide" id="calc_shipping_country_field">
                                                                    <label for="calc_shipping_country" class="screen-reader-text">Country / region:</label>
                                                                    <select name="calc_shipping_country" id="calc_shipping_country" class="country_to_state country_select" rel="calc_shipping_state">
                                                                        <option value="default">Select a country / region…</option>
                                                                        <option value="AF">Afghanistan</option>
                                                                        <option value="AX">Åland Islands</option>
                                                                        <option value="AL">Albania</option>
                                                                        <option value="DZ">Algeria</option>
                                                                        <option value="AS">American Samoa</option>
                                                                        <option value="AD">Andorra</option>
                                                                        <option value="AO">Angola</option>
                                                                        <option value="AI">Anguilla</option>
                                                                        <option value="AQ">Antarctica</option>
                                                                        <option value="AG">Antigua and Barbuda</option>
                                                                        <option value="AR">Argentina</option>
                                                                        <option value="AM">Armenia</option>
                                                                        <option value="AW">Aruba</option>
                                                                        <option value="AU">Australia</option>
                                                                        <option value="AT">Austria</option>
                                                                        <option value="AZ">Azerbaijan</option>
                                                                        <option value="BS">Bahamas</option>
                                                                        <option value="BH">Bahrain</option>
                                                                        <option value="BD">Bangladesh</option>
                                                                        <option value="BB">Barbados</option>
                                                                        <option value="BY">Belarus</option>
                                                                        <option value="PW">Belau</option>
                                                                        <option value="BE">Belgium</option>
                                                                        <option value="BZ">Belize</option>
                                                                        <option value="BJ">Benin</option>
                                                                        <option value="BM">Bermuda</option>
                                                                        <option value="BT">Bhutan</option>
                                                                        <option value="BO">Bolivia</option>
                                                                        <option value="BQ">Bonaire, Saint Eustatius and Saba</option>
                                                                        <option value="BA">Bosnia and Herzegovina</option>
                                                                        <option value="BW">Botswana</option>
                                                                        <option value="BV">Bouvet Island</option>
                                                                        <option value="BR">Brazil</option>
                                                                        <option value="IO">British Indian Ocean Territory</option>
                                                                        <option value="BN">Brunei</option>
                                                                        <option value="BG">Bulgaria</option>
                                                                        <option value="BF">Burkina Faso</option>
                                                                        <option value="BI">Burundi</option>
                                                                        <option value="KH">Cambodia</option>
                                                                        <option value="CM">Cameroon</option>
                                                                        <option value="CA">Canada</option>
                                                                        <option value="CV">Cape Verde</option>
                                                                        <option value="KY">Cayman Islands</option>
                                                                        <option value="CF">Central African Republic</option>
                                                                        <option value="TD">Chad</option>
                                                                        <option value="CL">Chile</option>
                                                                        <option value="CN">China</option>
                                                                        <option value="CX">Christmas Island</option>
                                                                        <option value="CC">Cocos (Keeling) Islands</option>
                                                                        <option value="CO">Colombia</option>
                                                                        <option value="KM">Comoros</option>
                                                                        <option value="CG">Congo (Brazzaville)</option>
                                                                        <option value="CD">Congo (Kinshasa)</option>
                                                                        <option value="CK">Cook Islands</option>
                                                                        <option value="CR">Costa Rica</option>
                                                                        <option value="HR">Croatia</option>
                                                                        <option value="CU">Cuba</option>
                                                                        <option value="CW">Curaçao</option>
                                                                        <option value="CY">Cyprus</option>
                                                                        <option value="CZ">Czech Republic</option>
                                                                        <option value="DK">Denmark</option>
                                                                        <option value="DJ">Djibouti</option>
                                                                        <option value="DM">Dominica</option>
                                                                        <option value="DO">Dominican Republic</option>
                                                                        <option value="EC">Ecuador</option>
                                                                        <option value="EG">Egypt</option>
                                                                        <option value="SV">El Salvador</option>
                                                                        <option value="GQ">Equatorial Guinea</option>
                                                                        <option value="ER">Eritrea</option>
                                                                        <option value="EE">Estonia</option>
                                                                        <option value="SZ">Eswatini</option>
                                                                        <option value="ET">Ethiopia</option>
                                                                        <option value="FK">Falkland Islands</option>
                                                                        <option value="FO">Faroe Islands</option>
                                                                        <option value="FJ">Fiji</option>
                                                                        <option value="FI">Finland</option>
                                                                        <option value="FR">France</option>
                                                                        <option value="GF">French Guiana</option>
                                                                        <option value="PF">French Polynesia</option>
                                                                        <option value="TF">French Southern Territories</option>
                                                                        <option value="GA">Gabon</option>
                                                                        <option value="GM">Gambia</option>
                                                                        <option value="GE">Georgia</option>
                                                                        <option value="DE">Germany</option>
                                                                        <option value="GH">Ghana</option>
                                                                        <option value="GI">Gibraltar</option>
                                                                        <option value="GR">Greece</option>
                                                                        <option value="GL">Greenland</option>
                                                                        <option value="GD">Grenada</option>
                                                                        <option value="GP">Guadeloupe</option>
                                                                        <option value="GU">Guam</option>
                                                                        <option value="GT">Guatemala</option>
                                                                        <option value="GG">Guernsey</option>
                                                                        <option value="GN">Guinea</option>
                                                                        <option value="GW">Guinea-Bissau</option>
                                                                        <option value="GY">Guyana</option>
                                                                        <option value="HT">Haiti</option>
                                                                        <option value="HM">Heard Island and McDonald Islands</option>
                                                                        <option value="HN">Honduras</option>
                                                                        <option value="HK">Hong Kong</option>
                                                                        <option value="HU">Hungary</option>
                                                                        <option value="IS">Iceland</option>
                                                                        <option value="IN">India</option>
                                                                        <option value="ID">Indonesia</option>
                                                                        <option value="IR">Iran</option>
                                                                        <option value="IQ">Iraq</option>
                                                                        <option value="IE">Ireland</option>
                                                                        <option value="IM">Isle of Man</option>
                                                                        <option value="IL">Israel</option>
                                                                        <option value="IT">Italy</option>
                                                                        <option value="CI">Ivory Coast</option>
                                                                        <option value="JM">Jamaica</option>
                                                                        <option value="JP">Japan</option>
                                                                        <option value="JE">Jersey</option>
                                                                        <option value="JO">Jordan</option>
                                                                        <option value="KZ">Kazakhstan</option>
                                                                        <option value="KE">Kenya</option>
                                                                        <option value="KI">Kiribati</option>
                                                                        <option value="KW">Kuwait</option>
                                                                        <option value="KG">Kyrgyzstan</option>
                                                                        <option value="LA">Laos</option>
                                                                        <option value="LV">Latvia</option>
                                                                        <option value="LB">Lebanon</option>
                                                                        <option value="LS">Lesotho</option>
                                                                        <option value="LR">Liberia</option>
                                                                        <option value="LY">Libya</option>
                                                                        <option value="LI">Liechtenstein</option>
                                                                        <option value="LT">Lithuania</option>
                                                                        <option value="LU">Luxembourg</option>
                                                                        <option value="MO">Macao</option>
                                                                        <option value="MG">Madagascar</option>
                                                                        <option value="MW">Malawi</option>
                                                                        <option value="MY">Malaysia</option>
                                                                        <option value="MV">Maldives</option>
                                                                        <option value="ML">Mali</option>
                                                                        <option value="MT">Malta</option>
                                                                        <option value="MH">Marshall Islands</option>
                                                                        <option value="MQ">Martinique</option>
                                                                        <option value="MR">Mauritania</option>
                                                                        <option value="MU">Mauritius</option>
                                                                        <option value="YT">Mayotte</option>
                                                                        <option value="MX">Mexico</option>
                                                                        <option value="FM">Micronesia</option>
                                                                        <option value="MD">Moldova</option>
                                                                        <option value="MC">Monaco</option>
                                                                        <option value="MN">Mongolia</option>
                                                                        <option value="ME">Montenegro</option>
                                                                        <option value="MS">Montserrat</option>
                                                                        <option value="MA">Morocco</option>
                                                                        <option value="MZ">Mozambique</option>
                                                                        <option value="MM">Myanmar</option>
                                                                        <option value="NA">Namibia</option>
                                                                        <option value="NR">Nauru</option>
                                                                        <option value="NP">Nepal</option>
                                                                        <option value="NL">Netherlands</option>
                                                                        <option value="NC">New Caledonia</option>
                                                                        <option value="NZ">New Zealand</option>
                                                                        <option value="NI">Nicaragua</option>
                                                                        <option value="NE">Niger</option>
                                                                        <option value="NG">Nigeria</option>
                                                                        <option value="NU">Niue</option>
                                                                        <option value="NF">Norfolk Island</option>
                                                                        <option value="KP">North Korea</option>
                                                                        <option value="MK">North Macedonia</option>
                                                                        <option value="MP">Northern Mariana Islands</option>
                                                                        <option value="NO">Norway</option>
                                                                        <option value="OM">Oman</option>
                                                                        <option value="PK" selected="selected">Pakistan</option>
                                                                        <option value="PS">Palestinian Territory</option>
                                                                        <option value="PA">Panama</option>
                                                                        <option value="PG">Papua New Guinea</option>
                                                                        <option value="PY">Paraguay</option>
                                                                        <option value="PE">Peru</option>
                                                                        <option value="PH">Philippines</option>
                                                                        <option value="PN">Pitcairn</option>
                                                                        <option value="PL">Poland</option>
                                                                        <option value="PT">Portugal</option>
                                                                        <option value="PR">Puerto Rico</option>
                                                                        <option value="QA">Qatar</option>
                                                                        <option value="RE">Reunion</option>
                                                                        <option value="RO">Romania</option>
                                                                        <option value="RU">Russia</option>
                                                                        <option value="RW">Rwanda</option>
                                                                        <option value="ST">São Tomé and Príncipe</option>
                                                                        <option value="BL">Saint Barthélemy</option>
                                                                        <option value="SH">Saint Helena</option>
                                                                        <option value="KN">Saint Kitts and Nevis</option>
                                                                        <option value="LC">Saint Lucia</option>
                                                                        <option value="SX">Saint Martin (Dutch part)</option>
                                                                        <option value="MF">Saint Martin (French part)</option>
                                                                        <option value="PM">Saint Pierre and Miquelon</option>
                                                                        <option value="VC">Saint Vincent and the Grenadines</option>
                                                                        <option value="WS">Samoa</option>
                                                                        <option value="SM">San Marino</option>
                                                                        <option value="SA">Saudi Arabia</option>
                                                                        <option value="SN">Senegal</option>
                                                                        <option value="RS">Serbia</option>
                                                                        <option value="SC">Seychelles</option>
                                                                        <option value="SL">Sierra Leone</option>
                                                                        <option value="SG">Singapore</option>
                                                                        <option value="SK">Slovakia</option>
                                                                        <option value="SI">Slovenia</option>
                                                                        <option value="SB">Solomon Islands</option>
                                                                        <option value="SO">Somalia</option>
                                                                        <option value="ZA">South Africa</option>
                                                                        <option value="GS">South Georgia/Sandwich Islands</option>
                                                                        <option value="KR">South Korea</option>
                                                                        <option value="SS">South Sudan</option>
                                                                        <option value="ES">Spain</option>
                                                                        <option value="LK">Sri Lanka</option>
                                                                        <option value="SD">Sudan</option>
                                                                        <option value="SR">Suriname</option>
                                                                        <option value="SJ">Svalbard and Jan Mayen</option>
                                                                        <option value="SE">Sweden</option>
                                                                        <option value="CH">Switzerland</option>
                                                                        <option value="SY">Syria</option>
                                                                        <option value="TW">Taiwan</option>
                                                                        <option value="TJ">Tajikistan</option>
                                                                        <option value="TZ">Tanzania</option>
                                                                        <option value="TH">Thailand</option>
                                                                        <option value="TL">Timor-Leste</option>
                                                                        <option value="TG">Togo</option>
                                                                        <option value="TK">Tokelau</option>
                                                                        <option value="TO">Tonga</option>
                                                                        <option value="TT">Trinidad and Tobago</option>
                                                                        <option value="TN">Tunisia</option>
                                                                        <option value="TR">Turkey</option>
                                                                        <option value="TM">Turkmenistan</option>
                                                                        <option value="TC">Turks and Caicos Islands</option>
                                                                        <option value="TV">Tuvalu</option>
                                                                        <option value="UG">Uganda</option>
                                                                        <option value="UA">Ukraine</option>
                                                                        <option value="AE">United Arab Emirates</option>
                                                                        <option value="GB">United Kingdom (UK)</option>
                                                                        <option value="US">United States (US)</option>
                                                                        <option value="UM">United States (US) Minor Outlying Islands</option>
                                                                        <option value="UY">Uruguay</option>
                                                                        <option value="UZ">Uzbekistan</option>
                                                                        <option value="VU">Vanuatu</option>
                                                                        <option value="VA">Vatican</option>
                                                                        <option value="VE">Venezuela</option>
                                                                        <option value="VN">Vietnam</option>
                                                                        <option value="VG">Virgin Islands (British)</option>
                                                                        <option value="VI">Virgin Islands (US)</option>
                                                                        <option value="WF">Wallis and Futuna</option>
                                                                        <option value="EH">Western Sahara</option>
                                                                        <option value="YE">Yemen</option>
                                                                        <option value="ZM">Zambia</option>
                                                                        <option value="ZW">Zimbabwe</option>
                                                                    </select>
                                                                </p>

                                                                <p class="form-row validate-required form-row-wide address-field" id="calc_shipping_state_field">
                                                                    <span>
                                                                        <label for="calc_shipping_state" class="screen-reader-text">State / County&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                        <select name="calc_shipping_state" class="state_select" id="calc_shipping_state" data-placeholder="State / County">
                                                                            <option value="">Select an option…</option>
                                                                            <option value="JK">Azad Kashmir</option>
                                                                            <option value="BA">Balochistan</option>
                                                                            <option value="TA">FATA</option>
                                                                            <option value="GB">Gilgit Baltistan</option>
                                                                            <option value="IS">Islamabad Capital Territory</option>
                                                                            <option value="KP">Khyber Pakhtunkhwa</option>
                                                                            <option value="PB">Punjab</option>
                                                                            <option value="SD">Sindh</option>
                                                                        </select>
                                                                    </span>
                                                                </p>

                                                                <p class="form-row validate-required form-row-wide address-field" id="calc_shipping_city_field">
                                                                    <label for="calc_shipping_city" class="screen-reader-text">Town / City&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                    <input type="text" class="input-text" value="Arifwale" placeholder="City" name="calc_shipping_city" id="calc_shipping_city">
                                                                </p>

                                                                <p class="form-row validate-required form-row-wide address-field" id="calc_shipping_postcode_field">
                                                                    <label for="calc_shipping_postcode" class="screen-reader-text">Postcode / ZIP&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                    <input type="text" class="input-text" value="90788" placeholder="Postcode / ZIP" name="calc_shipping_postcode" id="calc_shipping_postcode">
                                                                </p>

                                                                <p><button type="submit" name="calc_shipping" value="1" class="button">Update</button></p>
                                                                <input type="hidden" id="woocommerce-shipping-calculator-nonce" name="woocommerce-shipping-calculator-nonce" value="19bbea0f0b"><input type="hidden" name="_wp_http_referer" value="/pizzon/wp/demo-02/cart/">
                                                            </section>
                                                        </form>

                                                    </td>
                                                </tr>






                                                <tr class="order-total">
                                                    <th>Total</th>
                                                    <td data-title="Total"><strong><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span>1,265.00</bdi></span></strong> </td>
                                                </tr>


                                            </tbody>
                                        </table>

                                        <div class="wc-proceed-to-checkout">

                                            <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/checkout/" class="checkout-button button alt wc-forward">
                                                Proceed to checkout</a>
                                        </div>


                                    </div>
                                </div>

                            </div><!-- /wp:shortcode -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

</body>

</html>