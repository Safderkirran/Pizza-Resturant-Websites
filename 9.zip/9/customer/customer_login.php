<style>
	@media (max-width: 841px) {
		h1 {
			color: red;
		}

		.ki {
			width: 100%;
			margin-top: 10px;

		}

		.sa {
			position: relative;
			left: 2px !important;
			width: 98%;
		}
	}
</style>
<?php
session_start();

include("./includes/db.php");
include("includes/header.php");
include("./functions/");
include("./includes/main.php");

?>

<div class="box"><!-- box Starts -->
	<div class="section-heading section-heading-left wow fadeInLeft"><!-- box-header Starts -->
		<h5 class="sub-title">Consultation</h5>

		<h1>Login</h1>
	</div>

</div><!-- box-header Ends -->
<form action="checkout.php" method="post"><!--form Starts -->
	<div class="form-group"><!-- form-group Starts -->

		<input type="text" class="form-control" name="c_email" required placeholder="Email">

	</div><!-- form-group Ends -->

	<div class="form-group"><!-- form-group Starts -->


		<input type="password" class="form-control" name="c_pass" required placeholder="password">




		<a href="forgot_pass.php" style="font-size: 13px; margin-top: 10px; margin-left: 11px;"> Forgot Password ?</a>


	</div><!-- form-group Ends -->

	<center><!-- center Starts -->

		<a class="form-button" href="customer_register.php">

			<h3 class="btn-ct ki " style="position: relative; top:-40px !important;">New Register </h3>

		</a>


	</center><!-- center Ends -->

	<div class=" form-button"><!-- text-center Starts -->

		<button name="login" value="Login" class="btn-ct sa" style="position: relative; left:45%; margin-bottom: 20px;">

			<i class="fa fa-sign-in"></i> Log in


		</button>

	</div><!-- text-center Ends -->


</form><!--form Ends -->




</div><!-- box Ends -->

<?php

if (isset($_POST['login'])) {

	$customer_email = $_POST['c_email'];

	$customer_pass = $_POST['c_pass'];

	$select_customer = "select * from customers where customer_email='$customer_email' AND customer_pass='$customer_pass'";

	$run_customer = mysqli_query($con, $select_customer);

	$get_ip = getRealUserIp();

	$check_customer = mysqli_num_rows($run_customer);

	$select_cart = "select * from cart where ip_add='$get_ip'";

	$run_cart = mysqli_query($con, $select_cart);

	$check_cart = mysqli_num_rows($run_cart);

	if ($check_customer == 0) {

		echo "<script>alert('password or email is wrong')</script>";

		exit();
	}

	if ($check_customer == 1 and $check_cart == 0) {

		$_SESSION['customer_email'] = $customer_email;

		echo "<script>alert('You are Logged In')</script>";

		echo "<script>window.open('customer/my_account.php?my_orders','_self')</script>";
	} else {

		$_SESSION['customer_email'] = $customer_email;

		echo "<script>alert('You are Logged In')</script>";

		echo "<script>window.open('checkout.php','_self')</script>";
	}
}

?>
<?php
include("includes/footer.php");

?>