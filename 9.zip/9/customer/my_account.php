<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
  <style>
    /* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Arial', sans-serif;
}

/* Body */
body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: whitesmoke;
    overflow-x: hidden;
}

/* Container */
.container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    padding: 20px;
}

/* Card */
.card {
    background: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
    padding: 40px 20px;
    max-width: 400px;
    width: 100%;
}

/* Checkmark */
.checkmark {
    font-size: 60px;
    color: #fbb200;
}

/* Heading */
.card h1 {
    font-size: 2.5em;
    margin: 20px 0;
    color: #333;
}

/* Paragraph */
.card p {
    font-size: 1.1em;
    color: #777;
    margin-bottom: 20px;
}

/* Button */
.btn {
    display: inline-block;
    background: #fbb200;
    color: #ffffff;
    padding: 15px 30px;
    font-weight: 900;
    border: none;
    border-radius: 50px;
    font-size: 1.1em;
    text-decoration: none;
    transition: background 0.3s ease;
}

.btn:hover {
    background: #fbb200;
}

/* Responsive */
@media (max-width: 768px) {
    .card {
        padding: 30px 15px;
    }
    .card h1 {
        font-size: 2em;
    }
    .card p {
        font-size: 1em;
    }
    .btn {
        padding: 12px 25px;
        font-size: 1em;
    }
}

@media (max-width: 480px) {
    .card {
        padding: 20px 10px;
    }
    .card h1 {
        font-size: 1.8em;
    }
    .card p {
        font-size: 0.9em;
    }
    .btn {
        padding: 10px 20px;
        font-size: 0.9em;
    }
}

  </style>
    <div class="container">
        <div class="card">
            <div class="checkmark">
                <i class="fas fa-check-circle"></i>
            </div>
            <h1>Congratulations!</h1>
            <p>Your order has been placed successfully.</p>
            <p>Thank you for choosing us!</p>
            <a href="#" class="btn">Thanks</a>
        </div>
    </div>
</body>
</html>
