<?php
session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

// Check if the cart session exists
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product) {
        // Display each product in the cart
        echo "<p>Product ID: " . $product['product_id'] . "</p>";
        echo "<p>Product Title: " . $product['product_title'] . "</p>";
        echo "<p>Product Price: $" . $product['product_price'] . "</p>";
        // Add more details as needed
    }
} else {
    // Display a message if the cart is empty
    echo "<p>Your cart is empty.</p>";
}

include("includes/footer.php");
?>
