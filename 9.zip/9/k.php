<!DOCTYPE html>
<html lang="zxx">

<head>
	<!-- Basic Page Needs -->
	<title>Pizzon</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- CSS -->
	<link type="image/x-icon" href="images/favicon.png" rel="icon">
	<link rel="stylesheet" type="text/css" href="./m/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./m/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./m/css/glass-case.css">
	<link rel="stylesheet" type="text/css" href="./m/css/magnific-popup.css">
	<link rel="stylesheet" type="text/css" href="./m/css/style.css">
</head>

<body>

	<!-- Preloader Start -->
	<div id="preloader" class="preloader">
		<div class="preloader-box">
			<img src="./m/images/preloader.svg" alt="preloader">
		</div>
	</div>
	<!-- Preloader End -->

	<?php

	session_start();

	include("includes/db.php");
	include("includes/header.php");
	include("functions/functions.php");
	include("includes/main.php");


	?>



	<!-- Start Of Main Div -->
	<main>

		<!-- Start Of Sub Banner -->
		<section class="sub-banner bg-yellow overflow-h position-r">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-xl-6 col-lg-6 col-md-12">
						<div class="sub-banner-content wow fadeInLeft">
							<h1 class="sub-banner-title">Shop Detail</h1>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
						</div>
					</div>

					<div class="col-xl-6 col-lg-6 col-md-12">
						<div class="bread-crumb wow fadeInRight">
							<ul>
								<li><a href="index.html">Home</a></li>
								<li>Shop Detail</li>
							</ul>
						</div>
					</div>
				</div>
			</div>

			<div class="black-jamun wow fadeInLeft animation-delay-5">
				<img src="./m/images/reservation-pizza.png" alt="black-jamun">
			</div>


		</section>
		<!-- End Of Sub Banner -->

		<?php

		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			if (isset($_POST['product_id'], $_POST['product_title'], $_POST['product_price'], $_POST['product_img'], $_POST['product_description'])) {
				$product_id = $_POST['product_id'];
				$product_title = $_POST['product_title'];
				$product_price = $_POST['product_price'];
				$product_img = $_POST['product_img'];
				$product_description = $_POST['product_description']; // Use the correct name

			}
		}
		?>
	<!-- Start Of Shop Detail -->
<section class="shop-detail ptb-100">
    <div class="container">
        <div class="row">
            <!-- Product Image Column -->
            <div class="col-xl-6 col-lg-6 col-md-12 md-mb-40">
                <div class="glasscase-main">
                    <ul id="glasscase" class="gc-start">
                        <?php echo "<li><img src='$product_img' alt='$product_title pizza-img-1'></li>";?>
                    </ul>
                </div>
            </div>
            <!-- Product Detail Column -->
            <div class="col-xl-6 col-lg-6 col-md-12">
                <div class="product-detail">
                    <?php echo "<h2 class='product-title'>$product_title</h2>"; ?>
                    <div class="product-price">
                        <div class="price">
                            <?php echo "<span>$$product_price</span>"; ?>
                        </div>
                        <div class="rating-summary-block">
                            <!-- Rating Stars -->
                        </div>
                    </div>
                    <div class="product-description">
                        <?php echo "<p>$product_description</p>"; ?>
                    </div>
                    <!-- Add to Cart Form -->
                    <form action="mange.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                        <input type="hidden" name="product_title" value="<?php echo $product_title; ?>">
                        <input type="hidden" name="product_price" value="<?php echo $product_price; ?>">
                        <input type="hidden" name="product_img" value="<?php echo $product_img; ?>">
                        <input type="hidden" name="product_description" value="<?php echo $product_description; ?>">
                        <div class="add-cart-box" style="margin-top: 10px;">
                            <div class="number">
                                <input type="text" value="1">
                                <span class="minus"><i class="fa fa-angle-up" aria-hidden="true"></i></span>
                                <span class="plus"><i class="fa fa-angle-down" aria-hidden="true"></i></span>
                            </div>
                            <div class="cart-button">
                                <button type="submit" name="Add" class="btn-ct">Add To Cart</button>
                            </div>
                            <div class="wish-list">
                                <!-- Wishlist Button -->
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Of Shop Detail -->







	</main>
	<!-- End Of Main Div -->





	<!-- Start Of Search Popup -->
	<div class="search-popup">
		<div class="search-overlay"></div>
		<div class="search-form">
			<button class="close"></button>
			<form>
				<input type="text" name="search" placeholder="What are you looking for?" class="search-input">
				<button type="submit"><img src="./m/images/search-icon-white.png" alt="Search Icon"></button>
			</form>
		</div>
	</div>
	<!-- End Of Search Popup -->





	<!-- Start Of Js -->
	<script src="./m/js/jquery-3.4.1.min.js"></script>
	<script src="./m/js/bootstrap.min.js"></script>
	<script src="./m/js/animation.js"></script>
	<script src="./m/js/jquery.magnific-popup.min.js"></script>
	<script src="./m/js/modernizr.js"></script>
	<script src="./m/js/pizzon.js"></script>
	<script>
		$(document).ready(function() {
			//If your <ul> has the id "glasscase"
			$('#glasscase').glassCase({
				'thumbsPosition': 'bottom',
				'widthDisplayPerc': 100,
				isDownloadEnabled: false,
			});
		});
	</script>
</body>

</html>