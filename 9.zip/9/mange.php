<?php
session_start();
session_destroy();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['Add'])) {
        // Check if the cart exists in the session
        if (isset($_SESSION['cart'])) {
            // Check if the product is already in the cart
            $myitems = array_column($_SESSION['cart'], 'product_title');
            if (in_array($_POST['product_title'], $myitems)) {
                echo "<script>
                        alert('Product already in cart');
                        window.location.href='kirran.php';
                    </script>";
                exit(); // Exit after displaying alert
            }

            // If not in the cart, add the new item to it
            $count = count($_SESSION['cart']);
            $_SESSION['cart'][] = array(
                'product_id' => $_POST['product_id'],
                'product_title' => $_POST['product_title'],
                'product_price' => $_POST['product_price'],
                'product_img' => $_POST['product_img'],
                'product_description' => $_POST['product_description']

            );
            echo "<script>
            alert('Product ');
            window.location.href='kirran.php';
             </script>";
            // Redirect to a different page after adding to the cart
            header('Location: kirran.php');
            exit(); // Exit after redirection
        } else {
            // If the cart does not exist, create it and add the new item
            $_SESSION['cart'][0] = array(
                'product_id' => $_POST['product_id'],
                'product_title' => $_POST['product_title'],
                'product_price' => $_POST['product_price'],
                'product_img' => $_POST['product_img'],
                'product_description' => $_POST['product_description']
            );
            // Redirect to a different page after adding to the cart
            header('Location: kirran.php');
            exit(); // Exit after redirection
        }
    }
}
