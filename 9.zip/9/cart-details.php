<!doctype html>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link type="image/x-icon" href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/10/favicon.png" rel="icon">
    <title>Margherita pizza &#8211; Pizzon Modern</title>
    <meta name='robots' content='max-image-preview:large' />
    <style id="theme_variable">
        :root {
            --theme-primary-color: #FBB200;
            --theme-secondary-color: #F22E3E;
            --theme-accent-color: #777777;
            --theme-background-color: #fff;
            --theme-button-background: #FBB200;
            --theme-button-background-hover: #F22E3E;
            --theme-link-color: #111111;
            --theme-link-hover-color: #F22E3E;
            --theme-global-border-color: #E4DED9;
            --theme-global-color-1: #FFFFFF;
            --theme-global-color-2: #111111;
            --theme-global-color-3: #FFFAED;
            --theme-global-color-4: #fff;
            --theme-font-family: Montserrat;
            --theme-font-weight: 500;
            --theme-font-size: 18px;
            --theme-line-height: 32px;
            --theme-letter-spacing: normal;
            --theme-font-size-tablet: 18px;
            --theme-line-height-tablet: 32px;
            --theme-letter-spacing-tablet: 0px;
            --theme-font-size-mobile: 16px;
            --theme-line-height-mobile: 30px;
            --theme-letter-spacing-mobile: normal;
            --theme-text-color: #777777;
            --heading1-font-family: Montserrat;
            --heading1-font-weight: 700;
            --heading1-font-style: normal;
            --heading1-text-align: initial;
            --heading1-text-transform: initial;
            --heading1-font-size: 64px;
            --heading1-line-height: 74px;
            --heading1-letter-spacing: normal;
            --heading1-text-color: #111111;
            --heading2-font-family: Montserrat;
            --heading2-font-weight: 700;
            --heading2-font-style: normal;
            --heading2-text-align: initial;
            --heading2-text-transform: initial;
            --heading2-font-size: 40px;
            --heading2-line-height: 55px;
            --heading2-letter-spacing: normal;
            --heading2-text-color: #111111;
            --heading3-font-family: Montserrat;
            --heading3-font-weight: 600;
            --heading3-font-style: normal;
            --heading3-text-align: initial;
            --heading3-text-transform: initial;
            --heading3-font-size: 28px;
            --heading3-line-height: 40px;
            --heading3-letter-spacing: normal;
            --heading3-text-color: #111111;
            --heading4-font-family: Montserrat;
            --heading4-font-weight: 600;
            --heading4-font-style: normal;
            --heading4-text-align: initial;
            --heading4-text-transform: initial;
            --heading4-font-size: 24px;
            --heading4-line-height: 28px;
            --heading4-letter-spacing: normal;
            --heading4-text-color: #1d1d1d;
            --heading5-font-family: Montserrat;
            --heading5-font-weight: 600;
            --heading5-font-style: normal;
            --heading5-text-align: initial;
            --heading5-text-transform: initial;
            --heading5-font-size: 22px;
            --heading5-line-height: 38px;
            --heading5-letter-spacing: normal;
            --heading5-text-color: #111111;
            --heading6-font-family: Montserrat;
            --heading6-font-weight: 600;
            --heading6-font-style: normal;
            --heading6-text-align: initial;
            --heading6-text-transform: initial;
            --heading6-font-size: 18px;
            --heading6-line-height: 30px;
            --heading6-letter-spacing: normal;
            --heading6-text-color: #111111;
            --heading1-font-size-tablet: 50px;
            --heading1-line-height-tablet: 64px;
            --heading1-letter-spacing-tablet: 0px;
            --heading2-font-size-tablet: 40px;
            --heading2-line-height-tablet: 55px;
            --heading2-letter-spacing-tablet: 0px;
            --heading3-font-size-tablet: 30px;
            --heading3-line-height-tablet: 34px;
            --heading3-letter-spacing-tablet: 0px;
            --heading4-font-size-tablet: 24px;
            --heading4-line-height-tablet: 28px;
            --heading4-letter-spacing-tablet: 0px;
            --heading5-font-size-tablet: 22px;
            --heading5-line-height-tablet: 38px;
            --heading5-letter-spacing-tablet: 0px;
            --heading6-font-size-tablet: 20px;
            --heading6-line-height-tablet: 20px;
            --heading6-letter-spacing-tablet: 0px;
            --heading1-font-size-mobile: 40px;
            --heading1-line-height-mobile: 52px;
            --heading1-letter-spacing-mobile: normal;
            --heading2-font-size-mobile: 30px;
            --heading2-line-height-mobile: 42px;
            --heading2-letter-spacing-mobile: 0px;
            --heading3-font-size-mobile: 26px;
            --heading3-line-height-mobile: 26px;
            --heading3-letter-spacing-mobile: normal;
            --heading4-font-size-mobile: 22px;
            --heading4-line-height-mobile: 36px;
            --heading4-letter-spacing-mobile: normal;
            --heading5-font-size-mobile: 20px;
            --heading5-line-height-mobile: 20px;
            --heading5-letter-spacing-mobile: normal;
            --heading6-font-size-mobile: 18px;
            --heading6-line-height-mobile: 18px;
            --heading6-letter-spacing-mobile: normal;
            --button-font-family: Montserrat;
            --button-font-weight: 400;
            --button-text-align: initial;
            --button-text-transform: uppercase;
            --button-font-size: 20px;
            --button-line-height: 32px;
            --button-letter-spacing: normal;
            --button-text-color: #fff;
            --button-text-hover-color: #FFFFFF;
            --button-border-radius: 50px;
            --button-padding-top: 12px;
            --button-padding-right: 30px;
            --button-padding-bottom: 12px;
            --button-padding-left: 30px;
            --button-border-color: #fbb200;
            --button-border-hover-color: #f22e3e;
            --button-border-type: solid;
            --button-border-top: 2px;
            --button-border-right: 2px;
            --button-border-bottom: 2px;
            --button-border-left: 2px;
            --button-border-hover-type: solid;
            --button-border-hover-top: 2px;
            --button-border-hover-right: 2px;
            --button-border-hover-bottom: 2px;
            --button-border-hover-left: 2px;
            --button-font-size-tablet: 16px;
            --button-line-height-tablet: 24px;
            --button-letter-spacing-tablet: 1px;
            --button-tablet-padding-top: 12px;
            --button-tablet-padding-right: 30px;
            --button-tablet-padding-bottom: 12px;
            --button-tablet-padding-left: 30px;
            --button-font-size-mobile: 16px;
            --button-line-height-mobile: 24px;
            --button-letter-spacing-mobile: 1px;
            --button-mobile-padding-top: 8px;
            --button-mobile-padding-right: 20px;
            --button-mobile-padding-bottom: 8px;
            --button-mobile-padding-left: 20px;
        }
    </style>
    <link rel='dns-prefetch' href='//stats.wp.com' />
    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
    <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin />
    <link rel="alternate" type="application/rss+xml" title="Pizzon Modern &raquo; Feed" href="https://themes.templatescoder.com/pizzon/wp/demo-02/feed/" />
    <link rel="alternate" type="application/rss+xml" title="Pizzon Modern &raquo; Comments Feed" href="https://themes.templatescoder.com/pizzon/wp/demo-02/comments/feed/" />
    <link rel="alternate" type="application/rss+xml" title="Pizzon Modern &raquo; Margherita pizza Comments Feed" href="https://themes.templatescoder.com/pizzon/wp/demo-02/product/margherita-pizza/feed/" />
    <script>
        window._wpemojiSettings = {
            "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/",
            "ext": ".png",
            "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/",
            "svgExt": ".svg",
            "source": {
                "concatemoji": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.5"
            }
        };
        /*! This file is auto-generated */
        ! function(i, n) {
            var o, s, e;

            function c(e) {
                try {
                    var t = {
                        supportTests: e,
                        timestamp: (new Date).valueOf()
                    };
                    sessionStorage.setItem(o, JSON.stringify(t))
                } catch (e) {}
            }

            function p(e, t, n) {
                e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(t, 0, 0);
                var t = new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data),
                    r = (e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(n, 0, 0), new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data));
                return t.every(function(e, t) {
                    return e === r[t]
                })
            }

            function u(e, t, n) {
                switch (t) {
                    case "flag":
                        return n(e, "\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f", "\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f") ? !1 : !n(e, "\ud83c\uddfa\ud83c\uddf3", "\ud83c\uddfa\u200b\ud83c\uddf3") && !n(e, "\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f", "\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");
                    case "emoji":
                        return !n(e, "\ud83d\udc26\u200d\u2b1b", "\ud83d\udc26\u200b\u2b1b")
                }
                return !1
            }

            function f(e, t, n) {
                var r = "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? new OffscreenCanvas(300, 150) : i.createElement("canvas"),
                    a = r.getContext("2d", {
                        willReadFrequently: !0
                    }),
                    o = (a.textBaseline = "top", a.font = "600 32px Arial", {});
                return e.forEach(function(e) {
                    o[e] = t(a, e, n)
                }), o
            }

            function t(e) {
                var t = i.createElement("script");
                t.src = e, t.defer = !0, i.head.appendChild(t)
            }
            "undefined" != typeof Promise && (o = "wpEmojiSettingsSupports", s = ["flag", "emoji"], n.supports = {
                everything: !0,
                everythingExceptFlag: !0
            }, e = new Promise(function(e) {
                i.addEventListener("DOMContentLoaded", e, {
                    once: !0
                })
            }), new Promise(function(t) {
                var n = function() {
                    try {
                        var e = JSON.parse(sessionStorage.getItem(o));
                        if ("object" == typeof e && "number" == typeof e.timestamp && (new Date).valueOf() < e.timestamp + 604800 && "object" == typeof e.supportTests) return e.supportTests
                    } catch (e) {}
                    return null
                }();
                if (!n) {
                    if ("undefined" != typeof Worker && "undefined" != typeof OffscreenCanvas && "undefined" != typeof URL && URL.createObjectURL && "undefined" != typeof Blob) try {
                        var e = "postMessage(" + f.toString() + "(" + [JSON.stringify(s), u.toString(), p.toString()].join(",") + "));",
                            r = new Blob([e], {
                                type: "text/javascript"
                            }),
                            a = new Worker(URL.createObjectURL(r), {
                                name: "wpTestEmojiSupports"
                            });
                        return void(a.onmessage = function(e) {
                            c(n = e.data), a.terminate(), t(n)
                        })
                    } catch (e) {}
                    c(n = f(s, u, p))
                }
                t(n)
            }).then(function(e) {
                for (var t in e) n.supports[t] = e[t], n.supports.everything = n.supports.everything && n.supports[t], "flag" !== t && (n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && n.supports[t]);
                n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && !n.supports.flag, n.DOMReady = !1, n.readyCallback = function() {
                    n.DOMReady = !0
                }
            }).then(function() {
                return e
            }).then(function() {
                var e;
                n.supports.everything || (n.readyCallback(), (e = n.source || {}).concatemoji ? t(e.concatemoji) : e.wpemoji && e.twemoji && (t(e.twemoji), t(e.wpemoji)))
            }))
        }((window, document), window._wpemojiSettings);
    </script>
    <style id='wp-emoji-styles-inline-css'>
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 0.07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='wp-block-library-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/css/dist/block-library/style.min.css?ver=6.5' media='all' />
    <style id='wp-block-library-theme-inline-css'>
        .wp-block-audio figcaption {
            color: #555;
            font-size: 13px;
            text-align: center
        }

        .is-dark-theme .wp-block-audio figcaption {
            color: #ffffffa6
        }

        .wp-block-audio {
            margin: 0 0 1em
        }

        .wp-block-code {
            border: 1px solid #ccc;
            border-radius: 4px;
            font-family: Menlo, Consolas, monaco, monospace;
            padding: .8em 1em
        }

        .wp-block-embed figcaption {
            color: #555;
            font-size: 13px;
            text-align: center
        }

        .is-dark-theme .wp-block-embed figcaption {
            color: #ffffffa6
        }

        .wp-block-embed {
            margin: 0 0 1em
        }

        .blocks-gallery-caption {
            color: #555;
            font-size: 13px;
            text-align: center
        }

        .is-dark-theme .blocks-gallery-caption {
            color: #ffffffa6
        }

        .wp-block-image figcaption {
            color: #555;
            font-size: 13px;
            text-align: center
        }

        .is-dark-theme .wp-block-image figcaption {
            color: #ffffffa6
        }

        .wp-block-image {
            margin: 0 0 1em
        }

        .wp-block-pullquote {
            border-bottom: 4px solid;
            border-top: 4px solid;
            color: currentColor;
            margin-bottom: 1.75em
        }

        .wp-block-pullquote cite,
        .wp-block-pullquote footer,
        .wp-block-pullquote__citation {
            color: currentColor;
            font-size: .8125em;
            font-style: normal;
            text-transform: uppercase
        }

        .wp-block-quote {
            border-left: .25em solid;
            margin: 0 0 1.75em;
            padding-left: 1em
        }

        .wp-block-quote cite,
        .wp-block-quote footer {
            color: currentColor;
            font-size: .8125em;
            font-style: normal;
            position: relative
        }

        .wp-block-quote.has-text-align-right {
            border-left: none;
            border-right: .25em solid;
            padding-left: 0;
            padding-right: 1em
        }

        .wp-block-quote.has-text-align-center {
            border: none;
            padding-left: 0
        }

        .wp-block-quote.is-large,
        .wp-block-quote.is-style-large,
        .wp-block-quote.is-style-plain {
            border: none
        }

        .wp-block-search .wp-block-search__label {
            font-weight: 700
        }

        .wp-block-search__button {
            border: 1px solid #ccc;
            padding: .375em .625em
        }

        :where(.wp-block-group.has-background) {
            padding: 1.25em 2.375em
        }

        .wp-block-separator.has-css-opacity {
            opacity: .4
        }

        .wp-block-separator {
            border: none;
            border-bottom: 2px solid;
            margin-left: auto;
            margin-right: auto
        }

        .wp-block-separator.has-alpha-channel-opacity {
            opacity: 1
        }

        .wp-block-separator:not(.is-style-wide):not(.is-style-dots) {
            width: 100px
        }

        .wp-block-separator.has-background:not(.is-style-dots) {
            border-bottom: none;
            height: 1px
        }

        .wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots) {
            height: 2px
        }

        .wp-block-table {
            margin: 0 0 1em
        }

        .wp-block-table td,
        .wp-block-table th {
            word-break: normal
        }

        .wp-block-table figcaption {
            color: #555;
            font-size: 13px;
            text-align: center
        }

        .is-dark-theme .wp-block-table figcaption {
            color: #ffffffa6
        }

        .wp-block-video figcaption {
            color: #555;
            font-size: 13px;
            text-align: center
        }

        .is-dark-theme .wp-block-video figcaption {
            color: #ffffffa6
        }

        .wp-block-video {
            margin: 0 0 1em
        }

        .wp-block-template-part.has-background {
            margin-bottom: 0;
            margin-top: 0;
            padding: 1.25em 2.375em
        }
    </style>
    <style id='classic-theme-styles-inline-css'>
        /*! This file is auto-generated */

        .wp-block-button__link {
            color: #fff;
            background-color: #32373c;
            border-radius: 9999px;
            box-shadow: none;
            text-decoration: none;
            padding: calc(.667em + 2px) calc(1.333em + 2px);
            font-size: 1.125em
        }

        .wp-block-file__button {
            background: #32373c;
            color: #fff;
            text-decoration: none
        }
    </style>
    <link rel='stylesheet' id='redux-extendify-styles-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/redux-framework/redux-core/assets/css/extendify-utilities.css?ver=4.4.13' media='all' />
    <link rel='stylesheet' id='contact-form-7-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.8.7' media='all' />
    <link rel='stylesheet' id='product-archive-widgets-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/inc/widgets-css/product-archive-widgets.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='tmpcoder-widgets-style-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/inc/widgets-css/frontend.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='tmpcoder-woo-product-compare-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/css/product-compare/woo-product-compare.min.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='tmpcoder-woo-grid-css-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/woo-pro-grid/frontend.min.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='tmpcoder-animations-css-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/woo-pro-grid/lib/tmpcoder-animations.min.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='tmpcoder-link-animations-css-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/woo-pro-grid/lib/tmpcoder-link-animations.min.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='tmpcoder-button-animations-css-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/woo-pro-grid/lib/button-animations.min.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='tmpcoder-loading-animations-css-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/woo-pro-grid/lib/loading-animations.min.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='tmpcoder-lightgallery-css-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/woo-pro-grid/lib/lightgallery/lightgallery.min.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='widget-woocommerce-css-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/inc/widgets-css/widget-woocommerce.min.css?ver=1.3.5' media='all' />
    <link rel='stylesheet' id='jquery-listtopie-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/css/jquery.listtopie.css?ver=1.0.0' media='' />
    <link rel='stylesheet' id='magnific-popup-min-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/css/magnific-popup.min.css?ver=1.0.0' media='' />
    <link rel='stylesheet' id='tmpcoder-frontend-style-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/css/frontend.css?ver=1.0.0' media='' />
    <link rel='stylesheet' id='woo-mini-cart-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/css/woo-mini-cart/woo-mini-cart.css?ver=1.0.0' media='' />
    <link rel='stylesheet' id='tmpcoder-multicolor-style-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core//assets/css/canvas.css?ver=6.5' media='all' />
    <link rel='stylesheet' id='photoswipe-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/css/photoswipe/photoswipe.min.css?ver=8.6.1' media='all' />
    <link rel='stylesheet' id='photoswipe-default-skin-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.min.css?ver=8.6.1' media='all' />
    <link rel='stylesheet' id='woocommerce-layout-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=8.6.1' media='all' />
    <link rel='stylesheet' id='woocommerce-smallscreen-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=8.6.1' media='only screen and (max-width: 768px)' />
    <link rel='stylesheet' id='woocommerce-general-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=8.6.1' media='all' />
    <style id='woocommerce-inline-inline-css'>
        .woocommerce form .form-row .required {
            visibility: visible;
        }
    </style>
    <link rel='stylesheet' id='dashicons-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/css/dashicons.min.css?ver=6.5' media='all' />
    <style id='dashicons-inline-css'>
        [data-font="Dashicons"]:before {
            font-family: 'Dashicons' !important;
            content: attr(data-icon) !important;
            speak: none !important;
            font-weight: normal !important;
            font-variant: normal !important;
            text-transform: none !important;
            line-height: 1 !important;
            font-style: normal !important;
            -webkit-font-smoothing: antialiased !important;
            -moz-osx-font-smoothing: grayscale !important;
        }
    </style>
    <link rel='stylesheet' id='cfvsw_swatches_product-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/variation-swatches-woo/assets/css/swatches.css?ver=1.0.7' media='all' />
    <style id='cfvsw_swatches_product-inline-css'>
        .cfvsw-tooltip {
            background: #000000;
            color: #ffffff;
        }

        .cfvsw-tooltip:before {
            background: #000000;
        }

        :root {
            --cfvsw-swatches-font-size: 12px;
            --cfvsw-swatches-border-color: #000000;
            --cfvsw-swatches-border-color-hover: #00000080;
            --cfvsw-swatches-tooltip-font-size: 12px;
        }
    </style>
    <link rel='stylesheet' id='wlfmc-main-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/smart-wishlist-for-more-convert/assets/frontend/css/style.min.css?ver=1.7.4' media='all' />
    <style id='wlfmc-main-inline-css'>
        .wlfmc-wishlist-popup .wlfmc-popup-footer .wlfmc_btn_0 {
            background-color: #555555;
            color: #ffffff;
            border-radius: 2px !important;
        }

        .wlfmc-wishlist-popup .wlfmc-popup-footer .wlfmc_btn_0:hover {
            background-color: #555555;
            ;
            color: #ffffff;
        }

        .wlfmc-wishlist-popup .wlfmc-popup-footer .wlfmc_btn_1 {
            background-color: rgba(0, 0, 0, 0);
            color: #7e7e7e;
            border-radius: 2px !important;
        }

        .wlfmc-wishlist-popup .wlfmc-popup-footer .wlfmc_btn_1:hover {
            background-color: rgba(0, 0, 0, 0);
            ;
            color: #7e7e7e;
        }

        .wlfmc-popup {
            background-color: #fff;
        }

        .wlfmc-popup .wlfmc-popup-content,
        .wlfmc-popup .wlfmc-popup-content label {
            color: #333;
        }

        .wlfmc-popup .wlfmc-popup-title {
            color: #333;
        }

        .wlfmc-popup {
            border-color: #c2c2c2;
        }

        .wlfmc-popup .wlfmc-popup-header-bordered i:not(.wlfmc-icon-close) {
            color: #333;
        }

        .wlfmc-popup .wlfmc-popup-header-bordered i:not(.wlfmc-icon-close) {
            background-color: #f2f2f2;
        }

        .wlfmc-popup {
            border-radius: 8px;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a.have-sep span:before {
            border-left-color: transparent;
        }

        :root {
            --tooltip-color-custom: #fff;
        }

        :root {
            --tooltip-bg-custom: rgb(251, 178, 0);
        }

        .wlfmc-tooltip-custom {
            border-radius: 6px !important;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a i {
            font-size: 15px;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a i {
            color: rgb(230, 126, 34);
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a:hover i {
            color: rgb(81, 81, 81);
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a {
            background-color: transparent;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a:hover {
            background-color: transparent;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a {
            border-radius: 5px;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a {
            border-width: 1px;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a {
            border-color: transparent;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a:hover {
            border-color: transparent;
        }

        .wlfmc-single-btn:not(.is-elementor) {
            margin: 0px !important;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a {
            width: 45px !important;
        }

        .wlfmc-single-btn:not(.is-elementor) .wlfmc-add-button>a {
            height: 45px;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a.have-sep span:before {
            border-left-color: transparent;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a i {
            font-size: 15px;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a i {
            color: rgb(230, 126, 34);
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a:hover i {
            color: rgb(81, 81, 81);
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a {
            height: 45px;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a {
            border-radius: 5px;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a {
            border-width: 1px;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a {
            background-color: transparent;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a:hover {
            background-color: transparent;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a {
            border-color: transparent;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a:hover {
            border-color: transparent;
        }

        .wlfmc-loop-btn:not(.is-elementor) .wlfmc-add-button>a {
            width: 45px;
        }

        .wlfmc-loop-btn:not(.is-elementor) {
            margin: 0px !important;
        }

        .wlfmc-guest-notice-wrapper {
            background-color: #f6f6f6;
        }

        .wlfmc-guest-notice-wrapper .wlfmc-notice-buttons a.wlfmc_btn_0 {
            background-color: #555555 !important;
            ;
            color: #ffffff !important;
            border-radius: 2px;
        }

        .wlfmc-guest-notice-wrapper .wlfmc-notice-buttons a.wlfmc_btn_0:hover {
            background-color: #555555 !important;
            ;
            color: #ffffff !important;
        }

        .wlfmc-guest-notice-wrapper .wlfmc-notice-buttons a.wlfmc_btn_1 {
            background-color: rgba(0, 0, 0, 0) !important;
            ;
            color: #7e7e7e !important;
            border-radius: 2px;
        }

        .wlfmc-guest-notice-wrapper .wlfmc-notice-buttons a.wlfmc_btn_1:hover {
            background-color: rgba(0, 0, 0, 0) !important;
            ;
            color: #7e7e7e !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus),
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer select,
        .wlfmc-default-table:not(.is-elementor).qty-same-button input.qty,
        .wlfmc-default-table:not(.is-elementor).qty-same-button .quantity .button {
            border-radius: 5px !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus),
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer select,
        .wlfmc-default-table:not(.is-elementor).qty-same-button input.qty,
        .wlfmc-default-table:not(.is-elementor).qty-same-button .quantity .button {
            border-width: 1px !important;
            border-style: solid;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus),
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer select,
        .wlfmc-default-table:not(.is-elementor).qty-same-button input.qty,
        .wlfmc-default-table:not(.is-elementor).qty-same-button .quantity .button {
            background-color: #ebebeb !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button:hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn:hover,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus):hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button:hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"]:hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"]:hover {
            background-color: #e67e22 !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus),
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer select,
        .wlfmc-default-table:not(.is-elementor).qty-same-button input.qty,
        .wlfmc-default-table:not(.is-elementor).qty-same-button .quantity .button {
            border-color: transparent !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button:hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn:hover,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus):hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button:hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"]:hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"]:hover {
            border-color: transparent !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus),
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer select,
        .wlfmc-default-table:not(.is-elementor).qty-same-button input.qty,
        .wlfmc-default-table:not(.is-elementor).qty-same-button .quantity .button {
            color: #515151 !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button:hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn:hover,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus):hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button:hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"]:hover,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"]:hover {
            color: #fff !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus),
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer select,
        .wlfmc-default-table:not(.is-elementor).qty-same-button input.qty,
        .wlfmc-default-table:not(.is-elementor).qty-same-button .quantity .button {
            font-size: 14px !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .apply-btn,
        .wlfmc-default-table:not(.is-elementor).add-to-card-same-button tr td.last-column .button:not(.minus):not(.plus),
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .button,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer button[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer input[type="submit"],
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer select,
        .wlfmc-default-table:not(.is-elementor).qty-same-button input.qty,
        .wlfmc-default-table:not(.is-elementor).qty-same-button .quantity .button {
            height: 36px !important;
            max-height: 36px !important;
            min-height: 36px !important;
            padding-top: 0;
            padding-bottom: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        .wlfmc-default-table:not(.is-elementor) .product-thumbnail img {
            background-color: #f5f5f5;
        }

        .wlfmc-default-table:not(.is-elementor) .total-prices,
        .wlfmc-default-table:not(.is-elementor) .total-prices>div,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .wlfmc-total-td,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer tr.actions,
        .wlfmc-default-table-header:not(.is-elementor),
        .wlfmc-default-table:not(.is-elementor) .wishlist-items-wrapper:not(.wishlist-empty) tr {
            border-color: #ebebeb !important;
        }

        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .wlfmc-total-td,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer tr.actions,
        .wlfmc-default-table-header:not(.is-elementor),
        .wlfmc-default-table:not(.is-elementor) .wishlist-items-wrapper:not(.wishlist-empty) tr,
        .wlfmc-default-table:not(.is-elementor) .wishlist-items-wrapper:not(.wishlist-empty) .wlfmc-absolute-meta-data {
            border-radius: 6px;
        }

        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer .wlfmc-total-td,
        .wlfmc-default-table:not(.is-elementor) .wlfmc-wishlist-footer tr.actions,
        .wlfmc-default-table-header:not(.is-elementor),
        .wlfmc-default-table:not(.is-elementor) .wishlist-items-wrapper:not(.wishlist-empty) tr {
            background-color: #fff !important;
        }

        .wlfmc-default-table:not(.is-elementor) .wishlist-items-wrapper:not(.wishlist-empty) tr:hover {
            background-color: #fff !important;
        }

        .wlfmc-default-table:not(.is-elementor) td.with-border-top {
            border-top-color: transparent !important;
        }

        .wlfmc-share ul.share-items .share-item a.facebook i {
            color: #C71610;
        }

        .wlfmc-share ul.share-items .share-item a.twitter i {
            color: #00ACEE;
        }

        .wlfmc-share ul.share-items .share-item a.messenger i {
            color: #0077FF;
        }

        .wlfmc-share ul.share-items .share-item a.whatsapp i {
            color: #4FCE5D;
        }

        .wlfmc-share ul.share-items .share-item a.telegram i {
            color: #2AABEE;
        }

        .wlfmc-share ul.share-items .share-item a.email i {
            color: #C71610;
        }

        .wlfmc-share ul.share-items .share-item a.download-pdf i {
            color: #FF2366;
        }

        .wlfmc-share ul.share-items .share-item a.copy-link-trigger i {
            color: #9162ff;
        }

        .wlfmc-share ul.share-items i {
            border-radius: 50% !important;
        }

        .wlfmc-share ul.share-items a:hover i {
            border-color: rgba(59, 89, 152, .1) !important;
        }

        .wlfmc-share ul.share-items i {
            border-color: rgba(59, 89, 152, .1) !important;
        }

        .wlfmc-share .wlfmc-copy-container .copy-link-trigger {
            color: #333 !important;
        }

        .wlfmc-share .wlfmc-copy-container .copy-link-trigger:hover {
            color: #333 !important;
        }

        .wlfmc-share .wlfmc-copy-container .copy-link-trigger {
            background-color: #ebebeb !important;
        }

        .wlfmc-share .wlfmc-copy-container .copy-link-trigger:hover {
            background-color: #ebebeb !important;
        }

        .wlfmc-share .wlfmc-copy-container .copy-link-trigger {
            border-color: #ebebeb !important;
        }

        .wlfmc-share .wlfmc-copy-container .copy-link-trigger:hover {
            border-color: transparent !important;
        }

        .wlfmc-share .wlfmc-copy-container {
            color: #333 !important;
        }

        .wlfmc-share .wlfmc-copy-container {
            border-color: rgba(59, 89, 152, .1) !important;
        }

        .wlfmc-share .wlfmc-copy-container {
            background-color: #fff !important;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-view-wishlist-link {
            background-color: #ebebeb !important;
            ;
            color: #515151 !important;
            border-color: rgb(0, 0, 0, 0) !important;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-view-wishlist-link:hover {
            background-color: #e67e22 !important;
            ;
            color: #fff !important;
            border-color: rgb(0, 0, 0, 0) !important;
        }

        .wlfmc-elementor.wlfmc-wishlist-counter {
            z-index: 997 !important;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-counter-icon i {
            color: #333;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-counter-icon i {
            font-size: inherit;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-counter-number.position-top-left,
        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-counter-number.position-top-right {
            background-color: #e74c3c;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-counter-icon i.wlfmc-svg {
            width: 24px;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-counter-items {
            background-color: #fff;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-counter-items {
            border-color: #f5f5f5;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-counter-items {
            border-radius: 5px !important;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-view-wishlist-link {
            height: 38px !important;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-view-wishlist-link {
            font-size: 15px !important;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-view-wishlist-link {
            border-width: 1px !important;
        }

        .wlfmc-products-counter-wrapper:not(.is-elementor) .wlfmc-view-wishlist-link {
            border-radius: 5px !important;
        }

        .wlfmc-default-table:not(.is-elementor) input.qty {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }

        .wlfmc-default-table-header:not(.is-elementor) .button {
            width: 36px
        }

        .single-product div.product form.cart .wlfmc-add-to-wishlist.wlfmc_position_before_add_to_cart_button {
            float: left;
        }

        .rtl.single-product div.product form.cart .wlfmc-add-to-wishlist.wlfmc_position_before_add_to_cart_button {
            float: right;
        }
    </style>
    <link rel='stylesheet' id='jquery-colorbox-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/yith-woocommerce-compare/assets/css/colorbox.css?ver=1.4.21' media='all' />
    <link rel='stylesheet' id='google-fonts-css' href='https://fonts.googleapis.com/css?family=PT+Sans+Narrow%3A400%2C500%2C600%2C700&#038;display=swap&#038;ver=6.5' media='all' />
    <link rel='stylesheet' id='owl-carousel-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/themes/pizzon/assets/css/owl.carousel.css?ver=1.0.0' media='' />
    <link rel='stylesheet' id='wc-style-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/themes/pizzon/assets/css/wc-style.css?ver=1.0.0' media='' />
    <link rel='stylesheet' id='theme-min-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/themes/pizzon/theme.min.css?ver=1.0.5' media='' />
    <link rel='stylesheet' id='pizn-style-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/themes/pizzon/style.css?ver=1.0.5' media='all' />
    <style id='pizn-style-inline-css'>
        h1,
        .entry-content h1 {
            font-size: var(--heading1-font-size);
            font-family: var(--heading1-font-family);
            font-weight: var(--heading1-font-weight);
            color: var(--heading1-text-color);
            line-height: var(--heading1-line-height);
            text-transform: var(--heading1-text-transform);
            letter-spacing: var(--heading1-letter-spacing);
        }

        h2,
        .entry-content h2 {
            font-size: var(--heading2-font-size);
            font-family: var(--heading2-font-family);
            font-weight: var(--heading2-font-weight);
            color: var(--heading2-text-color);
            line-height: var(--heading2-line-height);
            text-transform: var(--heading2-text-transform);
            letter-spacing: var(--heading2-letter-spacing);
        }

        h3,
        .entry-content h3 {
            font-size: var(--heading3-font-size);
            font-family: var(--heading3-font-family);
            font-weight: var(--heading3-font-weight);
            color: var(--heading3-text-color);
            line-height: var(--heading3-line-height);
            text-transform: var(--heading3-text-transform);
            letter-spacing: var(--heading3-letter-spacing);
        }

        h4,
        .entry-content h4 {
            font-size: var(--heading4-font-size);
            font-family: var(--heading4-font-family);
            font-weight: var(--heading4-font-weight);
            color: var(--heading4-text-color);
            line-height: var(--heading4-line-height);
            text-transform: var(--heading4-text-transform);
            letter-spacing: var(--heading4-letter-spacing);
        }

        h5,
        .entry-content h5 {
            font-size: var(--heading5-font-size);
            font-family: var(--heading5-font-family);
            font-weight: var(--heading5-font-weight);
            color: var(--heading5-text-color);
            line-height: var(--heading5-line-height);
            text-transform: var(--heading5-text-transform);
            letter-spacing: var(--heading5-letter-spacing);
        }

        h6,
        .entry-content h6 {
            font-size: var(--heading6-font-size);
            font-family: var(--heading6-font-family);
            font-weight: var(--heading6-font-weight);
            color: var(--heading6-text-color);
            line-height: var(--heading6-line-height);
            text-transform: var(--heading6-text-transform);
            letter-spacing: var(--heading6-letter-spacing);
        }

        .elementor-button-wrapper .elementor-button {
            background-color: var(--theme-button-background);
            border-color: var(--button-border-color);
            border-style: var(--button-border-type);
            border-top-width: var(--button-border-top);
            border-right-width: var(--button-border-right);
            border-bottom-width: var(--button-border-bottom);
            border-left-width: var(--button-border-left);
            font-family: var(--button-font-family);
            font-weight: var(--button-font-weight);
            text-align: var(--button-text-align);
            text-transform: var(--button-text-transform);
            font-size: var(--button-font-size);
            line-height: var(--button-line-height);
            letter-spacing: var(--button-letter-spacing);
            border-radius: var(--button-border-radius);
            padding-top: var(--button-padding-top);
            padding-right: var(--button-padding-right);
            padding-left: var(--button-padding-left);
            padding-bottom: var(--button-padding-bottom);
        }

        .elementor-button-wrapper .elementor-button:hover {
            background-color: var(--theme-button-background-hover);
            border-color: var(--button-border-hover-color);
            color: var(--button-text-hover-color);
            border-style: var(--button-border-hover-type);
            border-top-width: var(--button-border-hover-top);
            border-right-width: var(--button-border-hover-right);
            border-bottom-width: var(--button-border-hover-bottom);
            border-left-width: var(--button-border-hover-left);
        }

        @media (max-width: 1024px) {
            body {
                font-size: var(--theme-font-size-tablet);
                line-height: var(--theme-line-height-tablet);
                letter-spacing: var(--theme-letter-spacing-tablet)
            }
            h1,
            .entry-content h1 {
                font-size: var(--heading1-font-size-tablet);
                line-height: var(--heading1-line-height-tablet);
                letter-spacing: var(--heading1-letter-spacing-tablet);
            }
            h2,
            .entry-content h2 {
                font-size: var(--heading2-font-size-tablet);
                line-height: var(--heading2-line-height-tablet);
                letter-spacing: var(--heading2-letter-spacing-tablet);
            }
            h3,
            .entry-content h3 {
                font-size: var(--heading3-font-size-tablet);
                line-height: var(--heading3-line-height-tablet);
                letter-spacing: var(--heading3-letter-spacing-tablet);
            }
            h4,
            .entry-content h4 {
                font-size: var(--heading4-font-size-tablet);
                line-height: var(--heading4-line-height-tablet);
                letter-spacing: var(--heading4-letter-spacing-tablet);
            }
            h5,
            .entry-content h5 {
                font-size: var(--heading5-font-size-tablet);
                line-height: var(--heading5-line-height-tablet);
                letter-spacing: var(--heading5-letter-spacing-tablet);
            }
            h6,
            .entry-content h6 {
                font-size: var(--heading6-font-size-tablet);
                line-height: var(--heading6-line-height-tablet);
                letter-spacing: var(--heading6-letter-spacing-tablet);
            }
            button {
                font-size: var(--button-font-size-tablet);
                line-height: var(--button-line-height-tablet);
                letter-spacing: var(--button-letter-spacing-tablet);
                padding-top: var(--button-tablet-padding-top);
                padding-right: var(--button-tablet-padding-right);
                padding-left: var(--button-tablet-padding-left);
                padding-bottom: var(--button-tablet-padding-bottom);
            }
            .tmpcoder-navigation-menu__align-tablet-center nav ul {
                display: grid;
                text-align: center;
                align-items: center;
                justify-content: center !important;
            }
            .tmpcoder-navigation-menu__align-tablet-right nav ul {
                display: grid;
                text-align: right;
                align-items: right;
                justify-content: right !important;
            }
            .tmpcoder-navigation-menu__align-tablet-left nav ul {
                display: grid;
                text-align: left;
                align-items: left;
                justify-content: left !important;
            }
        }

        @media (max-width: 768px) {
            body {
                font-size: var(--theme-font-size-mobile);
                line-height: var(--theme-line-height-mobile);
                letter-spacing: var(--theme-letter-spacing-mobile)
            }
            h1,
            .entry-content h1 {
                font-size: var(--heading1-font-size-mobile);
                line-height: var(--heading1-line-height-mobile);
                letter-spacing: var(--heading1-letter-spacing-mobile);
            }
            h2,
            .entry-content h2 {
                font-size: var(--heading2-font-size-mobile);
                line-height: var(--heading2-line-height-mobile);
                letter-spacing: var(--heading2-letter-spacing-mobile);
            }
            h3,
            .entry-content h3 {
                font-size: var(--heading3-font-size-mobile);
                line-height: var(--heading3-line-height-mobile);
                letter-spacing: var(--heading3-letter-spacing-mobile);
            }
            h4,
            .entry-content h4 {
                font-size: var(--heading4-font-size-mobile);
                line-height: var(--heading4-line-height-mobile);
                letter-spacing: var(--heading4-letter-spacing-mobile);
            }
            h5,
            .entry-content h5 {
                font-size: var(--heading5-font-size-mobile);
                line-height: var(--heading5-line-height-mobile);
                letter-spacing: var(--heading5-letter-spacing-mobile);
            }
            h6,
            .entry-content h6 {
                font-size: var(--heading6-font-size-mobile);
                line-height: var(--heading6-line-height-mobile);
                letter-spacing: var(--heading6-letter-spacing-mobile);
            }
            button {
                font-size: var(--button-font-size-mobile);
                line-height: var(--button-line-height-mobile);
                letter-spacing: var(--button-letter-spacing-mobile);
                padding-top: var(--button-mobile-padding-top);
                padding-right: var(--button-mobile-padding-right);
                padding-left: var(--button-mobile-padding-left);
                padding-bottom: var(--button-mobile-padding-bottom);
            }
            .tmpcoder-navigation-menu__align-mobile-center nav ul {
                display: grid;
                text-align: center;
                align-items: center;
                justify-content: center !important;
            }
            .tmpcoder-navigation-menu__align-mobile-right nav ul {
                display: grid;
                text-align: right;
                align-items: right;
                justify-content: right !important;
            }
            .tmpcoder-navigation-menu__align-mobile-left nav ul {
                display: grid;
                text-align: left;
                align-items: left;
                justify-content: left !important;
            }
        }

        .wp-block-button .wp-block-button__link,
        .elementor-button-wrapper .elementor-button,
        .elementor-button-wrapper .elementor-button:visited {
            color: var(--button-text-color);
            fill: var(--button-text-color);
        }

        ,
        .elementor-button:hover {
            color: var(--button-text-hover-color);
            fill: var(--button-text-hover-color);
        }
    </style>
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=Montserrat:500,700,600,400&#038;display=swap&#038;ver=1712212718" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:500,700,600,400&#038;display=swap&#038;ver=1712212718" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:500,700,600,400&#038;display=swap&#038;ver=1712212718" /></noscript>
    <link rel='stylesheet' id='tmpcoder-mega-menu-frontend-style-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/css/mega-menu.css?ver=1.3.5'
        media='all' />
    <script type="text/template" id="tmpl-variation-template">
        <div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
        <div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
        <div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
    </script>
    <script type="text/template" id="tmpl-unavailable-variation-template">
        <p>Sorry, this product is unavailable. Please choose a different combination.</p>
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.14.0" id="regenerator-runtime-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/dist/hooks.min.js?ver=2810c76e705dd1a53b18" id="wp-hooks-js"></script>
    <script src="https://stats.wp.com/w.js?ver=202423" id="woo-tracks-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.8.6.1" id="jquery-blockui-js" data-wp-strategy="defer"></script>
    <script id="wc-add-to-cart-js-extra">
        var wc_add_to_cart_params = {
            "ajax_url": "\/pizzon\/wp\/demo-02\/wp-admin\/admin-ajax.php",
            "wc_ajax_url": "\/pizzon\/wp\/demo-02\/?wc-ajax=%%endpoint%%",
            "i18n_view_cart": "View cart",
            "cart_url": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/cart\/",
            "is_cart": "",
            "cart_redirect_after_add": "no"
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=8.6.1" id="wc-add-to-cart-js" defer data-wp-strategy="defer"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/zoom/jquery.zoom.min.js?ver=1.7.21-wc.8.6.1" id="zoom-js" defer data-wp-strategy="defer"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/flexslider/jquery.flexslider.min.js?ver=2.7.2-wc.8.6.1" id="flexslider-js" defer data-wp-strategy="defer"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe.min.js?ver=4.1.1-wc.8.6.1" id="photoswipe-js" defer data-wp-strategy="defer"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe-ui-default.min.js?ver=4.1.1-wc.8.6.1" id="photoswipe-ui-default-js" defer data-wp-strategy="defer"></script>
    <script id="wc-single-product-js-extra">
        var wc_single_product_params = {
            "i18n_required_rating_text": "Please select a rating",
            "review_rating_required": "yes",
            "flexslider": {
                "rtl": false,
                "animation": true,
                "smoothHeight": true,
                "directionNav": true,
                "controlNav": "thumbnails",
                "slideshow": false,
                "animationSpeed": 500,
                "animationLoop": false,
                "allowOneSlide": false,
                "minItems": 2,
                "maxItems": 4
            },
            "zoom_enabled": "1",
            "zoom_options": [],
            "photoswipe_enabled": "1",
            "photoswipe_options": {
                "shareEl": false,
                "closeOnScroll": false,
                "history": false,
                "hideAnimationDuration": 0,
                "showAnimationDuration": 0
            },
            "flexslider_enabled": "1"
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/frontend/single-product.min.js?ver=8.6.1" id="wc-single-product-js" defer data-wp-strategy="defer"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.8.6.1" id="js-cookie-js" defer data-wp-strategy="defer"></script>
    <script id="woocommerce-js-extra">
        var woocommerce_params = {
            "ajax_url": "\/pizzon\/wp\/demo-02\/wp-admin\/admin-ajax.php",
            "wc_ajax_url": "\/pizzon\/wp\/demo-02\/?wc-ajax=%%endpoint%%"
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=8.6.1" id="woocommerce-js" defer data-wp-strategy="defer"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/underscore.min.js?ver=1.13.4" id="underscore-js"></script>
    <script id="wp-util-js-extra">
        var _wpUtilSettings = {
            "ajax": {
                "url": "\/pizzon\/wp\/demo-02\/wp-admin\/admin-ajax.php"
            }
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/wp-util.min.js?ver=6.5" id="wp-util-js"></script>
    <link rel="https://api.w.org/" href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-json/" />
    <link rel="alternate" type="application/json" href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-json/wp/v2/product/3190" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://themes.templatescoder.com/pizzon/wp/demo-02/xmlrpc.php?rsd" />
    <meta name="generator" content="WordPress 6.5" />
    <meta name="generator" content="WooCommerce 8.6.1" />
    <link rel="canonical" href="https://themes.templatescoder.com/pizzon/wp/demo-02/product/margherita-pizza/" />
    <link rel='shortlink' href='https://themes.templatescoder.com/pizzon/wp/demo-02/?p=3190' />
    <link rel="alternate" type="application/json+oembed" href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fthemes.templatescoder.com%2Fpizzon%2Fwp%2Fdemo-02%2Fproduct%2Fmargherita-pizza%2F" />
    <link rel="alternate" type="text/xml+oembed" href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fthemes.templatescoder.com%2Fpizzon%2Fwp%2Fdemo-02%2Fproduct%2Fmargherita-pizza%2F&#038;format=xml" />
    <meta name="generator" content="Redux 4.4.13" /> <noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
    <meta name="generator" content="Elementor 3.19.4; features: e_optimized_assets_loading, e_optimized_css_loading, e_font_icon_svg, additional_custom_breakpoints, block_editor_assets_optimize, e_image_loading_optimization; settings: css_print_method-external, google_font-enabled, font_display-swap">
    <meta name="generator" content="Powered by Slider Revolution 6.6.20 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
    <script>
        function setREVStartSize(e) {
            //window.requestAnimationFrame(function() {
            window.RSIW = window.RSIW === undefined ? window.innerWidth : window.RSIW;
            window.RSIH = window.RSIH === undefined ? window.innerHeight : window.RSIH;
            try {
                var pw = document.getElementById(e.c).parentNode.offsetWidth,
                    newh;
                pw = pw === 0 || isNaN(pw) || (e.l == "fullwidth" || e.layout == "fullwidth") ? window.RSIW : pw;
                e.tabw = e.tabw === undefined ? 0 : parseInt(e.tabw);
                e.thumbw = e.thumbw === undefined ? 0 : parseInt(e.thumbw);
                e.tabh = e.tabh === undefined ? 0 : parseInt(e.tabh);
                e.thumbh = e.thumbh === undefined ? 0 : parseInt(e.thumbh);
                e.tabhide = e.tabhide === undefined ? 0 : parseInt(e.tabhide);
                e.thumbhide = e.thumbhide === undefined ? 0 : parseInt(e.thumbhide);
                e.mh = e.mh === undefined || e.mh == "" || e.mh === "auto" ? 0 : parseInt(e.mh, 0);
                if (e.layout === "fullscreen" || e.l === "fullscreen")
                    newh = Math.max(e.mh, window.RSIH);
                else {
                    e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
                    for (var i in e.rl)
                        if (e.gw[i] === undefined || e.gw[i] === 0) e.gw[i] = e.gw[i - 1];
                    e.gh = e.el === undefined || e.el === "" || (Array.isArray(e.el) && e.el.length == 0) ? e.gh : e.el;
                    e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
                    for (var i in e.rl)
                        if (e.gh[i] === undefined || e.gh[i] === 0) e.gh[i] = e.gh[i - 1];

                    var nl = new Array(e.rl.length),
                        ix = 0,
                        sl;
                    e.tabw = e.tabhide >= pw ? 0 : e.tabw;
                    e.thumbw = e.thumbhide >= pw ? 0 : e.thumbw;
                    e.tabh = e.tabhide >= pw ? 0 : e.tabh;
                    e.thumbh = e.thumbhide >= pw ? 0 : e.thumbh;
                    for (var i in e.rl) nl[i] = e.rl[i] < window.RSIW ? 0 : e.rl[i];
                    sl = nl[0];
                    for (var i in nl)
                        if (sl > nl[i] && nl[i] > 0) {
                            sl = nl[i];
                            ix = i;
                        }
                    var m = pw > (e.gw[ix] + e.tabw + e.thumbw) ? 1 : (pw - (e.tabw + e.thumbw)) / (e.gw[ix]);
                    newh = (e.gh[ix] * m) + (e.tabh + e.thumbh);
                }
                var el = document.getElementById(e.c);
                if (el !== null && el) el.style.height = newh + "px";
                el = document.getElementById(e.c + "_wrapper");
                if (el !== null && el) {
                    el.style.height = newh + "px";
                    el.style.display = "block";
                }
            } catch (e) {
                console.log("Failure at Presize of Slider:" + e)
            }
            //});
        };
    </script>
    <style id='tmpcoder-elementor-globle-variables'>
        :root {
            --e-global-color-tmpcoderprimarycolor: #FBB200;
            --e-global-color-tmpcodersecondarycolor: #F22E3E;
            --e-global-color-tmpcoderaccentcolor: #777777;
            --e-global-color-tmpcoderbodybackgroundcolor: #FFFFFF;
            --e-global-color-tmpcoderthemecolor1: #111111;
            --e-global-color-tmpcoderthemecolor2: #FFFAED;
            --e-global-color-tmpcoderthemecolor4: #fff;
            --e-global-color-tmpcoderlinkcolor: #111111;
            --e-global-color-tmpcoderlinkhovercolor: #F22E3E;
            --e-global-color-tmpcoderglobalbordercolor: #E4DED9;
            --e-global-color-tmpcodersitefontscolor: #777777;
            --e-global-color-tmpcoderbuttonfontscolor: #fff;
            --e-global-color-tmpcoderbuttonfontshovercolor: #FFFFFF;
            --e-global-color-tmpcoderbuttonbackgroundcolor: #FBB200;
            --e-global-color-tmpcoderbuttonbackgroundhovercolor: #F22E3E;
            --e-global-color-tmpcoderbuttonbordercolor: #fbb200;
            --e-global-color-tmpcoderbuttonborderhovercolor: #f22e3e;
        }
    </style>
</head>

<body class="product-template-default single single-product postid-3190 wp-embed-responsive theme-pizzon woocommerce woocommerce-page woocommerce-no-js cfvsw-label-none cfvsw-product-page demo-01-pizzon-classic pizzon-default-theme elementor-default elementor-kit-28">

    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>

    <!-- Start preloader -->


    <div id="preloader">
        <div class="preloader">
            <img fetchpriority="high" class="alignnone size-full wp-image-70" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/preloader.svg" alt="" width="300" height="300" /> </div>
    </div>

    <?php

    session_start();

    include("includes/db.php");
    include("includes/header.php");
    include("functions/functions.php");
    include("includes/main.php");

    ?>
    <!-- End preloader -->

    <div data-elementor-type="wp-post" data-elementor-id="133" class="elementor elementor-133">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-70d3859 tmpcoder-custom-section-position-unset elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
            data-id="70d3859" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1785774 tmpcoder-custom-column-position-unset" data-id="1785774" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <section class="elementor-section elementor-inner-section elementor-element elementor-element-e1ec750 elementor-section-content-middle tmpcoder-custom-section-position-unset elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
                            data-id="e1ec750" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6a06a13 tmpcoder-custom-column-position-unset" data-id="6a06a13" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-3f159f6 elementor-invisible elementor-widget elementor-widget-tmpcoder-page-title" data-id="3f159f6" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInLeft&quot;}" data-widget_type="tmpcoder-page-title.default">
                                            <div class="elementor-widget-container">
                                                <h1 class="tmpcoder-post-title">Margherita pizza</h1>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-41cc842 elementor-widget__width-initial elementor-invisible elementor-widget elementor-widget-text-editor" data-id="41cc842" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInLeft&quot;}"
                                            data-widget_type="text-editor.default">
                                            <div class="elementor-widget-container">
                                                <style>
                                                    /*! elementor - v3.19.0 - 28-02-2024 */

                                                    .elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap {
                                                        background-color: #69727d;
                                                        color: #fff
                                                    }

                                                    .elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap {
                                                        color: #69727d;
                                                        border: 3px solid;
                                                        background-color: transparent
                                                    }

                                                    .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap {
                                                        margin-top: 8px
                                                    }

                                                    .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter {
                                                        width: 1em;
                                                        height: 1em
                                                    }

                                                    .elementor-widget-text-editor .elementor-drop-cap {
                                                        float: left;
                                                        text-align: center;
                                                        line-height: 1;
                                                        font-size: 50px
                                                    }

                                                    .elementor-widget-text-editor .elementor-drop-cap-letter {
                                                        display: inline-block
                                                    }
                                                </style> Lorem Ipsum is simply dummy text of the printing and typesetting industry. </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-90b4a5d tmpcoder-custom-column-position-unset" data-id="90b4a5d" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-18e1d79 elementor-invisible elementor-widget elementor-widget-Breadcrumb" data-id="18e1d79" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="Breadcrumb.default">
                                            <div class="elementor-widget-container">

                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="page-banner">

                                                            <h2 class="sub-banner-title notshow">Margherita pizza</h2>
                                                            <nav class="woocommerce-breadcrumb" aria-label="Breadcrumb"><span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02">Home</a></span> / <span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product-category/popular-dishes/">Popular Dishes</a></span>                                                                / <span>Margherita pizza</span></nav>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section class="elementor-section elementor-inner-section elementor-element elementor-element-26be0b5 elementor-section-content-middle tmpcoder-custom-section-position-unset elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
                            data-id="26be0b5" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-8ad0db6 tmpcoder-custom-column-position-unset" data-id="8ad0db6" data-element_type="column">
                                    <div class="elementor-widget-wrap elementor-element-populated">
                                        <div class="elementor-element elementor-element-f21970b elementor-widget__width-initial elementor-absolute elementor-widget-tablet__width-initial elementor-invisible elementor-widget elementor-widget-image" data-id="f21970b" data-element_type="widget"
                                            data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;fadeInRight&quot;,&quot;_animation_delay&quot;:0.5}" data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <style>
                                                    /*! elementor - v3.19.0 - 28-02-2024 */

                                                    .elementor-widget-image {
                                                        text-align: center
                                                    }

                                                    .elementor-widget-image a {
                                                        display: inline-block
                                                    }

                                                    .elementor-widget-image a img[src$=".svg"] {
                                                        width: 48px
                                                    }

                                                    .elementor-widget-image img {
                                                        vertical-align: middle;
                                                        display: inline-block
                                                    }
                                                </style> <img width="112" height="115" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion.png" class="attachment-full size-full wp-image-88" alt="" /> </div>
                                        </div>
                                        <div class="elementor-element elementor-element-0c6374e elementor-widget__width-initial elementor-absolute elementor-invisible elementor-widget elementor-widget-image" data-id="0c6374e" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:1}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img loading="lazy" width="97" height="99" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/tamato.png" class="attachment-full size-full wp-image-102" alt="" />                                                </div>
                                        </div>
                                        <div class="elementor-element elementor-element-8a545ae elementor-widget__width-initial elementor-absolute black-jam-img elementor-invisible elementor-widget elementor-widget-image" data-id="8a545ae" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;fadeInLeft&quot;,&quot;_animation_delay&quot;:2}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img loading="lazy" width="153" height="277" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/black-jamun.png" class="attachment-full size-full wp-image-87" alt="" />                                                </div>
                                        </div>
                                        <div class="elementor-element elementor-element-c2732a8 elementor-widget__width-initial elementor-absolute elementor-invisible elementor-widget elementor-widget-image" data-id="c2732a8" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;_animation&quot;:&quot;fadeInRight&quot;,&quot;_animation_delay&quot;:1.5}"
                                            data-widget_type="image.default">
                                            <div class="elementor-widget-container">
                                                <img loading="lazy" width="119" height="204" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/banner-leaf.png" class="attachment-full size-full wp-image-1576" alt="" />                                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-233ddebb elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
            data-id="233ddebb" data-element_type="section">
            <div class="elementor-container elementor-column-gap-no">
                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-56f2a408" data-id="56f2a408" data-element_type="column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element elementor-element-b483b30 tmpcoder-gallery-slider-nav-fade tmpcoder-product-media-thumbs-slider tmpcoder-gallery-lightbox-yes elementor-widget elementor-widget-tmpcoder-product-media" data-id="b483b30" data-element_type="widget"
                            data-widget_type="tmpcoder-product-media.default">
                            <div class="elementor-widget-container">
                                <div class="tmpcoder-product-media-wrap tmpcoder-product-media-thumbs-horizontal" data-slidestoshow="4" data-slidestoscroll="2" data-lightbox="{&quot;selector&quot;:&quot;.woocommerce-product-gallery__image&quot;,&quot;iframeMaxWidth&quot;:&quot;60%&quot;,&quot;hash&quot;:false,&quot;autoplay&quot;:&quot;true&quot;,&quot;pause&quot;:5000,&quot;progressBar&quot;:&quot;true&quot;,&quot;counter&quot;:&quot;true&quot;,&quot;controls&quot;:&quot;true&quot;,&quot;getCaptionFromTitleOrAlt&quot;:&quot;true&quot;,&quot;thumbnail&quot;:&quot;true&quot;,&quot;showThumbByDefault&quot;:&quot;true&quot;,&quot;share&quot;:&quot;true&quot;,&quot;zoom&quot;:&quot;true&quot;,&quot;fullScreen&quot;:&quot;true&quot;,&quot;download&quot;:&quot;true&quot;}">
                                    <div class="tmpcoder-product-media-lightbox"><i aria-hidden="true" class="fas fa-search"></i></div>
                                    <div class="tmpcoder-gallery-slider-arrows-wrap">
                                        <div class="tmpcoder-gallery-slider-prev-arrow tmpcoder-gallery-slider-arrow"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 303.3 512" style="enable-background:new 0 0 303.3 512;" xml:space="preserve"><g><polygon class="st0" points="94.7,256 303.3,464.6 256,512 47.3,303.4 0,256 47.3,208.6 256,0 303.3,47.4 "/></g></svg></div>
                                        <div
                                            class="tmpcoder-gallery-slider-next-arrow tmpcoder-gallery-slider-arrow"><svg style="transform: rotate(180deg); -webkit-transform: rotate(180deg);" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 303.3 512" style="enable-background:new 0 0 303.3 512;"
                                                xml:space="preserve"><g><polygon class="st0" points="94.7,256 303.3,464.6 256,512 47.3,303.4 0,256 47.3,208.6 256,0 303.3,47.4 "/></g></svg></div>
                                </div>
                                <div class="tmpcoder-thumbnail-slider-prev-arrow tmpcoder-tsa-hidden tmpcoder-thumbnail-slider-arrow"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 303.3 512" style="enable-background:new 0 0 303.3 512;" xml:space="preserve"><g><polygon class="st0" points="94.7,256 303.3,464.6 256,512 47.3,303.4 0,256 47.3,208.6 256,0 303.3,47.4 "/></g></svg></div>
                                <div
                                    class="tmpcoder-thumbnail-slider-next-arrow tmpcoder-tsa-hidden tmpcoder-thumbnail-slider-arrow"><svg style="transform: rotate(180deg); -webkit-transform: rotate(180deg);" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 303.3 512" style="enable-background:new 0 0 303.3 512;"
                                        xml:space="preserve"><g><polygon class="st0" points="94.7,256 303.3,464.6 256,512 47.3,303.4 0,256 47.3,208.6 256,0 303.3,47.4 "/></g></svg></div>
                            <div class="woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images"
                                data-columns="4" style="opacity: 0; transition: opacity .25s ease-in-out;">
                                <div class="woocommerce-product-gallery__wrapper">
                                    <div data-thumb="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion-100x100.jpg" data-thumb-alt="" class="woocommerce-product-gallery__image"><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion.jpg"><img loading="lazy" width="513" height="513" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion.jpg" class="wp-post-image" alt="" title="onion" data-caption="" data-src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion.jpg" data-large_image="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion.jpg" data-large_image_width="513" data-large_image_height="513" decoding="async" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion.jpg 513w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion-300x300.jpg 300w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion-150x150.jpg 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/onion-100x100.jpg 100w" sizes="(max-width: 513px) 100vw, 513px" /></a></div>
                                    <div
                                        data-thumb="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/mexicana-1-100x100.jpg" data-thumb-alt="" class="woocommerce-product-gallery__image"><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/mexicana-1.jpg"><img loading="lazy" width="513" height="513" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/mexicana-1.jpg" class="" alt="" title="mexicana" data-caption="" data-src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/mexicana-1.jpg" data-large_image="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/mexicana-1.jpg" data-large_image_width="513" data-large_image_height="513" decoding="async" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/mexicana-1.jpg 513w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/mexicana-1-300x300.jpg 300w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/mexicana-1-150x150.jpg 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/mexicana-1-100x100.jpg 100w" sizes="(max-width: 513px) 100vw, 513px" /></a></div>
                                <div
                                    data-thumb="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-1-100x100.jpg" data-thumb-alt="" class="woocommerce-product-gallery__image"><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-1.jpg"><img loading="lazy" width="513" height="513" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-1.jpg" class="" alt="" title="chesy-pizza" data-caption="" data-src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-1.jpg" data-large_image="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-1.jpg" data-large_image_width="513" data-large_image_height="513" decoding="async" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-1.jpg 513w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-1-300x300.jpg 300w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-1-150x150.jpg 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-1-100x100.jpg 100w" sizes="(max-width: 513px) 100vw, 513px" /></a></div>
                            <div
                                data-thumb="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-1-100x100.jpg" data-thumb-alt="" class="woocommerce-product-gallery__image"><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-1.jpg"><img loading="lazy" width="513" height="513" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-1.jpg" class="" alt="" title="pesto" data-caption="" data-src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-1.jpg" data-large_image="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-1.jpg" data-large_image_width="513" data-large_image_height="513" decoding="async" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-1.jpg 513w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-1-300x300.jpg 300w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-1-150x150.jpg 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-1-100x100.jpg 100w" sizes="(max-width: 513px) 100vw, 513px" /></a></div>
                        <div
                            data-thumb="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/2-1-100x100.png" data-thumb-alt="" class="woocommerce-product-gallery__image"><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/2-1.png"><img loading="lazy" width="200" height="200" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/2-1.png" class="" alt="" title="2-1.png" data-caption="" data-src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/2-1.png" data-large_image="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/2-1.png" data-large_image_width="200" data-large_image_height="200" decoding="async" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/2-1.png 200w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/2-1-150x150.png 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/2-1-100x100.png 100w" sizes="(max-width: 200px) 100vw, 200px" /></a></div>
                </div>
            </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4a7ce719" data-id="4a7ce719" data-element_type="column">
        <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-1737be0f elementor-widget elementor-widget-tmpcoderWooProductTitle" data-id="1737be0f" data-element_type="widget" data-widget_type="tmpcoderWooProductTitle.default">
                <div class="elementor-widget-container">
                    <style>
                        /*! elementor - v3.19.0 - 28-02-2024 */

                        .elementor-heading-title {
                            padding: 0;
                            margin: 0;
                            line-height: 1
                        }

                        .elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a {
                            color: inherit;
                            font-size: inherit;
                            line-height: inherit
                        }

                        .elementor-widget-heading .elementor-heading-title.elementor-size-small {
                            font-size: 15px
                        }

                        .elementor-widget-heading .elementor-heading-title.elementor-size-medium {
                            font-size: 19px
                        }

                        .elementor-widget-heading .elementor-heading-title.elementor-size-large {
                            font-size: 29px
                        }

                        .elementor-widget-heading .elementor-heading-title.elementor-size-xl {
                            font-size: 39px
                        }

                        .elementor-widget-heading .elementor-heading-title.elementor-size-xxl {
                            font-size: 59px
                        }
                    </style>
                    <h2 class="elementor-heading-title elementor-size-default">Margherita pizza</h2>
                </div>
            </div>
            <section class="elementor-section elementor-inner-section elementor-element elementor-element-2b18e248 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
                data-id="2b18e248" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3c746464" data-id="3c746464" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-759c8a83 elementor-widget elementor-widget-tmpcoderWooPrice" data-id="759c8a83" data-element_type="widget" data-widget_type="tmpcoderWooPrice.default">
                                <div class="elementor-widget-container">
                                    <p class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>45.00</bdi>
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-2a7db1e1" data-id="2a7db1e1" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-2587ff52 tmpcoder-pr-show-text-yes tmpcoder-product-rating-flex tmpcoder-product-rating-left elementor-widget elementor-widget-tmpcoder-product-rating" data-id="2587ff52" data-element_type="widget" data-widget_type="tmpcoder-product-rating.default">
                                <div class="elementor-widget-container">
                                    <div class="tmpcoder-product-rating">
                                        <div class="tmpcoder-woo-rating"><i class="tmpcoder-rating-icon-0">&#9734;</i><i class="tmpcoder-rating-icon-empty">&#9734;</i><i class="tmpcoder-rating-icon-empty">&#9734;</i><i class="tmpcoder-rating-icon-empty">&#9734;</i><i class="tmpcoder-rating-icon-empty">&#9734;</i></div>
                                        <a href="#reviews" class="woocommerce-review-link" rel="nofollow">
            <span class="count">0</span> Reviews        </a>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="elementor-element elementor-element-750c89f8 elementor-widget elementor-widget-tmpcoderWooShortDescription" data-id="750c89f8" data-element_type="widget" data-widget_type="tmpcoderWooShortDescription.default">
                <div class="elementor-widget-container">
                    <div class="woocommerce-product-details__short-description">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Semper sagittis dolor aliquet quam feugiat nisi a ultrices feugiat. Viverra facilisi turpis eget tempor. Mattis risus amet euismod eleifend.</p>
                    </div>
                </div>
            </div>
            <div class="elementor-element elementor-element-4578fe54 wpr-product-meta-column wpr-product-meta-left wpr-product-meta-cat-yes wpr-product-meta-tag-yes elementor-widget elementor-widget-tmpcoder-product-meta" data-id="4578fe54" data-element_type="widget"
                data-widget_type="tmpcoder-product-meta.default">
                <div class="elementor-widget-container">
                    <div class="wpr-product-meta">
                        <div class="product_meta">



                            <span class="posted_in">Categories: <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product-category/pizzas/" rel="tag">Pizzas</a>, <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product-category/popular-dishes/" rel="tag">Popular Dishes</a></span>
                            <span class="tagged_as">Tags: <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product-tag/margherita/" rel="tag">Margherita</a>, <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product-tag/pizza/" rel="tag">pizza</a>, <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product-tag/spicy/" rel="tag">spicy</a></span>

                        </div>
                    </div>
                </div>
            </div>
            <section class="elementor-section elementor-inner-section elementor-element elementor-element-1d24f3f1 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
                data-id="1d24f3f1" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6bf2e74b" data-id="6bf2e74b" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-6f679d87 tmpcoder-product-adc-align-center tmpcoder-add-to-cart-layout-column tmpcoder-product-adc-align-left tmpcoder-variations-layout-column tmpcoder-buttons-layout-row tmpcoder-product-qty-align-after elementor-widget elementor-widget-tmpcoderWooAddToCart"
                                data-id="6f679d87" data-element_type="widget" data-widget_type="tmpcoderWooAddToCart.default">
                                <div class="elementor-widget-container">
                                    <div id="add-to-cart-attributes" class="tmpcoder-product-add-to-cart tmpcoder-up-down-icon" layout-settings="after" data-ajax-add-to-cart="yes">

                                        <form class="cart" action="https://themes.templatescoder.com/pizzon/wp/demo-02/product/margherita-pizza/" method="post" enctype='multipart/form-data'>

                                            <div class="tmpcoder-simple-qty-wrap">
                                                <div class="tmpcoder-quantity-wrapper">
                                                    <div class="quantity">
                                                        <label class="screen-reader-text" for="quantity_66615163b44dc">Margherita pizza quantity</label>
                                                        <input type="number" id="quantity_66615163b44dc" class="input-text qty text" name="quantity" value="1" aria-label="Product quantity" size="4" min="1" max="" step="1" placeholder="" inputmode="numeric" autocomplete="off" />
                                                    </div>
                                                    <div class="tmpcoder-add-to-cart-icons-wrap"><i class="fas fa-angle-up"></i><i class="fas fa-angle-down"></i></i>
                                                    </div>
                                                </div>
                                                <button type="submit" name="add-to-cart" value="3190" class="single_add_to_cart_button button alt"><span class="elementor-button-content-wrapper"><span class="elementor-button-text">Add to Cart</span></span></button>

                                            </div>
                                        </form>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4ad309e2" data-id="4ad309e2" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-22bb854d elementor-widget__width-auto elementor-widget elementor-widget-wlfmc-add-to-wish-list" data-id="22bb854d" data-element_type="widget" data-widget_type="wlfmc-add-to-wish-list.default">
                                <div class="elementor-widget-container">
                                    <div class="wlfmc-add-to-wishlist wlfmc-add-to-wishlist-3190  wlfmc-single-btn is-elementor wlfmc-btn-type-icon show-remove-after-add " data-remove-url="?remove_from_wishlist=#product_id" data-add-url="?add_to_wishlist=#product_id" data-enable-outofstock="1"
                                        data-popup-id="add_to_wishlist_popup_3190_1">


                                        <!-- ADD TO WISHLIST -->
                                        <div class="wlfmc-add-button  wlfmc-addtowishlist " data-tooltip-text=" Wishlist" data-tooltip-type="custom">
                                            <a href="#" rel="nofollow" data-product-id="3190" data-product-type="simple" data-parent-product-id="3190" data-e-disable-page-transition class="wlfmc_add_to_wishlist wlfmc-custom-btn alt ">
				<i class="wlfmc-svg"><?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="e-font-icon-svg e-far-heart" viewBox="0 0 512 512">
  <path d="M458.4 64.3C400.6 15.7 311.3 23 256 79.3 200.7 23 111.4 15.6 53.6 64.3-21.6 127.6-10.6 230.8 43 285.5l175.4 178.7c10 10.2 23.4 15.9 37.6 15.9 14.3 0 27.6-5.6 37.6-15.8L469 285.6c53.5-54.7 64.7-157.9-10.6-221.3zm-23.6 187.5L259.4 430.5c-2.4 2.4-4.4 2.4-6.8 0L77.2 251.8c-36.5-37.2-43.9-107.6 7.3-150.7 38.9-32.7 98.9-27.8 136.5 10.5l35 35.7 35-35.7c37.8-38.5 97.8-43.2 136.5-10.6 51.1 43.1 43.5 113.9 7.3 150.8z"></path>
</svg>
</i>			</a>
                                        </div>
                                        <!-- REMOVE FROM WISHLIST -->
                                        <div class="wlfmc-add-button  wlfmc-removefromwishlist " data-tooltip-type="custom" data-tooltip-text="Remove From Wishlist">
                                            <a href="#" rel="nofollow" data-wishlist-id="" data-item-id="" data-product-id="3190" data-product-type="simple" data-parent-product-id="3190" data-e-disable-page-transition class="wlfmc_delete_item  wlfmc-custom-btn alt ">
					<i class="wlfmc-svg"><?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="e-font-icon-svg e-fas-heart" viewBox="0 0 512 512">
  <path d="M462.3 62.6C407.5 15.9 326 24.3 275.7 76.2L256 96.5l-19.7-20.3C186.1 24.3 104.5 15.9 49.7 62.6c-62.8 53.6-66.1 149.8-9.9 207.9l193.5 199.8c12.5 12.9 32.8 12.9 45.3 0l193.5-199.8c56.3-58.1 53-154.3-9.8-207.9z"></path>
</svg>
</i>				</a>
                                        </div>

                                        <!-- WISHLIST POPUP -->
                                        <div class="wlfmc-popup wlfmc-wishlist-popup auto-init size-large" data-horizontal="center" data-vertical="center" data-use-featured="" data-image-size="medium" data-product-title="Margherita pizza" id="add_to_wishlist_popup_3190_1">
                                            <div class="wlfmc-popup-content">
                                                <span class="wlfmc-popup-header-bordered f-center-item space-between">
						<span class="d-flex f-center-item gap-10">
							<i class="wlfmc-svg"><?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="e-font-icon-svg e-far-heart" viewBox="0 0 512 512">
  <path d="M458.4 64.3C400.6 15.7 311.3 23 256 79.3 200.7 23 111.4 15.6 53.6 64.3-21.6 127.6-10.6 230.8 43 285.5l175.4 178.7c10 10.2 23.4 15.9 37.6 15.9 14.3 0 27.6-5.6 37.6-15.8L469 285.6c53.5-54.7 64.7-157.9-10.6-221.3zm-23.6 187.5L259.4 430.5c-2.4 2.4-4.4 2.4-6.8 0L77.2 251.8c-36.5-37.2-43.9-107.6 7.3-150.7 38.9-32.7 98.9-27.8 136.5 10.5l35 35.7 35-35.7c37.8-38.5 97.8-43.2 136.5-10.6 51.1 43.1 43.5 113.9 7.3 150.8z"></path>
</svg>
</i>							<span class="wlfmc-popup-title">Added to Wishlist</span>
                                                </span>
                                                <a class="wlfmc-popup-close" data-popup-id="add_to_wishlist_popup_3190_1" href="#"><i class="wlfmc-icon-close"></i></a>
                                                </span>
                                                <div class="wlfmc-popup-header">
                                                    <figure>
                                                        <img loading="lazy" data-src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/wish-check-1.png" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/wish-check-1.png" alt="Added to Wishlist"
                                                        />
                                                    </figure>
                                                </div>
                                                <div class="wlfmc-parent-product-price hide" style="display:none"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#8377;</span>45.00</span>
                                                </div>
                                                <div class="wlfmc-popup-desc">
                                                    <p>See your favorite product on Wishlist</p>
                                                </div>
                                            </div>
                                            <div class="wlfmc-popup-footer">
                                                <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/wishlist/" class="wlfmc-btn wlfmc_btn_0">View My Wishlist</a> <a href="#" class="wlfmc-popup-close wlfmc-btn wlfmc-popup-close wlfmc_btn_1" data-popup-id="add_to_wishlist_popup_3190_1">Close</a>                                                </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    </div>
    </section>
    <section class="elementor-section elementor-top-section elementor-element elementor-element-42e83a0c elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
        data-id="42e83a0c" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
        <div class="elementor-container elementor-column-gap-default">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-67880893" data-id="67880893" data-element_type="column">
                <div class="elementor-widget-wrap elementor-element-populated">
                    <div class="elementor-element elementor-element-1e55977a tmpcoder-tabs-position-above tmpcoder-forms-submit-left elementor-widget elementor-widget-tmpcoder-product-tabs" data-id="1e55977a" data-element_type="widget" data-settings="{&quot;tab_transition_duration&quot;:0.5}"
                        data-widget_type="tmpcoder-product-tabs.default">
                        <div class="elementor-widget-container">
                            <div class="tmpcoder-product-tabs">
                                <div class="woocommerce-tabs wc-tabs-wrapper">
                                    <ul class="tabs wc-tabs" role="tablist">
                                        <li class="description_tab" id="tab-title-description" role="tab" aria-controls="tab-description">
                                            <a href="#tab-description">
						Description					</a>
                                        </li>
                                        <li class="reviews_tab" id="tab-title-reviews" role="tab" aria-controls="tab-reviews">
                                            <a href="#tab-reviews">
						Reviews (0)					</a>
                                        </li>
                                    </ul>
                                    <div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--description panel entry-content wc-tab" id="tab-description" role="tabpanel" aria-labelledby="tab-title-description">

                                        <h2>Description</h2>

                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex
                                            ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
                                            mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto
                                            beatae vitae dicta sunt explicabo.</p>
                                        <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit
                                            amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                                    </div>
                                    <div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--reviews panel entry-content wc-tab" id="tab-reviews" role="tabpanel" aria-labelledby="tab-title-reviews">
                                        <div id="reviews" class="woocommerce-Reviews">
                                            <div id="comments">
                                                <h2 class="woocommerce-Reviews-title">
                                                    Reviews </h2>

                                                <p class="woocommerce-noreviews">There are no reviews yet.</p>
                                            </div>

                                            <div id="review_form_wrapper">
                                                <div id="review_form">
                                                    <div id="respond" class="comment-respond">
                                                        <span id="reply-title" class="comment-reply-title">Be the first to review &ldquo;Margherita pizza&rdquo; <small><a rel="nofollow" id="cancel-comment-reply-link" href="/pizzon/wp/demo-02/product/margherita-pizza/#respond" style="display:none;">Cancel reply</a></small></span>
                                                        <form
                                                            action="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-comments-post.php" method="post" id="commentform" class="comment-form">
                                                            <div class="comment-form-rating"><label for="rating">Your rating&nbsp;<span class="required">*</span></label><select name="rating" id="rating" required>
						<option value="">Rate&hellip;</option>
						<option value="5">Perfect</option>
						<option value="4">Good</option>
						<option value="3">Average</option>
						<option value="2">Not that bad</option>
						<option value="1">Very poor</option>
					</select></div>
                                                            <p class="comment-form-comment"><label for="comment">Your review&nbsp;<span class="required">*</span></label><textarea id="comment" name="comment" cols="45" rows="8" required></textarea></p>
                                                            <p class="comment-form-author"><label for="author">Name&nbsp;<span class="required">*</span></label><input id="author" name="author" type="text" value="" size="30" required /></p>
                                                            <p class="comment-form-email"><label for="email">Email&nbsp;<span class="required">*</span></label><input id="email" name="email" type="email" value="" size="30" required /></p>
                                                            <p class="comment-form-cookies-consent"><input id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes" /> <label for="wp-comment-cookies-consent">Save my name, email, and website in this browser for the next time I comment.</label></p>
                                                            <p class="form-submit"><span class="elementor-button-wrapper"><button class="btn elementor-button-link">Submit</button></span> <input type='hidden' name='comment_post_ID' value='3190' id='comment_post_ID' />
                                                                <input type='hidden' name='comment_parent' id='comment_parent' value='0' />
                                                            </p>
                                                            </form>
                                                    </div>
                                                    <!-- #respond -->
                                                </div>
                                            </div>

                                            <div class="clear"></div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <script>
                                // elementorFrontend.hooks.addAction( 'frontend/element_ready/tmpcoder-product-tabs.default', function( $scope ) {
                                // 	$scope.find('.description_tab a').trigger('click');

                                // 	if ( !$scope.find('p.stars').length ) {
                                // 		$scope.find('#rating').hide();
                                // 		$scope.find('#rating').before('<p class="stars"><span><a class="star-1" href="#">1</a><a class="star-2" href="#">2</a><a class="star-3" href="#">3</a><a class="star-4" href="#">4</a><a class="star-5" href="#">5</a></span></p>');
                                // 	}
                                // } );
                            </script>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="elementor-section elementor-top-section elementor-element elementor-element-2db96afb elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
        data-id="2db96afb" data-element_type="section">
        <div class="elementor-container elementor-column-gap-no">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2309d4bf" data-id="2309d4bf" data-element_type="column">
                <div class="elementor-widget-wrap elementor-element-populated">
                    <div class="elementor-element elementor-element-192173de elementor-product-loop-item--align-left elementor-grid-mobile-1 elementor-grid-3 tmpcoder-layout-type-modern elementor-grid-tablet-2 elementor-products-grid elementor-wc-products show-heading-yes elementor-widget elementor-widget-tmpcoder-related-product"
                        data-id="192173de" data-element_type="widget" data-widget_type="tmpcoder-related-product.default">
                        <div class="elementor-widget-container">

                            <section class="related products">

                                <h2>Related products</h2>

                                <ul class="products elementor-grid columns-4">


                                    <li class="product type-product post-3198 status-publish first instock product_cat-pizzas product_cat-popular-dishes product_tag-pizza product_tag-truffle has-post-thumbnail shipping-taxable purchasable product-type-simple">
                                        <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product/pestovas-pizza/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img loading="lazy" width="300" height="300" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-300x300.jpg" class="attachment-woocommerce_thumbnail elementor-animation-grow size-woocommerce_thumbnail" alt="" decoding="async" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-300x300.jpg 300w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-150x150.jpg 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto-100x100.jpg 100w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/pesto.jpg 513w" sizes="(max-width: 300px) 100vw, 300px" /><div class="product-detail-section"><h2 class="woocommerce-loop-product__title">Pestovas Pizza</h2>	        <div itemprop="description" class="tmpcoder-related-description">
	           <p>Lorem ipsum dolor sit amet, consectetur adipiscing 	        </div>
		
	<span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>85.00</bdi></span></span>
</div></a><a href="?add-to-cart=3198" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="3198" data-product_sku="" aria-label="Add to cart: &ldquo;Pestovas Pizza&rdquo;"
                                            aria-describedby="" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="OBJECTS" x="0px" y="0px" viewBox="0 0 383.71 380.06" xml:space="preserve"><g>	<path d="M380.39,97.23c-2.96-3.82-7.51-6.04-12.31-6.04H88.46l-19.44-79.2C67.3,4.95,61.04,0,53.87,0H15.63C6.99,0,0,7.07,0,15.78  c0,8.72,6.99,15.78,15.63,15.78h25.99l64.16,261.32c0.43,1.77,1.15,3.4,2.1,4.86c0.61,0.93,1.43,1.65,2.21,2.42  c0.44,0.43,0.77,0.98,1.25,1.36c1.23,0.97,2.63,1.69,4.09,2.25c0.13,0.05,0.23,0.15,0.23,0.15c1.77,0.63,3.49,0.94,5.27,0.94  l0.12-0.01h202.3c7.19,0,13.45-4.93,15.18-11.98l44.7-182.13C384.41,106.04,383.35,101.06,380.39,97.23z M311.13,273.3H133.18  L96.22,122.75H348.1L311.13,273.3z"></path>	<path d="M135.43,327.78L135.43,327.78c-14.31,0-25.9,11.7-25.9,26.14c0,14.43,11.59,26.14,25.89,26.14h0  c14.3,0,25.89-11.7,25.89-26.14C161.32,339.48,149.73,327.78,135.43,327.78z"></path>	<path d="M308.95,327.78L308.95,327.78c-14.31,0-25.9,11.7-25.9,26.14c0,14.43,11.59,26.14,25.9,26.14h0  c14.3,0,25.89-11.7,25.89-26.14C334.84,339.48,323.25,327.78,308.95,327.78z"></path></g></svg>Order Now</a></li>


                                    <li class="product type-product post-3193 status-publish instock product_cat-popular-dishes product_cat-slides product_tag-fries product_tag-mayo has-post-thumbnail shipping-taxable purchasable product-type-simple">
                                        <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product/french-mayos/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img loading="lazy" width="300" height="300" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french-300x300.jpg" class="attachment-woocommerce_thumbnail elementor-animation-grow size-woocommerce_thumbnail" alt="" decoding="async" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french-300x300.jpg 300w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french-150x150.jpg 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french-100x100.jpg 100w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/french.jpg 513w" sizes="(max-width: 300px) 100vw, 300px" /><div class="product-detail-section"><h2 class="woocommerce-loop-product__title">French mayos</h2>	        <div itemprop="description" class="tmpcoder-related-description">
	           <p>Lorem ipsum dolor sit amet, consectetur adipiscing 	        </div>
		
	<span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>65.00</bdi></span></span>
</div></a><a href="?add-to-cart=3193" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="3193" data-product_sku="" aria-label="Add to cart: &ldquo;French mayos&rdquo;"
                                            aria-describedby="" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="OBJECTS" x="0px" y="0px" viewBox="0 0 383.71 380.06" xml:space="preserve"><g>	<path d="M380.39,97.23c-2.96-3.82-7.51-6.04-12.31-6.04H88.46l-19.44-79.2C67.3,4.95,61.04,0,53.87,0H15.63C6.99,0,0,7.07,0,15.78  c0,8.72,6.99,15.78,15.63,15.78h25.99l64.16,261.32c0.43,1.77,1.15,3.4,2.1,4.86c0.61,0.93,1.43,1.65,2.21,2.42  c0.44,0.43,0.77,0.98,1.25,1.36c1.23,0.97,2.63,1.69,4.09,2.25c0.13,0.05,0.23,0.15,0.23,0.15c1.77,0.63,3.49,0.94,5.27,0.94  l0.12-0.01h202.3c7.19,0,13.45-4.93,15.18-11.98l44.7-182.13C384.41,106.04,383.35,101.06,380.39,97.23z M311.13,273.3H133.18  L96.22,122.75H348.1L311.13,273.3z"></path>	<path d="M135.43,327.78L135.43,327.78c-14.31,0-25.9,11.7-25.9,26.14c0,14.43,11.59,26.14,25.89,26.14h0  c14.3,0,25.89-11.7,25.89-26.14C161.32,339.48,149.73,327.78,135.43,327.78z"></path>	<path d="M308.95,327.78L308.95,327.78c-14.31,0-25.9,11.7-25.9,26.14c0,14.43,11.59,26.14,25.9,26.14h0  c14.3,0,25.89-11.7,25.89-26.14C334.84,339.48,323.25,327.78,308.95,327.78z"></path></g></svg>Order Now</a></li>


                                    <li class="product type-product post-3194 status-publish instock product_cat-pizzas product_tag-mexican product_tag-pizza has-post-thumbnail shipping-taxable purchasable product-type-simple">
                                        <a href="https://themes.templatescoder.com/pizzon/wp/demo-02/product/mexicana-pizza/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img loading="lazy" width="300" height="300" src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-300x300.jpg" class="attachment-woocommerce_thumbnail elementor-animation-grow size-woocommerce_thumbnail" alt="" decoding="async" srcset="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-300x300.jpg 300w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-150x150.jpg 150w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1-100x100.jpg 100w, https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/11/chesy-pizza-1.jpg 513w" sizes="(max-width: 300px) 100vw, 300px" /><div class="product-detail-section"><h2 class="woocommerce-loop-product__title">Mexicana pizza</h2>	        <div itemprop="description" class="tmpcoder-related-description">
	           <p>Lorem ipsum dolor sit amet, consectetur adipiscing 	        </div>
		
	<span class="price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">&#8377;</span>45.00</bdi></span></span>
</div></a><a href="?add-to-cart=3194" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="3194" data-product_sku="" aria-label="Add to cart: &ldquo;Mexicana pizza&rdquo;"
                                            aria-describedby="" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="OBJECTS" x="0px" y="0px" viewBox="0 0 383.71 380.06" xml:space="preserve"><g>	<path d="M380.39,97.23c-2.96-3.82-7.51-6.04-12.31-6.04H88.46l-19.44-79.2C67.3,4.95,61.04,0,53.87,0H15.63C6.99,0,0,7.07,0,15.78  c0,8.72,6.99,15.78,15.63,15.78h25.99l64.16,261.32c0.43,1.77,1.15,3.4,2.1,4.86c0.61,0.93,1.43,1.65,2.21,2.42  c0.44,0.43,0.77,0.98,1.25,1.36c1.23,0.97,2.63,1.69,4.09,2.25c0.13,0.05,0.23,0.15,0.23,0.15c1.77,0.63,3.49,0.94,5.27,0.94  l0.12-0.01h202.3c7.19,0,13.45-4.93,15.18-11.98l44.7-182.13C384.41,106.04,383.35,101.06,380.39,97.23z M311.13,273.3H133.18  L96.22,122.75H348.1L311.13,273.3z"></path>	<path d="M135.43,327.78L135.43,327.78c-14.31,0-25.9,11.7-25.9,26.14c0,14.43,11.59,26.14,25.89,26.14h0  c14.3,0,25.89-11.7,25.89-26.14C161.32,339.48,149.73,327.78,135.43,327.78z"></path>	<path d="M308.95,327.78L308.95,327.78c-14.31,0-25.9,11.7-25.9,26.14c0,14.43,11.59,26.14,25.9,26.14h0  c14.3,0,25.89-11.7,25.89-26.14C334.84,339.48,323.25,327.78,308.95,327.78z"></path></g></svg>Order Now</a></li>


                                </ul>

                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>
    <footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
        <div class='footer-width-fixer'>
            <div data-elementor-type="wp-post" data-elementor-id="152" class="elementor elementor-152">
                <section class="elementor-section elementor-top-section elementor-element elementor-element-215093a tmpcoder-custom-section-position-unset footer-box elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
                    data-id="215093a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-background-overlay"></div>
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-71c006ed tmpcoder-custom-column-position-unset elementor-invisible" data-id="71c006ed" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <section class="elementor-section elementor-inner-section elementor-element elementor-element-93f2363 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
                                    data-id="93f2363" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-035da0e tmpcoder-custom-column-position-unset" data-id="035da0e" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-823765c elementor-widget elementor-widget-heading" data-id="823765c" data-element_type="widget" data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h6 class="elementor-heading-title elementor-size-default">Information</h6>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-bea3305 tmpcoder-navigation-menu__breakpoint-none tmpcoder-navigation-menu__align-left tmpcoder-submenu-icon-arrow tmpcoder-link-redirect-child elementor-widget elementor-widget-navigation-menu" data-id="bea3305"
                                                    data-element_type="widget" data-settings="{&quot;padding_horizontal_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:13,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;dropdown_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;padding_horizontal_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}"
                                                    data-widget_type="navigation-menu.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="tmpcoder-navigation-menu tmpcoder-layout-vertical tmpcoder-navigation-menu-layout vertical" data-layout="vertical">
                                                            <div class="tmpcoder-navigation-menu__toggle elementor-clickable">
                                                                <div class="tmpcoder-navigation-menu-icon">
                                                                </div>
                                                            </div>
                                                            <nav class="tmpcoder-navigation-menu__layout-vertical tmpcoder-navigation-menu__submenu-arrow" data-toggle-icon="" data-close-icon="" data-full-width="">
                                                                <ul id="menu-1-bea3305" class="tmpcoder-navigation-menu">
                                                                    <li id="menu-item-2393" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/" class="tmpcoder-menu-item">Home</a></li>
                                                                    <li id="menu-item-2394" class="menu-item menu-item-type-post_type menu-item-object-page parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/blog-left/" class="tmpcoder-menu-item">Blog</a></li>
                                                                    <li id="menu-item-2395" class="menu-item menu-item-type-post_type menu-item-object-page parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/about-us/" class="tmpcoder-menu-item">About Us</a></li>
                                                                    <li id="menu-item-2396" class="menu-item menu-item-type-post_type menu-item-object-page parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/our-menu/" class="tmpcoder-menu-item">Menu</a></li>
                                                                    <li id="menu-item-2397" class="menu-item menu-item-type-post_type menu-item-object-page parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/contact/" class="tmpcoder-menu-item">Contact Us</a></li>
                                                                </ul>
                                                            </nav>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6273cd8" data-id="6273cd8" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-2688478 elementor-widget elementor-widget-heading" data-id="2688478" data-element_type="widget" data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h6 class="elementor-heading-title elementor-size-default">Top Items</h6>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-363c62e tmpcoder-navigation-menu__breakpoint-none tmpcoder-navigation-menu__align-left tmpcoder-submenu-icon-arrow tmpcoder-link-redirect-child elementor-widget elementor-widget-navigation-menu" data-id="363c62e"
                                                    data-element_type="widget" data-settings="{&quot;padding_horizontal_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:13,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;dropdown_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;padding_horizontal_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}"
                                                    data-widget_type="navigation-menu.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="tmpcoder-navigation-menu tmpcoder-layout-vertical tmpcoder-navigation-menu-layout vertical" data-layout="vertical">
                                                            <div class="tmpcoder-navigation-menu__toggle elementor-clickable">
                                                                <div class="tmpcoder-navigation-menu-icon">
                                                                </div>
                                                            </div>
                                                            <nav class="tmpcoder-navigation-menu__layout-vertical tmpcoder-navigation-menu__submenu-arrow" data-toggle-icon="" data-close-icon="" data-full-width="">
                                                                <ul id="menu-1-363c62e" class="tmpcoder-navigation-menu">
                                                                    <li id="menu-item-197" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Pepperoni</a></li>
                                                                    <li id="menu-item-198" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Swiss Mushroom</a></li>
                                                                    <li id="menu-item-199" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Barbeque Chicken</a></li>
                                                                    <li id="menu-item-200" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Vegetarian</a></li>
                                                                    <li id="menu-item-201" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Ham &#038; Cheese</a></li>
                                                                </ul>
                                                            </nav>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6e13fc7" data-id="6e13fc7" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-e23f6bd elementor-widget elementor-widget-heading" data-id="e23f6bd" data-element_type="widget" data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h6 class="elementor-heading-title elementor-size-default">Others</h6>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-b9cb786 tmpcoder-navigation-menu__breakpoint-none tmpcoder-navigation-menu__align-left tmpcoder-submenu-icon-arrow tmpcoder-link-redirect-child elementor-widget elementor-widget-navigation-menu" data-id="b9cb786"
                                                    data-element_type="widget" data-settings="{&quot;padding_horizontal_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:13,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;dropdown_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;padding_horizontal_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}"
                                                    data-widget_type="navigation-menu.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="tmpcoder-navigation-menu tmpcoder-layout-vertical tmpcoder-navigation-menu-layout vertical" data-layout="vertical">
                                                            <div class="tmpcoder-navigation-menu__toggle elementor-clickable">
                                                                <div class="tmpcoder-navigation-menu-icon">
                                                                </div>
                                                            </div>
                                                            <nav class="tmpcoder-navigation-menu__layout-vertical tmpcoder-navigation-menu__submenu-arrow" data-toggle-icon="" data-close-icon="" data-full-width="">
                                                                <ul id="menu-1-b9cb786" class="tmpcoder-navigation-menu">
                                                                    <li id="menu-item-1522" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Checkout</a></li>
                                                                    <li id="menu-item-1523" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Cart</a></li>
                                                                    <li id="menu-item-1524" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Product</a></li>
                                                                    <li id="menu-item-1525" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Locations</a></li>
                                                                    <li id="menu-item-2390" class="menu-item menu-item-type-post_type menu-item-object-page parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/my-account/" class="tmpcoder-menu-item">My account</a></li>
                                                                </ul>
                                                            </nav>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-be75a99 tmpcoder-custom-column-position-unset" data-id="be75a99" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-815f99e elementor-widget elementor-widget-heading" data-id="815f99e" data-element_type="widget" data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h6 class="elementor-heading-title elementor-size-default">Social Media</h6>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-8d4291c e-grid-align-left elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="8d4291c" data-element_type="widget" data-widget_type="social-icons.default">
                                                    <div class="elementor-widget-container">
                                                        <style>
                                                            /*! elementor - v3.19.0 - 28-02-2024 */

                                                            .elementor-widget-social-icons.elementor-grid-0 .elementor-widget-container,
                                                            .elementor-widget-social-icons.elementor-grid-mobile-0 .elementor-widget-container,
                                                            .elementor-widget-social-icons.elementor-grid-tablet-0 .elementor-widget-container {
                                                                line-height: 1;
                                                                font-size: 0
                                                            }

                                                            .elementor-widget-social-icons:not(.elementor-grid-0):not(.elementor-grid-tablet-0):not(.elementor-grid-mobile-0) .elementor-grid {
                                                                display: inline-grid
                                                            }

                                                            .elementor-widget-social-icons .elementor-grid {
                                                                grid-column-gap: var(--grid-column-gap, 5px);
                                                                grid-row-gap: var(--grid-row-gap, 5px);
                                                                grid-template-columns: var(--grid-template-columns);
                                                                justify-content: var(--justify-content, center);
                                                                justify-items: var(--justify-content, center)
                                                            }

                                                            .elementor-icon.elementor-social-icon {
                                                                font-size: var(--icon-size, 25px);
                                                                line-height: var(--icon-size, 25px);
                                                                width: calc(var(--icon-size, 25px) + 2 * var(--icon-padding, .5em));
                                                                height: calc(var(--icon-size, 25px) + 2 * var(--icon-padding, .5em))
                                                            }

                                                            .elementor-social-icon {
                                                                --e-social-icon-icon-color: #fff;
                                                                display: inline-flex;
                                                                background-color: #69727d;
                                                                align-items: center;
                                                                justify-content: center;
                                                                text-align: center;
                                                                cursor: pointer
                                                            }

                                                            .elementor-social-icon i {
                                                                color: var(--e-social-icon-icon-color)
                                                            }

                                                            .elementor-social-icon svg {
                                                                fill: var(--e-social-icon-icon-color)
                                                            }

                                                            .elementor-social-icon:last-child {
                                                                margin: 0
                                                            }

                                                            .elementor-social-icon:hover {
                                                                opacity: .9;
                                                                color: #fff
                                                            }

                                                            .elementor-social-icon-android {
                                                                background-color: #a4c639
                                                            }

                                                            .elementor-social-icon-apple {
                                                                background-color: #999
                                                            }

                                                            .elementor-social-icon-behance {
                                                                background-color: #1769ff
                                                            }

                                                            .elementor-social-icon-bitbucket {
                                                                background-color: #205081
                                                            }

                                                            .elementor-social-icon-codepen {
                                                                background-color: #000
                                                            }

                                                            .elementor-social-icon-delicious {
                                                                background-color: #39f
                                                            }

                                                            .elementor-social-icon-deviantart {
                                                                background-color: #05cc47
                                                            }

                                                            .elementor-social-icon-digg {
                                                                background-color: #005be2
                                                            }

                                                            .elementor-social-icon-dribbble {
                                                                background-color: #ea4c89
                                                            }

                                                            .elementor-social-icon-elementor {
                                                                background-color: #d30c5c
                                                            }

                                                            .elementor-social-icon-envelope {
                                                                background-color: #ea4335
                                                            }

                                                            .elementor-social-icon-facebook,
                                                            .elementor-social-icon-facebook-f {
                                                                background-color: #3b5998
                                                            }

                                                            .elementor-social-icon-flickr {
                                                                background-color: #0063dc
                                                            }

                                                            .elementor-social-icon-foursquare {
                                                                background-color: #2d5be3
                                                            }

                                                            .elementor-social-icon-free-code-camp,
                                                            .elementor-social-icon-freecodecamp {
                                                                background-color: #006400
                                                            }

                                                            .elementor-social-icon-github {
                                                                background-color: #333
                                                            }

                                                            .elementor-social-icon-gitlab {
                                                                background-color: #e24329
                                                            }

                                                            .elementor-social-icon-globe {
                                                                background-color: #69727d
                                                            }

                                                            .elementor-social-icon-google-plus,
                                                            .elementor-social-icon-google-plus-g {
                                                                background-color: #dd4b39
                                                            }

                                                            .elementor-social-icon-houzz {
                                                                background-color: #7ac142
                                                            }

                                                            .elementor-social-icon-instagram {
                                                                background-color: #262626
                                                            }

                                                            .elementor-social-icon-jsfiddle {
                                                                background-color: #487aa2
                                                            }

                                                            .elementor-social-icon-link {
                                                                background-color: #818a91
                                                            }

                                                            .elementor-social-icon-linkedin,
                                                            .elementor-social-icon-linkedin-in {
                                                                background-color: #0077b5
                                                            }

                                                            .elementor-social-icon-medium {
                                                                background-color: #00ab6b
                                                            }

                                                            .elementor-social-icon-meetup {
                                                                background-color: #ec1c40
                                                            }

                                                            .elementor-social-icon-mixcloud {
                                                                background-color: #273a4b
                                                            }

                                                            .elementor-social-icon-odnoklassniki {
                                                                background-color: #f4731c
                                                            }

                                                            .elementor-social-icon-pinterest {
                                                                background-color: #bd081c
                                                            }

                                                            .elementor-social-icon-product-hunt {
                                                                background-color: #da552f
                                                            }

                                                            .elementor-social-icon-reddit {
                                                                background-color: #ff4500
                                                            }

                                                            .elementor-social-icon-rss {
                                                                background-color: #f26522
                                                            }

                                                            .elementor-social-icon-shopping-cart {
                                                                background-color: #4caf50
                                                            }

                                                            .elementor-social-icon-skype {
                                                                background-color: #00aff0
                                                            }

                                                            .elementor-social-icon-slideshare {
                                                                background-color: #0077b5
                                                            }

                                                            .elementor-social-icon-snapchat {
                                                                background-color: #fffc00
                                                            }

                                                            .elementor-social-icon-soundcloud {
                                                                background-color: #f80
                                                            }

                                                            .elementor-social-icon-spotify {
                                                                background-color: #2ebd59
                                                            }

                                                            .elementor-social-icon-stack-overflow {
                                                                background-color: #fe7a15
                                                            }

                                                            .elementor-social-icon-steam {
                                                                background-color: #00adee
                                                            }

                                                            .elementor-social-icon-stumbleupon {
                                                                background-color: #eb4924
                                                            }

                                                            .elementor-social-icon-telegram {
                                                                background-color: #2ca5e0
                                                            }

                                                            .elementor-social-icon-thumb-tack {
                                                                background-color: #1aa1d8
                                                            }

                                                            .elementor-social-icon-tripadvisor {
                                                                background-color: #589442
                                                            }

                                                            .elementor-social-icon-tumblr {
                                                                background-color: #35465c
                                                            }

                                                            .elementor-social-icon-twitch {
                                                                background-color: #6441a5
                                                            }

                                                            .elementor-social-icon-twitter {
                                                                background-color: #1da1f2
                                                            }

                                                            .elementor-social-icon-viber {
                                                                background-color: #665cac
                                                            }

                                                            .elementor-social-icon-vimeo {
                                                                background-color: #1ab7ea
                                                            }

                                                            .elementor-social-icon-vk {
                                                                background-color: #45668e
                                                            }

                                                            .elementor-social-icon-weibo {
                                                                background-color: #dd2430
                                                            }

                                                            .elementor-social-icon-weixin {
                                                                background-color: #31a918
                                                            }

                                                            .elementor-social-icon-whatsapp {
                                                                background-color: #25d366
                                                            }

                                                            .elementor-social-icon-wordpress {
                                                                background-color: #21759b
                                                            }

                                                            .elementor-social-icon-xing {
                                                                background-color: #026466
                                                            }

                                                            .elementor-social-icon-yelp {
                                                                background-color: #af0606
                                                            }

                                                            .elementor-social-icon-youtube {
                                                                background-color: #cd201f
                                                            }

                                                            .elementor-social-icon-500px {
                                                                background-color: #0099e5
                                                            }

                                                            .elementor-shape-rounded .elementor-icon.elementor-social-icon {
                                                                border-radius: 10%
                                                            }

                                                            .elementor-shape-circle .elementor-icon.elementor-social-icon {
                                                                border-radius: 50%
                                                            }
                                                        </style>
                                                        <div class="elementor-social-icons-wrapper elementor-grid">
                                                            <span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-9a0712a" target="_blank">
						<span class="elementor-screen-only">Facebook</span>
                                                            <svg class="e-font-icon-svg e-fab-facebook" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"></path></svg>                                                            </a>
                                                            </span>
                                                            <span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-pinterest elementor-repeater-item-d67905f" target="_blank">
						<span class="elementor-screen-only">Pinterest</span>
                                                            <svg class="e-font-icon-svg e-fab-pinterest" viewBox="0 0 496 512" xmlns="http://www.w3.org/2000/svg"><path d="M496 256c0 137-111 248-248 248-25.6 0-50.2-3.9-73.4-11.1 10.1-16.5 25.2-43.5 30.8-65 3-11.6 15.4-59 15.4-59 8.1 15.4 31.7 28.5 56.8 28.5 74.8 0 128.7-68.8 128.7-154.3 0-81.9-66.9-143.2-152.9-143.2-107 0-163.9 71.8-163.9 150.1 0 36.4 19.4 81.7 50.3 96.1 4.7 2.2 7.2 1.2 8.3-3.3.8-3.4 5-20.3 6.9-28.1.6-2.5.3-4.7-1.7-7.1-10.1-12.5-18.3-35.3-18.3-56.6 0-54.7 41.4-107.6 112-107.6 60.9 0 103.6 41.5 103.6 100.9 0 67.1-33.9 113.6-78 113.6-24.3 0-42.6-20.1-36.7-44.8 7-29.5 20.5-61.3 20.5-82.6 0-19-10.2-34.9-31.4-34.9-24.9 0-44.9 25.7-44.9 60.2 0 22 7.4 36.8 7.4 36.8s-24.5 103.8-29 123.2c-5 21.4-3 51.6-.9 71.2C65.4 450.9 0 361.1 0 256 0 119 111 8 248 8s248 111 248 248z"></path></svg>                                                            </a>
                                                            </span>
                                                            <span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-repeater-item-6b5e2a4" target="_blank">
						<span class="elementor-screen-only">Twitter</span>
                                                            <svg class="e-font-icon-svg e-fab-twitter" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path></svg>                                                            </a>
                                                            </span>
                                                            <span class="elementor-grid-item">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-0ddbc16" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
                                                            <svg class="e-font-icon-svg e-fab-instagram" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg>                                                            </a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-dfe7a17 elementor-widget elementor-widget-text-editor" data-id="dfe7a17" data-element_type="widget" data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        Signup and get exclusive offers and coupon codes </div>
                                                </div>
                                                <div class="elementor-element elementor-element-ea4ce57 elementor-widget elementor-widget-button" data-id="ea4ce57" data-element_type="widget" data-widget_type="button.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-button-wrapper">
                                                            <a class="elementor-button elementor-button-link elementor-size-sm" href="#">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Sign Up</span>
		</span>
					</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="elementor-section elementor-top-section elementor-element elementor-element-6bbdf979 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
                    data-id="6bbdf979" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-3f6f6b6e" data-id="3f6f6b6e" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-2e98d97a tmpcoder-navigation-menu__align-tablet-left tmpcoder-navigation-menu__breakpoint-none tmpcoder-menu-first-sep-hide-yes tmpcoder-navigation-menu__align-left tmpcoder-submenu-icon-arrow tmpcoder-submenu-animation-none tmpcoder-link-redirect-child elementor-widget elementor-widget-navigation-menu"
                                    data-id="2e98d97a" data-element_type="widget" data-settings="{&quot;padding_horizontal_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:25,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:20,&quot;sizes&quot;:[]},&quot;padding_horizontal_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:18,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:7,&quot;sizes&quot;:[]},&quot;menu_space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;padding_vertical_menu_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;menu_row_space_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;dropdown_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;dropdown_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;top&quot;:&quot;&quot;,&quot;right&quot;:&quot;&quot;,&quot;bottom&quot;:&quot;&quot;,&quot;left&quot;:&quot;&quot;,&quot;isLinked&quot;:true},&quot;width_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;220&quot;,&quot;sizes&quot;:[]},&quot;width_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;width_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_horizontal_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:15,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;padding_vertical_dropdown_item_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;distance_from_menu_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_size_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_width_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;toggle_border_radius_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}"
                                    data-widget_type="navigation-menu.default">
                                    <div class="elementor-widget-container">
                                        <div class="tmpcoder-navigation-menu tmpcoder-layout-horizontal tmpcoder-navigation-menu-layout horizontal tmpcoder-pointer__none" data-layout="horizontal">
                                            <div class="tmpcoder-navigation-menu__toggle elementor-clickable">
                                                <div class="tmpcoder-navigation-menu-icon">
                                                </div>
                                            </div>
                                            <nav class="tmpcoder-navigation-menu__layout-horizontal tmpcoder-navigation-menu__submenu-arrow" data-toggle-icon="" data-close-icon="" data-full-width="">
                                                <ul id="menu-1-2e98d97a" class="tmpcoder-navigation-menu">
                                                    <li id="menu-item-3042" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/privacy-policy/" class="tmpcoder-menu-item">Privacy Policy</a></li>
                                                    <li id="menu-item-3043" class="menu-item menu-item-type-post_type menu-item-object-page parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="https://themes.templatescoder.com/pizzon/wp/demo-02/refund-and-returns-policy/" class="tmpcoder-menu-item">Refund Policy</a></li>
                                                    <li id="menu-item-204" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Cookie Policy</a></li>
                                                    <li id="menu-item-3044" class="menu-item menu-item-type-custom menu-item-object-custom parent tmpcoder-creative-menu"><span class="custom-icon"></span><a href="#" class="tmpcoder-menu-item">Terms &#038; Conditions</a></li>
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-668c7b05" data-id="668c7b05" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-75258336 elementor-widget elementor-widget-text-editor" data-id="75258336" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <ul class="footer-app-button">
                                            <li><a href="#"><img src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/12/ggl-play.png" /></a></li>
                                            <li><a href="#"><img src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/2023/12/apl-store.png" /></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="elementor-section elementor-top-section elementor-element elementor-element-2c1c753d elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-multicolor-no tmpcoder-sticky-section-no tmpcoder-particle-no"
                    data-id="2c1c753d" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-34f8ec63" data-id="34f8ec63" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-7dbf37a elementor-widget elementor-widget-text-editor" data-id="7dbf37a" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        © 2024 Pizzon. All Rights Reserved by <a href="https://templatescoder.com/" target="_blank" rel="noopener">Templatescoder</a> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </footer>


    <script>
        window.RS_MODULES = window.RS_MODULES || {};
        window.RS_MODULES.modules = window.RS_MODULES.modules || {};
        window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
        window.RS_MODULES.defered = true;
        window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
        window.RS_MODULES.type = 'compiled';
    </script>
    <script type="application/ld+json">
        {
            "@context": "https:\/\/schema.org\/",
            "@type": "BreadcrumbList",
            "itemListElement": [{
                "@type": "ListItem",
                "position": 1,
                "item": {
                    "name": "Home",
                    "@id": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02"
                }
            }, {
                "@type": "ListItem",
                "position": 2,
                "item": {
                    "name": "Popular Dishes",
                    "@id": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/product-category\/popular-dishes\/"
                }
            }, {
                "@type": "ListItem",
                "position": 3,
                "item": {
                    "name": "Margherita pizza",
                    "@id": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/product\/margherita-pizza\/"
                }
            }]
        }
    </script>
    <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="pswp__bg"></div>
        <div class="pswp__scroll-wrap">
            <div class="pswp__container">
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
            </div>
            <div class="pswp__ui pswp__ui--hidden">
                <div class="pswp__top-bar">
                    <div class="pswp__counter"></div>
                    <button class="pswp__button pswp__button--close" aria-label="Close (Esc)"></button>
                    <button class="pswp__button pswp__button--share" aria-label="Share"></button>
                    <button class="pswp__button pswp__button--fs" aria-label="Toggle fullscreen"></button>
                    <button class="pswp__button pswp__button--zoom" aria-label="Zoom in/out"></button>
                    <div class="pswp__preloader">
                        <div class="pswp__preloader__icn">
                            <div class="pswp__preloader__cut">
                                <div class="pswp__preloader__donut"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                    <div class="pswp__share-tooltip"></div>
                </div>
                <button class="pswp__button pswp__button--arrow--left" aria-label="Previous (arrow left)"></button>
                <button class="pswp__button pswp__button--arrow--right" aria-label="Next (arrow right)"></button>
                <div class="pswp__caption">
                    <div class="pswp__caption__center"></div>
                </div>
            </div>
        </div>
    </div>
    <script>
        (function() {
            var c = document.body.className;
            c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
            document.body.className = c;
        })();
    </script>
    <link rel='stylesheet' id='elementor-frontend-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/css/frontend-lite.min.css?ver=3.19.4' media='all' />
    <link rel='stylesheet' id='elementor-post-162-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/elementor/css/post-162.css?ver=1712209731' media='all' />
    <link rel='stylesheet' id='elementor-post-133-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/elementor/css/post-133.css?ver=1712209806' media='all' />
    <link rel='stylesheet' id='woocommerce_prettyPhoto_css-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/css/prettyPhoto.css?ver=8.6.1' media='all' />
    <link rel='stylesheet' id='elementor-post-152-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/elementor/css/post-152.css?ver=1712209731' media='all' />
    <link rel='stylesheet' id='swiper-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/lib/swiper/v8/css/swiper.min.css?ver=8.4.5' media='all' />
    <link rel='stylesheet' id='elementor-post-28-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/elementor/css/post-28.css?ver=1712209731' media='all' />
    <link rel='stylesheet' id='font-awesome-5-all-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=3.19.4' media='all' />
    <link rel='stylesheet' id='font-awesome-4-shim-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=3.19.4' media='all' />
    <link rel='stylesheet' id='elementor-global-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/uploads/sites/2/elementor/css/global.css?ver=1712209732' media='all' />
    <link rel='stylesheet' id='e-animations-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.19.4' media='all' />
    <link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=PT+Sans+Narrow%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=swap&#038;ver=6.5'
        media='all' />
    <link rel='stylesheet' id='rs-plugin-settings-css' href='https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.6.20' media='all' />
    <style id='rs-plugin-settings-inline-css'>
        #rs-demo-id {}
    </style>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.8.7" id="swv-js"></script>
    <script id="contact-form-7-js-extra">
        var wpcf7 = {
            "api": {
                "root": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-json\/",
                "namespace": "contact-form-7\/v1"
            }
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.8.7" id="contact-form-7-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.6.20" defer async id="tp-tools-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.6.20" defer async id="revmin-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/woo-pro-grid/lib/isotope/isotope.min.js?ver=1.3.5" id="tmpcoder-isotope-js-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/woo-pro-grid/lib/slick/slick.js?ver=1.3.5" id="tmpcoder-slick-js-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/woo-pro-grid/lib/lightgallery/lightgallery.min.js?ver=1.3.5" id="tmpcoder-lightgallery-js-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/js/snap.svg-min.js?ver=6.5" id="jquery-snap-svg-min-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/js/jquery.listtopie.min.js?ver=6.5" id="jquery-listtopie-min-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/js/jquery.magnific-popup.min.js?ver=6.5" id="jquery-magnific-popup-min-js"></script>
    <script id="tmpcoder-script-js-js-extra">
        var tmpcoder_plugin_script = {
            "ajax_url": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-admin\/admin-ajax.php",
            "nonce": "857c01b044",
            "comparePageID": "",
            "comparePageURL": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/product\/margherita-pizza\/",
            "wishlistPageID": "",
            "wishlistPageURL": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/product\/margherita-pizza\/",
            "chooseQuantityText": "Please select the required number of items.",
            "site_key": "",
            "is_admin": "",
            "input_empty": "Please fill out this field",
            "select_empty": "Nothing selected",
            "file_empty": "Please upload a file",
            "recaptcha_error": "Recaptcha Error",
            "tmpcoder_site_settings": {
                "last_tab": "",
                "primany_color": "#FBB200",
                "secondary_color": "#F22E3E",
                "accent_color": "#777777",
                "theme_color_1": "#FFFFFF",
                "theme_color_2": "#111111",
                "theme_color_3": "#FFFAED",
                "theme_color_4": {
                    "color": "",
                    "alpha": "",
                    "rgba": ""
                },
                "site_background_color": {
                    "background-color": "#fff"
                },
                "link_color": "#111111",
                "link_hover_color": "#F22E3E",
                "global_border_color": "#E4DED9",
                "site_fonts_options": {
                    "font-family": "Montserrat",
                    "font-options": "",
                    "google": "true",
                    "font-weight": "500",
                    "font-style": "",
                    "font-size": "18px",
                    "line-height": "32px",
                    "letter-spacing": "",
                    "color": "#777777"
                },
                "heading_1": {
                    "font-family": "Montserrat",
                    "font-options": "",
                    "google": "true",
                    "font-weight": "700",
                    "font-style": "",
                    "text-transform": "",
                    "font-size": "64px",
                    "line-height": "74px",
                    "letter-spacing": "",
                    "color": "#111111"
                },
                "heading_2": {
                    "font-family": "Montserrat",
                    "font-options": "",
                    "google": "true",
                    "font-weight": "700",
                    "font-style": "",
                    "text-transform": "",
                    "font-size": "40px",
                    "line-height": "55px",
                    "letter-spacing": "",
                    "color": "#111111"
                },
                "heading_3": {
                    "font-family": "Montserrat",
                    "font-options": "",
                    "google": "true",
                    "font-weight": "600",
                    "font-style": "",
                    "text-transform": "",
                    "font-size": "28px",
                    "line-height": "40px",
                    "letter-spacing": "",
                    "color": "#111111"
                },
                "heading_4": {
                    "font-family": "Montserrat",
                    "font-options": "",
                    "google": "true",
                    "font-weight": "600",
                    "font-style": "",
                    "text-transform": "",
                    "font-size": "24px",
                    "line-height": "28px",
                    "letter-spacing": "",
                    "color": "#1d1d1d"
                },
                "heading_5": {
                    "font-family": "Montserrat",
                    "font-options": "",
                    "google": "true",
                    "font-weight": "600",
                    "font-style": "",
                    "text-transform": "",
                    "font-size": "22px",
                    "line-height": "38px",
                    "letter-spacing": "",
                    "color": "#111111"
                },
                "heading_6": {
                    "font-family": "Montserrat",
                    "font-options": "",
                    "google": "true",
                    "font-weight": "600",
                    "font-style": "",
                    "text-transform": "",
                    "font-size": "18px",
                    "line-height": "30px",
                    "letter-spacing": "",
                    "color": "#111111"
                },
                "site_fonts_options_tablet": {
                    "font-size": "18px",
                    "line-height": "32px",
                    "letter-spacing": "0px"
                },
                "heading_1_tablet": {
                    "font-size": "50px",
                    "line-height": "64px",
                    "letter-spacing": "0px"
                },
                "heading_2_tablet": {
                    "font-size": "40px",
                    "line-height": "55px",
                    "letter-spacing": "0px"
                },
                "heading_3_tablet": {
                    "font-size": "30px",
                    "line-height": "34px",
                    "letter-spacing": "0px"
                },
                "heading_4_tablet": {
                    "font-size": "24px",
                    "line-height": "28px",
                    "letter-spacing": "0px"
                },
                "heading_5_tablet": {
                    "font-size": "22px",
                    "line-height": "38px",
                    "letter-spacing": "0px"
                },
                "heading_6_tablet": {
                    "font-size": "20px",
                    "line-height": "20px",
                    "letter-spacing": "0px"
                },
                "site_fonts_options_mobile": {
                    "font-size": "16px",
                    "line-height": "30px",
                    "letter-spacing": ""
                },
                "heading_1_mobile": {
                    "font-size": "40px",
                    "line-height": "52px",
                    "letter-spacing": ""
                },
                "heading_2_mobile": {
                    "font-size": "30px",
                    "line-height": "42px",
                    "letter-spacing": "0px"
                },
                "heading_3_mobile": {
                    "font-size": "26px",
                    "line-height": "26px",
                    "letter-spacing": ""
                },
                "heading_4_mobile": {
                    "font-size": "22px",
                    "line-height": "36px",
                    "letter-spacing": ""
                },
                "heading_5_mobile": {
                    "font-size": "20px",
                    "line-height": "20px",
                    "letter-spacing": ""
                },
                "heading_6_mobile": {
                    "font-size": "18px",
                    "line-height": "18px",
                    "letter-spacing": ""
                },
                "button_style": {
                    "font-family": "Montserrat",
                    "font-options": "",
                    "google": "1",
                    "font-weight": "400",
                    "font-style": "",
                    "text-transform": "uppercase",
                    "font-size": "20px",
                    "line-height": "32px",
                    "letter-spacing": "",
                    "color": "#fff"
                },
                "site_button_text_hover": "#FFFFFF",
                "site_button_color": "#FBB200",
                "site_button_color_hover": "#F22E3E",
                "button_border": {
                    "border-top": "2px",
                    "border-right": "2px",
                    "border-bottom": "2px",
                    "border-left": "2px",
                    "border-style": "solid",
                    "border-color": "#fbb200"
                },
                "button_border_hover": {
                    "border-top": "2px",
                    "border-right": "2px",
                    "border-bottom": "2px",
                    "border-left": "2px",
                    "border-style": "solid",
                    "border-color": "#f22e3e"
                },
                "button_border_radius": "50",
                "button_padding": {
                    "border-top": "12px",
                    "border-right": "30px",
                    "border-bottom": "12px",
                    "border-left": "30px",
                    "border-style": "solid",
                    "border-color": ""
                },
                "button_style_tablet": {
                    "font-size": "16px",
                    "line-height": "24px",
                    "letter-spacing": "1px"
                },
                "button_padding_tablet": {
                    "border-top": "12px",
                    "border-right": "30px",
                    "border-bottom": "12px",
                    "border-left": "30px",
                    "border-style": "",
                    "border-color": ""
                },
                "button_style_mobile": {
                    "font-size": "16px",
                    "line-height": "24px",
                    "letter-spacing": "1px"
                },
                "button_padding_mobile": {
                    "border-top": "8px",
                    "border-right": "20px",
                    "border-bottom": "8px",
                    "border-left": "20px",
                    "border-style": "",
                    "border-color": ""
                },
                "pizn_logo_image": {
                    "url": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-content\/uploads\/sites\/2\/2023\/10\/logo.png",
                    "id": "1088",
                    "height": "146",
                    "width": "117",
                    "thumbnail": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-content\/uploads\/sites\/2\/2023\/10\/logo.png"
                },
                "pizn_logo_text": "Pizzon",
                "pizn_fav_site_icon": {
                    "url": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-content\/uploads\/sites\/2\/2023\/10\/favicon.png",
                    "id": "1089",
                    "height": "146",
                    "width": "146",
                    "thumbnail": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-content\/uploads\/sites\/2\/2023\/10\/favicon.png"
                },
                "pizn_pre_loder": "1",
                "pizn_preloder_custom_html": "<img class=\"alignnone size-full wp-image-70\" src=\"https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-content\/uploads\/sites\/2\/2023\/11\/preloader.svg\" alt=\"\" width=\"300\" height=\"300\" \/>",
                "footer_copyright_text": "\u00a9 Pizzon All Rights Reserved. Designed By <a href=\"https:\/\/templatescoder.com\/\" target=\"_blank\" rel=\"noopener\">TemplatesCoder.com<\/a>",
                "cart_page_design": "modern",
                "checkout_page_design": "modern"
            }
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/js/script.js?ver=6.5" id="tmpcoder-script-js-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core//assets/js/canvas.js?ver=6.5" id="tmpcoder-multicolor-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/js/particles/particles.js?ver=3.0.6" id="wpr-particles-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/sourcebuster/sourcebuster.min.js?ver=8.6.1" id="sourcebuster-js-js"></script>
    <script id="wc-order-attribution-js-extra">
        var wc_order_attribution = {
            "params": {
                "lifetime": 1.0000000000000000818030539140313095458623138256371021270751953125e-5,
                "session": 30,
                "ajaxurl": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-admin\/admin-ajax.php",
                "prefix": "wc_order_attribution_",
                "allowTracking": true
            },
            "fields": {
                "source_type": "current.typ",
                "referrer": "current_add.rf",
                "utm_campaign": "current.cmp",
                "utm_source": "current.src",
                "utm_medium": "current.mdm",
                "utm_content": "current.cnt",
                "utm_id": "current.id",
                "utm_term": "current.trm",
                "session_entry": "current_add.ep",
                "session_start_time": "current_add.fd",
                "session_pages": "session.pgs",
                "session_count": "udata.vst",
                "user_agent": "udata.uag"
            }
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution.min.js?ver=8.6.1" id="wc-order-attribution-js"></script>
    <script id="wc-add-to-cart-variation-js-extra">
        var wc_add_to_cart_variation_params = {
            "wc_ajax_url": "\/pizzon\/wp\/demo-02\/?wc-ajax=%%endpoint%%",
            "i18n_no_matching_variations_text": "Sorry, no products matched your selection. Please choose a different combination.",
            "i18n_make_a_selection_text": "Please select some product options before adding this product to your cart.",
            "i18n_unavailable_text": "Sorry, this product is unavailable. Please choose a different combination."
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=8.6.1" id="wc-add-to-cart-variation-js" data-wp-strategy="defer"></script>
    <script id="cfvsw_swatches_product-js-extra">
        var cfvsw_swatches_settings = {
            "ajax_url": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-admin\/admin-ajax.php",
            "admin_url": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-admin\/admin.php",
            "remove_attr_class": "cfvsw-swatches-blur",
            "html_design": "none",
            "unavailable_text": "Selected variant is unavailable.",
            "ajax_add_to_cart_nonce": "af9fd63f41",
            "tooltip_image": "",
            "disable_out_of_stock": "1"
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/variation-swatches-woo/assets/js/swatches.js?ver=1.0.7" id="cfvsw_swatches_product-js"></script>
    <script id="yith-woocompare-main-js-extra">
        var yith_woocompare = {
            "ajaxurl": "\/pizzon\/wp\/demo-02\/?wc-ajax=%%endpoint%%",
            "actionadd": "yith-woocompare-add-product",
            "actionremove": "yith-woocompare-remove-product",
            "actionview": "yith-woocompare-view-table",
            "actionreload": "yith-woocompare-reload-product",
            "added_label": "Added",
            "table_title": "Product Comparison",
            "auto_open": "yes",
            "loader": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-content\/plugins\/yith-woocommerce-compare\/assets\/images\/loader.gif",
            "button_text": "Compare",
            "cookie_name": "yith_woocompare_list_2",
            "close_label": "Close"
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/yith-woocommerce-compare/assets/js/woocompare.min.js?ver=2.36.0" id="yith-woocompare-main-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/yith-woocommerce-compare/assets/js/jquery.colorbox-min.js?ver=1.4.21" id="jquery-colorbox-js"></script>
    <script id="pizn-custom-js-extra">
        var myAjax = {
            "ajax_url": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-admin\/admin-ajax.php"
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/themes/pizzon/assets/js/custom.js?ver=1.1.0" id="pizn-custom-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/themes/pizzon/assets/js/owl.carousel.min.js?ver=6.5" id="owl-carousel-min-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/comment-reply.min.js?ver=6.5" id="comment-reply-js" async data-wp-strategy="async"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/assets/js/sticky-section.js?ver=6.5" id="tmpcoder-ext-sticky-section-js-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/smart-wishlist-for-more-convert/assets/frontend/js/toastr.min.js?ver=1.7.4" id="toastr-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/smart-wishlist-for-more-convert/assets/frontend/js/jquery.popupoverlay.min.js?ver=1.7.4" id="jquery-popupoverlay-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
    <script id="wlfmc-main-js-extra">
        var wlfmc_l10n = {
            "ajax_url": "\/pizzon\/wp\/demo-02\/wp-admin\/admin-ajax.php",
            "wp_loaded_url": "\/pizzon\/wp\/demo-02\/product\/margherita-pizza\/",
            "admin_url": "\/pizzon\/wp\/demo-02\/wp-admin\/admin-ajax.php",
            "root": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-json\/wlfmc\/v1\/call",
            "nonce": "3896406664",
            "ajax_mode": "admin-ajax.php",
            "update_wishlists_data": "",
            "wishlist_hash_key": "wc_wishlist_hash_dca2056756f5f2fb426532a75e733517",
            "redirect_to_cart": "1",
            "is_cache_enabled": "1",
            "is_page_cache_enabled": "1",
            "lang": null,
            "wishlist_items": [],
            "click_behavior": "open-popup",
            "multi_wishlist": "",
            "enable_ajax_loading": "1",
            "ajax_loader_url": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-content\/plugins\/smart-wishlist-for-more-convert\/assets\/frontend\/images\/ajax-loader-alt.svg",
            "remove_from_wishlist_after_add_to_cart": "",
            "fragments_index_glue": ".",
            "is_rtl": "",
            "toast_position": "default",
            "labels": {
                "cookie_disabled": "We are sorry, but this feature is available only if cookies on your browser are enabled.",
                "product_adding": "Another product is being added to the list, please wait until it is finished.",
                "added_to_cart_message": "Product added to cart successfully",
                "failed_add_to_cart_message": "Product could not be added to the cart because some requirements are not met.",
                "login_need": "to use your Wishlist: <br><a href=\"https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/my-account\/\">Login right now<\/a>",
                "product_added_text": "Product added!",
                "already_in_wishlist_text": "The product is already in your Wishlist!",
                "product_removed_text": "Product Removed!",
                "popup_title": "Added to Wishlist",
                "popup_content": "<p>See your favorite product on Wishlist<\/p>",
                "link_copied": "The link was copied to clipboard"
            },
            "actions": {
                "add_to_cart_action": "wlfmc_add_to_cart",
                "add_to_wishlist_action": "wlfmc_add_to_wishlist",
                "remove_from_wishlist_action": "wlfmc_remove_from_wishlist",
                "delete_item_action": "wlfmc_delete_item",
                "load_fragments": "wlfmc_load_fragments",
                "load_automations": "wlfmc_load_automations",
                "update_item_quantity": "wlfmc_update_item_quantity",
                "change_layout": "wlfmc_change_layout"
            },
            "ajax_nonce": []
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/smart-wishlist-for-more-convert/assets/frontend/js/scripts.min.js?ver=1.7.4" id="wlfmc-main-js"></script>
    <script id="wlfmc-main-js-after">
        jQuery(document).ready(function($) {
            $(document).on('wlfmc_add_to_wishlist_data', function(e, el, data) {
                var button = el;
                var wrapper = button.closest('div.wlfmc-add-to-wishlist');
                if (wrapper.hasClass('wlfmc-loop-btn')) {
                    var container = wrapper.closest('*.product');
                    if (container.find('.cfvsw_variations_form').length > 0) {
                        var attributes_field = container.find('.cfvsw-hidden-select select');
                        if (attributes_field.length > 0) {
                            attributes_field.each(function() {
                                if ('' !== $(this).val()) {
                                    data[$(this).attr('name')] = $(this).val();
                                }
                            });
                        } else {
                            console.log('Invalid Attributes:', attributes_field);
                        }
                    }
                }
            });
            $(document).on('wlfmc_add_to_waitlist_data', function(e, el, data) {
                var button = el;
                var product_id = button.attr('data-parent-product-id');
                var wrapper = $('div.cfvsw_variations_form[data-product_id="' + product_id + '"]');

                if (wrapper.length > 0) {
                    var attributes_field = wrapper.find('.cfvsw-hidden-select select');
                    if (attributes_field.length > 0) {
                        attributes_field.each(function() {
                            if ('' !== $(this).val()) {
                                data[$(this).attr('name')] = $(this).val();
                            }
                        });
                    } else {
                        console.log('Invalid Attributes:', attributes_field);
                    }
                }
            });

            $(document).on('wlfmc_add_to_multi_list_data', function(e, el, data) {
                var button = el;
                var product_id = button.attr('data-parent-product-id');
                var wrapper = $('div.cfvsw_variations_form[data-product_id="' + product_id + '"]');

                if (wrapper.length > 0) {
                    var attributes_field = wrapper.find('.cfvsw-hidden-select select');
                    if (attributes_field.length > 0) {
                        attributes_field.each(function() {
                            if ('' !== $(this).val()) {
                                data[$(this).attr('name')] = $(this).val();
                            }
                        });
                    } else {
                        console.log('Invalid Attributes:', attributes_field);
                    }
                }
            });
        });
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/templatescoder-core/inc/widgets-js/frontend.js?ver=1.3.5" id="tmpcoder-frontend-js-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.19.4" id="font-awesome-4-shim-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.19.4" id="elementor-webpack-runtime-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.19.4" id="elementor-frontend-modules-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2" id="elementor-waypoints-js"></script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
    <script id="elementor-frontend-js-before">
        var elementorFrontendConfig = {
            "environmentMode": {
                "edit": false,
                "wpPreview": false,
                "isScriptDebug": false
            },
            "i18n": {
                "shareOnFacebook": "Share on Facebook",
                "shareOnTwitter": "Share on Twitter",
                "pinIt": "Pin it",
                "download": "Download",
                "downloadImage": "Download image",
                "fullscreen": "Fullscreen",
                "zoom": "Zoom",
                "share": "Share",
                "playVideo": "Play Video",
                "previous": "Previous",
                "next": "Next",
                "close": "Close",
                "a11yCarouselWrapperAriaLabel": "Carousel | Horizontal scrolling: Arrow Left & Right",
                "a11yCarouselPrevSlideMessage": "Previous slide",
                "a11yCarouselNextSlideMessage": "Next slide",
                "a11yCarouselFirstSlideMessage": "This is the first slide",
                "a11yCarouselLastSlideMessage": "This is the last slide",
                "a11yCarouselPaginationBulletMessage": "Go to slide"
            },
            "is_rtl": false,
            "breakpoints": {
                "xs": 0,
                "sm": 480,
                "md": 768,
                "lg": 1025,
                "xl": 1440,
                "xxl": 1600
            },
            "responsive": {
                "breakpoints": {
                    "mobile": {
                        "label": "Mobile Portrait",
                        "value": 767,
                        "default_value": 767,
                        "direction": "max",
                        "is_enabled": true
                    },
                    "mobile_extra": {
                        "label": "Mobile Landscape",
                        "value": 880,
                        "default_value": 880,
                        "direction": "max",
                        "is_enabled": false
                    },
                    "tablet": {
                        "label": "Tablet Portrait",
                        "value": 1024,
                        "default_value": 1024,
                        "direction": "max",
                        "is_enabled": true
                    },
                    "tablet_extra": {
                        "label": "Tablet Landscape",
                        "value": 1200,
                        "default_value": 1200,
                        "direction": "max",
                        "is_enabled": false
                    },
                    "laptop": {
                        "label": "Laptop",
                        "value": 1199,
                        "default_value": 1366,
                        "direction": "max",
                        "is_enabled": false
                    },
                    "widescreen": {
                        "label": "Widescreen",
                        "value": 1300,
                        "default_value": 2400,
                        "direction": "min",
                        "is_enabled": false
                    }
                }
            },
            "version": "3.19.4",
            "is_static": false,
            "experimentalFeatures": {
                "e_optimized_assets_loading": true,
                "e_optimized_css_loading": true,
                "e_font_icon_svg": true,
                "additional_custom_breakpoints": true,
                "container": true,
                "e_swiper_latest": true,
                "block_editor_assets_optimize": true,
                "ai-layout": true,
                "landing-pages": true,
                "e_image_loading_optimization": true,
                "e_global_styleguide": true
            },
            "urls": {
                "assets": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-content\/plugins\/elementor\/assets\/"
            },
            "swiperClass": "swiper",
            "settings": {
                "page": [],
                "editorPreferences": []
            },
            "kit": {
                "viewport_tablet": 1024,
                "active_breakpoints": ["viewport_mobile", "viewport_tablet"],
                "global_image_lightbox": "yes",
                "lightbox_enable_counter": "yes",
                "lightbox_enable_fullscreen": "yes",
                "lightbox_enable_zoom": "yes",
                "lightbox_enable_share": "yes",
                "lightbox_title_src": "title",
                "lightbox_description_src": "description"
            },
            "post": {
                "id": 3190,
                "title": "Margherita%20pizza%20%E2%80%93%20Pizzon%20Modern",
                "excerpt": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Semper sagittis dolor aliquet quam feugiat nisi a ultrices feugiat. Viverra facilisi turpis eget tempor. Mattis risus amet euismod eleifend.",
                "featuredImage": "https:\/\/themes.templatescoder.com\/pizzon\/wp\/demo-02\/wp-content\/uploads\/sites\/2\/2023\/11\/onion.jpg"
            }
        };
    </script>
    <script src="https://themes.templatescoder.com/pizzon/wp/demo-02/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.19.4" id="elementor-frontend-js"></script>

</body>

</html>