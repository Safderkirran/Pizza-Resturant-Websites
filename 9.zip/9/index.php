<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Basic Page Needs -->
    <title>Pizzon</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS -->
    <!-- <link type="image/x-icon" href="images/favicon.png" rel="icon"> -->
    <link type="image/x-icon" href="./m/images/favicon.png" rel="icon">
    <link rel="stylesheet" type="text/css" href="./m/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="./m/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./m/css/owl.carousel.css">
    <!-- <link rel="stylesheet" type="text/css" href="./m/css/style.css"> -->
</head>

<body>
    <style>
        .container-1 {
            width: 100%;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0px 90px;
        }

        .cart-section {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
    </style>
    <?php

    session_start();

    include("includes/db.php");
    include("includes/header.php");
    include("functions/functions.php");
    include("includes/main.php");

    ?>



    <!-- Preloader Start -->
    <div id="preloader" class="preloader">
        <div class="preloader-box">
            <img src="./m/images/preloader.svg" alt="preloader">
        </div>
    </div>
    <!-- Preloader End -->

    <!-- Header Start -->

    <!-- Header End -->


    <!-- Start Of Main Div -->
    <main class="main">

        <!-- Start Of Home Banner -->
        <section class="home-banner left-padding overflow-h">
            <div class="black-jamun wow fadeInLeft animation-delay-5">
                <img src="./m/images/black-jamun.png" alt="Vacter Image">
            </div>
            <div class="home-onion wow fadeInUp animation-delay-5">
                <img src="./m/images/onion.png" alt="Vacter Image">
            </div>
            <div class="row align-items-center">
                <div class="col-xl-5 col-lg-6 col-md-6 home-left-content wow fadeInLeft">
                    <div class="home-banner-content">
                        <h1 class="home-banner-title"> Welcome to <span> Ratatouille</span> kitchen. The Best Pizza in <span>Lahore city.</span></h1>
                        <div class="home-banner-desc">
                            <p>Fresh ingredients, handmade dough, and authentic flavors.</p>
                        </div>
                        <a href="shop-list.html" class="btn-ct btn-large"><img src="./m/images/cart-icon-white.png" alt="Cart Icon"> Order Now</a>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-6 col-md-6 home-right-img">
                    <div class="home-banner-img">
                        <div class="home-img wow fadeInRight animation-delay-5">
                            <div class="home-img-1">
                                <img src="./m/images/banner-img.png" alt="banner-img">
                            </div>

                        </div>
                        <div class="home-img-bottom wow fadeInUp animation-delay-5">
                            <img src="./m/images/banner-img-bottom.png" alt="banner-img-bottom">
                        </div>
                        <div class="slider-round-box wow fadeInRight">
                            <div class="slider-round">
                                <span class="slider-round-line"></span>
                                <div class="buy-one-get">
                                    <img src="./m/images/buy-one-get.png" alt="Vacter Image">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Of Home Banner -->


        <!-- Start Of Daily Fresh -->
        <section class="daily-fresh mb-150 overflow-h">
            <div class="daily-fresh-inner">
                <div class="fresh-img wow fadeInLeft">
                    <img src="./m/images/daily-fresh.png" alt="Daily Fresh">
                </div>
                <div class="fresh-content wow fadeInUp">
                    <h3 class="title">Introduction</h3>
                    <div class="fresh-des">
                        <p>At  Ratatouille cloud kitchen, we pride ourselves on delivering an exceptional pizza experience. Our pizzas are crafted with the freshest ingredients, handmade dough, and a passion for great taste. Whether you're craving a classic margherita or a gourmet creation, we've got you covered. Come and taste the difference at Ratatouille cloud kitchen.</p>
                    </div>
                </div>
            </div>
            <div class="daily-fresh-vacter wow fadeInUp animation-delay-5">
                <img src="./m/images/daily-fresh-vacter.png" alt="Vacter icon">
            </div>
        </section>
        <!-- End Of Daily Fresh -->

        <!-- Start Of Our Menu -->
        <section class="our-menu position-r ">
            <div class="our-menu-vacter wow fadeInRight">
                <img src="./m/images/tomato.png" alt="Vacter Image">
            </div>
            <div class="container">
                <div class="section-heading wow fadeInLeft">
                    <h5 class="sub-title">Popular Dishes</h5>
                    <h2>Browse Our Menu</h2>
                </div>
            </div>


           
        <div class="container mt-5">
            <div class="row">
                <?php getPro(); ?>
            </div>
        </div>



        </section>
        <!-- End Of Our Menu -->













    </main>
    <!-- End Of Main Div -->





    <!-- Start Of Search Popup -->
    <div class="search-popup">
        <div class="search-overlay"></div>
        <div class="search-form">
            <button class="close"></button>
            <form>
                <input type="text" name="search" placeholder="What are you looking for?" class="search-input">
                <button type="submit"><img src="./m/images/search-icon-white.png" alt="Search Icon"></button>
            </form>
        </div>
    </div>
    <!-- End Of Search Popup -->


    <!-- Start Of Cart Drawer -->
    <div class="cart-drawer">
        <div class="bg-overlay"></div>
        <div class="drawer-content">
            <div class="w-100">
                <div class="cart-header">
                    <h6 class="title text-uppercase">SHOPPING CART</h6>
                    <button class="close"></button>
                </div>
                <div class="cart-list">
                    <div class="cart-list-inner">
                        <div class="cart-item">
                            <div class="item-image">
                                <a href="shop-detail.html"><img src="./m/images/pizza-1.png" alt="Item Image"></a>
                            </div>
                            <div class="item-detl">
                                <div class="item-name">
                                    <a href="shop-detail.html">Shrimp pizza</a>
                                    <a class="item-remove" href="#"><img src="./m/images/delete.png" alt="delete"></a>
                                </div>
                                <div class="item-price">
                                    <span>$35.00</span>
                                </div>
                                <div class="quantity-editer">
                                    <div class="quantity">
                                        <button type="button" class="sub minus">-</button>
                                        <input class="count" name="quantity" type="number" value="1" min="1" max="10">
                                        <button type="button" class="add plus">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cart-item">
                            <div class="item-image">
                                <a href="shop-detail.html"><img src="i./m/mages/pizza-2.png" alt="Item Image"></a>
                            </div>
                            <div class="item-detl">
                                <div class="item-name">
                                    <a href="shop-detail.html">Seafood pizza</a>
                                    <a class="item-remove" href="#"><img src="./m/images/delete.png" alt="delete"></a>
                                </div>
                                <div class="item-price">
                                    <span>$65.00</span>
                                </div>
                                <div class="quantity-editer">
                                    <div class="quantity">
                                        <button type="button" class="sub minus">-</button>
                                        <input class="count" name="quantity" type="number" value="1" min="1" max="10">
                                        <button type="button" class="add plus">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cart-item">
                            <div class="item-image">
                                <a href="shop-detail.html"><img src="./m/images/pizza-3.png" alt="Item Image"></a>
                            </div>
                            <div class="item-detl">
                                <div class="item-name">
                                    <a class="item-title" href="shop-detail.html">Cheese pizza</a>
                                    <a class="item-remove" href="#"><img src="./m/images/delete.png" alt="delete"></a>
                                </div>
                                <div class="item-price">
                                    <span>$45.00</span>
                                </div>
                                <div class="quantity-editer">
                                    <div class="quantity">
                                        <button type="button" class="sub minus">-</button>
                                        <input class="count" name="quantity" type="number" value="1" min="1" max="10">
                                        <button type="button" class="add plus">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cart-footer">
                <div class="sub-total">
                    <strong>Subtotal:</strong> <span class="sprice">$66.70</span>
                </div>
                <div class="cart-footer-des">
                    <p>Taxes and shipping calculated at checkout</p>
                </div>
                <div class="cart-button">
                    <ul>
                        <li><a href="cart.html" class="btn-ct btn-small">View Cart</a></li>
                        <li><a href="checkout.html" class="btn-ct btn-small subtotal">Checkout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Of Cart Drawer -->
    <?php
    include("includes/footer.php");

    ?>

    <!-- Start Of Js -->
    <script src="./m/js/jquery-3.4.1.min.js"></script>
    <script src="./m/js/bootstrap.min.js"></script>
    <script src="./m/js/animation.js"></script>
    <script src="./m/js/owl.carousel.min.js"></script>
    <!-- <script src="./m/js/pizzon.js"></script> -->
</body>

</html>