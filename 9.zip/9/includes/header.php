<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CRoboto" rel="stylesheet">
  <meta http-equiv="x-ua-compatible" content="IE=edge, chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="shortcut icon" href="//cdn.shopify.com/s/files/1/2484/9148/files/SDQSDSQ_32x32.png?v=1511436147" type="image/png">
  <title>Cloud Kitchen</title>
   <!-- <link href="styles/bootstrap.min.css" rel="stylesheet"> -->
  <!-- <link href="styles/backend.css" rel="stylesheet"> -->
  <!-- <link href="styles/style.css" rel="stylesheet">  -->

  <!-- <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">  -->
    <!-- CSS -->
    <!-- <link type="image/x-icon" href="images/favicon.png" rel="icon"> -->
    <link type="image/x-icon" href="./m/images/favicon.png" rel="icon">
    <link rel="stylesheet" type="text/css" href="./m/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="./m/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./m/css/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="./m/css/style.css">

     <!-- CSS -->
     <link type="image/x-icon" href="./m/images/favicon.png" rel="icon">
    <link rel="stylesheet" type="text/css" href="./m/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="./m/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./m/css/style.css">
</head>

  <!-- Start Of Js -->
  <script src="./m/js/jquery-3.4.1.min.js"></script>
    <script src="./m/js/bootstrap.min.js"></script>
    <script src="./m/js/animation.js"></script>
    <script src="./m/js/pizzon.js"></script>