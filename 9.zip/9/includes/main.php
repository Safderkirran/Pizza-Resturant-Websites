</head>
<header>

  <body>

  <style>
     @media screen and (max-width: 998px) {
    .cart-slide {
      position: relative;
      left: 40px;
    }
  }
  </style>
    <!-- Header Start -->
    <header>
      <div class="header-vacter">
      <img src="./m/images/header-img.png" alt="Vacter Image">
        
      </div>
      <div class="container-big">
        <div class="header-inner">
          <div class="row align-items-center">
            <div class="col-xl-3 col-lg-3 col-md-3 col-5">
              <div class="header-logo">
              <a href="index.php"><img src="./m/images/what.jpeg" style="border-radius: 100%;" alt="Brand Logo"></a>
              </div>
            </div>
            <div class="col-xl-9 col-lg-9 col-md-9 col-7">
              <div class="main-menu">
                <div class="menu-toggle">
                  <span></span>
                </div>
                <div class="menu">
                  <div class="sidemenu-header">
                    <div class="sidemenu-logo">
                        <img src="./m/images/what.jpeg" style="border-radius: 100%;" alt="Brand Logo">
                    </div>
                    <div class="sidemenu-close">
                      <span></span>
                    </div>
                  </div>
                  <ul>
                    <li class="active"><a href="index.php">Home</a></li>
                    <li class=""><a href="index.php">Shop</a></li>
                    <li class=""><a href="customer_register.php">Contact</a></li>
                    <li class="login__item">
                      <?php
                      if (!isset($_SESSION['customer_email'])) {
                        echo '<a href="customer_register.php" class="login__link" >Register</a>';
                      } else {
                        echo '<a href="customer/my_account.php?my_orders" class="login__link">My Account</a>';
                      }
                      ?>
                    </li>
                    </a>

                    <li class="login__item">
                      <?php
                      if (!isset($_SESSION['customer_email'])) {
                        echo '<a href="checkout.php" class="login__link" >Sign In</a>';
                      } else {
                        echo '<a href="./logout.php" class="login__link" >Logout</a>';
                      }
                      ?> </a>
                    </li>




                    <div class="basket" style="position: relative; left: 540px; top: 14px;">
                      <a href="cart.php" class="btn btn--basket">
                        <i class="icon-basket"></i>
                        <?php items(); ?> items
                      </a>
                    </div>

                  </ul>
                </div>
                <div class="icon-menu">
                  <ul>

                    <li class="cart-slide position-r">
                      <a href=" cart.php">
                        <img src="./m/images/cart-icon.png" class="normal-icon" alt="Cart Icon">
                        <img src="./m/images/cart-icon-2.png" class="hover-icon" alt="Cart Icon">
                        <span class="cart-count"> <?php items(); ?> </span>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- Header End -->
    <!-- Start Of Js -->
    <script src="./m/js/jquery-3.4.1.min.js"></script>
    <script src="./m/js/bootstrap.min.js"></script>
    <script src="./m/js/animation.js"></script>
    <script src="./m/js/owl.carousel.min.js"></script>
    <!-- <script src="./m/js/pizzon.js"></script> -->

  </body>
</header>