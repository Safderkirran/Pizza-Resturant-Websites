<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Basic Page Needs -->
    <title>Pizzon</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS -->
    <link type="image/x-icon" href="images/favicon.png" rel="icon">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

    <!-- Preloader Start -->
    <div id="preloader" class="preloader">
        <div class="preloader-box">
            <img src="images/preloader.svg" alt="preloader">
        </div>
    </div>
    <!-- Preloader End -->

    <!-- Header Start -->
    <header>
        <div class="header-vacter">
            <img src="images/header-img.png" alt="Vacter Image">
        </div>
        <div class="container-big">
            <div class="header-inner">
                <div class="row align-items-center">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-5">
                        <div class="header-logo">
                            <a href="index.html"><img src="images/logo.png" alt="Brand Logo"></a>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-9 col-7">
                        <div class="main-menu">
                            <div class="menu-toggle">
                                <span></span>
                            </div>
                            <div class="menu">
                                <div class="sidemenu-header">
                                    <div class="sidemenu-logo">
                                        <img src="images/logo.png" alt="Brand Logo">
                                    </div>
                                    <div class="sidemenu-close">
                                        <span></span>
                                    </div>
                                </div>
                                <ul>
                                    <li><a href="index.html">Home</a></li>
                                    <li class="active">
                                        <span class="opener"></span>
                                        <a href="javascript:void(0)">Shop</a>
                                        <ul class="dropdown-content">
                                            <li class="active"><a href="shop-list.html">Shop List</a></li>
                                            <li><a href="shop-detail.html">Shop Detail</a></li>
                                            <li><a href="cart.html">Cart</a></li>
                                            <li><a href="checkout.html">Checkout</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span class="opener"></span>
                                        <a href="javascript:void(0)">Pages</a>
                                        <ul class="dropdown-content">
                                            <li><a href="about.html">About Us</a></li>
                                            <li><a href="our-menu.html">Our Menu</a></li>
                                            <li><a href="our-team.html">Our Team</a></li>
                                            <li><a href="book-now.html">Book Now</a></li>
                                            <li><a href="404.html">404 Page</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span class="opener"></span>
                                        <a href="javascript:void(0)">Blog</a>
                                        <ul class="dropdown-content">
                                            <li><a href="blog-right.html">Blog Right</a></li>
                                            <li><a href="blog-left.html">Blog Left</a></li>
                                            <li><a href="blog-detail.html">Blog Detail</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="contact-us.html">Contact</a></li>
                                </ul>
                            </div>
                            <div class="icon-menu">
                                <ul>
                                    <li class="search">
                                        <a href="javascript:void(0)">
											<img src="images/search-icon.png" class="normal-icon" alt="Search Icon">
											<img src="images/search-icon-2.png" class="hover-icon" alt="Search Icon">
										</a>
                                    </li>
                                    <li class="cart-slide position-r">
                                        <a href="javascript:void(0)">
											<img src="images/cart-icon.png" class="normal-icon" alt="Cart Icon">
											<img src="images/cart-icon-2.png" class="hover-icon" alt="Cart Icon">
											<span class="cart-count">0</span>
										</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->


    <!-- Start Of Main Div -->
    <main>

        <!-- Start Of Sub Banner -->
        <section class="sub-banner bg-yellow overflow-h position-r">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-6 col-lg-6 col-md-12">
                        <div class="sub-banner-content wow fadeInLeft">
                            <h1 class="sub-banner-title">Shop List</h1>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                        </div>
                    </div>

                    <div class="col-xl-6 col-lg-6 col-md-12">
                        <div class="bread-crumb wow fadeInRight">
                            <ul>
                                <li><a href="index.html">Home</a></li>
                                <li>Shop List</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="black-jamun wow fadeInLeft animation-delay-5">
                <img src="images/black-jamun.png" alt="black-jamun">
            </div>

            <div class="onion-img wow fadeInUp animation-delay-6">
                <img src="images/onion.png" alt="onion">
            </div>

            <div class="tamato-img wow fadeInUp animation-delay-7">
                <img src="images/tamato.png" alt="tamato">
            </div>

            <div class="leaf-img wow fadeInRight animation-delay-8">
                <img src="images/banner-leaf.png" alt="banner-leaf">
            </div>
        </section>
        <!-- End Of Sub Banner -->


        <!-- Start Of Shop List -->
        <section class="shop-list ptb-150 overflow-h">
            <div class="container">
                <div class="shop-filter">
                    <div class="row align-items-center">
                        <div class="col-xl-4 col-lg-4 col-md-4">
                            <div class="filter-btn wow fadeInLeft">
                                <a href="javascript:void(0)" class="btn-ct btn-small"><img src="images/filter.png" alt="Cart Icon"> Filter</a>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8 col-md-8">
                            <div class="sorting wow fadeInRight">
                                <span class="results">Showing all 9 results</span>
                                <div class="fillter-dropdown">
                                    <select class="form-control">
										<option>Default Sorting</option>
										<option>A - Z</option>
										<option>Z - A</option>
									</select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tab-panel active">
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="menu-item-box wow fadeInUp">
                                <div class="menu-item-img">
                                    <a href="shop-detail.html"><img src="images/item-1.jpg" alt="item-1"></a>
                                </div>
                                <div class="menu-item-info">
                                    <div class="menu-item-head">
                                        <div class="menu-item-title">
                                            <h5><a href="shop-detail.html">Shrimp foods</a></h5>
                                        </div>
                                        <div class="menu-item-price">
                                            <span>$35.00</span>
                                        </div>
                                    </div>
                                    <div class="item-rating">
                                        <ul>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <div class="menu-item-des">
                                        <p>All the Lorem Ipsum generators on to Internet tend to repeat </p>
                                    </div>
                                    <div class="menu-item-order">
                                        <a href="shop-detail.html" class="btn-ct btn-small"><img src="images/cart-icon-white.png" alt="Cart Icon"> Order Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="menu-item-box wow fadeInUp">
                                <div class="menu-item-img">
                                    <a href="shop-detail.html"><img src="images/item-2.jpg" alt="item-2"></a>
                                </div>
                                <div class="menu-item-info">
                                    <div class="menu-item-head">
                                        <div class="menu-item-title">
                                            <h5><a href="shop-detail.html">French mayos</a></h5>
                                        </div>
                                        <div class="menu-item-price">
                                            <span>$65.00</span>
                                        </div>
                                    </div>
                                    <div class="item-rating">
                                        <ul>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <div class="menu-item-des">
                                        <p>All the Lorem Ipsum generators on to Internet tend to repeat </p>
                                    </div>
                                    <div class="menu-item-order">
                                        <a href="shop-detail.html" class="btn-ct btn-small"><img src="images/cart-icon-white.png" alt="Cart Icon"> Order Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="menu-item-box wow fadeInUp">
                                <div class="menu-item-img">
                                    <a href="shop-detail.html"><img src="images/item-3.jpg" alt="item-3"></a>
                                </div>
                                <div class="menu-item-info">
                                    <div class="menu-item-head">
                                        <div class="menu-item-title">
                                            <h5><a href="shop-detail.html">Cheese pizza</a></h5>
                                        </div>
                                        <div class="menu-item-price">
                                            <span>$45.00</span>
                                        </div>
                                    </div>
                                    <div class="item-rating">
                                        <ul>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <div class="menu-item-des">
                                        <p>All the Lorem Ipsum generators on to Internet tend to repeat </p>
                                    </div>
                                    <div class="menu-item-order">
                                        <a href="shop-detail.html" class="btn-ct btn-small"><img src="images/cart-icon-white.png" alt="Cart Icon"> Order Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="menu-item-box wow fadeInUp">
                                <div class="menu-item-img">
                                    <a href="shop-detail.html"><img src="images/item-4.jpg" alt="item-4"></a>
                                </div>
                                <div class="menu-item-info">
                                    <div class="menu-item-head">
                                        <div class="menu-item-title">
                                            <h5><a href="shop-detail.html">Russian rolls</a></h5>
                                        </div>
                                        <div class="menu-item-price">
                                            <span>$25.00</span>
                                        </div>
                                    </div>
                                    <div class="item-rating">
                                        <ul>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <div class="menu-item-des">
                                        <p>All the Lorem Ipsum generators on to Internet tend to repeat </p>
                                    </div>
                                    <div class="menu-item-order">
                                        <a href="shop-detail.html" class="btn-ct btn-small"><img src="images/cart-icon-white.png" alt="Cart Icon"> Order Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="menu-item-box wow fadeInUp">
                                <div class="menu-item-img">
                                    <a href="shop-detail.html"><img src="images/item-5.jpg" alt="item-5"></a>
                                </div>
                                <div class="menu-item-info">
                                    <div class="menu-item-head">
                                        <div class="menu-item-title">
                                            <h5><a href="shop-detail.html">Seafood burger</a></h5>
                                        </div>
                                        <div class="menu-item-price">
                                            <span>$75.00</span>
                                        </div>
                                    </div>
                                    <div class="item-rating">
                                        <ul>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <div class="menu-item-des">
                                        <p>All the Lorem Ipsum generators on to Internet tend to repeat </p>
                                    </div>
                                    <div class="menu-item-order">
                                        <a href="shop-detail.html" class="btn-ct btn-small"><img src="images/cart-icon-white.png" alt="Cart Icon"> Order Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="menu-item-box wow fadeInUp">
                                <div class="menu-item-img">
                                    <a href="shop-detail.html"><img src="images/item-6.jpg" alt="item-6"></a>
                                </div>
                                <div class="menu-item-info">
                                    <div class="menu-item-head">
                                        <div class="menu-item-title">
                                            <h5><a href="shop-detail.html">Sandwich soup</a></h5>
                                        </div>
                                        <div class="menu-item-price">
                                            <span>$55.00</span>
                                        </div>
                                    </div>
                                    <div class="item-rating">
                                        <ul>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        </ul>
                                    </div>
                                    <div class="menu-item-des">
                                        <p>All the Lorem Ipsum generators on to Internet tend to repeat </p>
                                    </div>
                                    <div class="menu-item-order">
                                        <a href="shop-detail.html" class="btn-ct btn-small"><img src="images/cart-icon-white.png" alt="Cart Icon"> Order Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="custom-pagination text-center pt-50 wow fadeInUp">
                    <ul>
                        <li><a href="#" class="active">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- End Of Shop List -->


    </main>
    <!-- End Of Main Div -->


    <!-- Start Of Footer -->
    <footer>
        <div class="footer ptb-100 bg-yellow position-r overflow-h">
            <div class="footer-pattern-1 wow fadeInLeft animation-delay-5">
                <img src="images/logo.png" alt="logo">
            </div>
            <div class="footer-pattern-2 wow fadeInRight animation-delay-5">
                <img src="images/footer-pattern.png" alt="footer-pattern">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-6 col-md-6 footer-box wow fadeInUp">
                        <h6 class="footer-title text-uppercase">Information</h6>
                        <ul class="footer-menu">
                            <li><a href="index.html">Home</a></li>
                            <li><a href="blog-left.html">Blog</a></li>
                            <li><a href="about.html">About Us</a></li>
                            <li><a href="our-menu.html">Menu</a></li>
                            <li><a href="contact-us.html">Contact Us</a></li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-6 footer-box wow fadeInUp">
                        <h6 class="footer-title text-uppercase">Top Items</h6>
                        <ul class="footer-menu">
                            <li><a href="#">Pepperoni</a></li>
                            <li><a href="#">Swiss Mushroom</a></li>
                            <li><a href="#">Barbeque Chicken</a></li>
                            <li><a href="#">Vegetarian</a></li>
                            <li><a href="#">Ham & Cheese</a></li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-6 footer-box wow fadeInUp">
                        <h6 class="footer-title text-uppercase">Others</h6>
                        <ul class="footer-menu">
                            <li><a href="checkout.html">Checkout</a></li>
                            <li><a href="cart.html">Cart</a></li>
                            <li><a href="#">Product</a></li>
                            <li><a href="#">Locations</a></li>
                            <li><a href="#">Legal</a></li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-6 footer-box wow fadeInUp">
                        <h6 class="footer-title text-uppercase">Social Media</h6>
                        <ul class="footer-social">
                            <li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="#" class="pinterest"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                            <li><a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li><a href="#" class="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                        </ul>
                        <div class="footer-offers-text">
                            <p>Signup and get exclusive offers and coupon codes</p>
                        </div>
                        <div class="footer-sign-up">
                            <a href="#" class="btn-ct btn-small">Sign Up</a>
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 terms-menu">
                        <div class="row align-items-center">
                            <div class="col-xl-8 col-lg-9 col-md-12 wow fadeInLeft">
                                <ul class="policy-menu">
                                    <li><a href="#">Privacy Policy</a></li>
                                    <li><a href="#">Refund Policy</a></li>
                                    <li><a href="#">Cookie Policy</a></li>
                                    <li><a href="#">Terms & Conditions</a></li>
                                </ul>
                            </div>
                            <div class="col-xl-4 col-lg-3 col-md-12 wow fadeInRight">
                                <ul class="app-list">
                                    <li><a href="#"><img src="images/google-play.png" alt="Google Play"></a></li>
                                    <li><a href="#"><img src="images/app-stor.png" alt="App Stor"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <div class="text-center">
                    <p>&#169; 2023 Pizzon. All Rights Reserved by <a href="#">Templatescoder</a></p>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Of Footer -->


    <!-- Start Of Search Popup -->
    <div class="search-popup">
        <div class="search-overlay"></div>
        <div class="search-form">
            <button class="close"></button>
            <form>
                <input type="text" name="search" placeholder="What are you looking for?" class="search-input">
                <button type="submit"><img src="images/search-icon-white.png" alt="Search Icon"></button>
            </form>
        </div>
    </div>
    <!-- End Of Search Popup -->


    <!-- Start Of Cart Drawer -->
    <div class="cart-drawer">
        <div class="bg-overlay"></div>
        <div class="drawer-content">
            <div class="w-100">
                <div class="cart-header">
                    <h6 class="title text-uppercase">SHOPPING CART</h6>
                    <button class="close"></button>
                </div>
                <div class="cart-list">
                    <div class="cart-list-inner">
                        <div class="cart-item">
                            <div class="item-image">
                                <a href="shop-detail.html"><img src="images/pizza-1.png" alt="Item Image"></a>
                            </div>
                            <div class="item-detl">
                                <div class="item-name">
                                    <a href="shop-detail.html">Shrimp pizza</a>
                                    <a class="item-remove" href="#"><img src="images/delete.png" alt="delete"></a>
                                </div>
                                <div class="item-price">
                                    <span>$35.00</span>
                                </div>
                                <div class="quantity-editer">
                                    <div class="quantity">
                                        <button type="button" class="sub minus">-</button>
                                        <input class="count" name="quantity" type="number" value="1" min="1" max="10">
                                        <button type="button" class="add plus">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cart-item">
                            <div class="item-image">
                                <a href="shop-detail.html"><img src="images/pizza-2.png" alt="Item Image"></a>
                            </div>
                            <div class="item-detl">
                                <div class="item-name">
                                    <a href="shop-detail.html">Seafood pizza</a>
                                    <a class="item-remove" href="#"><img src="images/delete.png" alt="delete"></a>
                                </div>
                                <div class="item-price">
                                    <span>$65.00</span>
                                </div>
                                <div class="quantity-editer">
                                    <div class="quantity">
                                        <button type="button" class="sub minus">-</button>
                                        <input class="count" name="quantity" type="number" value="1" min="1" max="10">
                                        <button type="button" class="add plus">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cart-item">
                            <div class="item-image">
                                <a href="shop-detail.html"><img src="images/pizza-3.png" alt="Item Image"></a>
                            </div>
                            <div class="item-detl">
                                <div class="item-name">
                                    <a class="item-title" href="shop-detail.html">Cheese pizza</a>
                                    <a class="item-remove" href="#"><img src="images/delete.png" alt="delete"></a>
                                </div>
                                <div class="item-price">
                                    <span>$45.00</span>
                                </div>
                                <div class="quantity-editer">
                                    <div class="quantity">
                                        <button type="button" class="sub minus">-</button>
                                        <input class="count" name="quantity" type="number" value="1" min="1" max="10">
                                        <button type="button" class="add plus">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cart-footer">
                <div class="sub-total">
                    <strong>Subtotal:</strong> <span class="sprice">$66.70</span>
                </div>
                <div class="cart-footer-des">
                    <p>Taxes and shipping calculated at checkout</p>
                </div>
                <div class="cart-button">
                    <ul>
                        <li><a href="cart.html" class="btn-ct btn-small">View Cart</a></li>
                        <li><a href="checkout.html" class="btn-ct btn-small subtotal">Checkout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Of Cart Drawer -->


    <!-- Start Of Shop Sidebar -->
    <div class="shop-sidebar">
        <div class="bg-overlay"></div>
        <div class="shop-content">
            <div class="shop-header">
                <button class="close"></button>
            </div>
            <div class="shop-filter mb-50">
                <h2 class="shop-title">Filter By Price</h2>
                <div class="range-slider">
                    <input class="range-slider-range" type="range" value="90" min="40" max="200">
                    <div class="price-change-flt">
                        <div class="range-label">Price :</div>
                        <div class="range-start">$40 - $</div>
                        <span class="range-slider-value">90</span>
                    </div>
                </div>
                <div class="price-filter-btn">
                    <button class="btn-ct btn-small">Filter</button>
                </div>
            </div>
            <div class="top-products mb-50">
                <h2 class="shop-title">Top Products</h2>
                <div class="product-box">
                    <div class="product-img">
                        <a href="shop-detail.html"><img src="images/pizza-1.png" alt="Item Image"></a>
                    </div>
                    <div class="product-detail">
                        <a href="shop-detail.html" class="pro-title">Shrimp pizza</a>
                        <span class="price">$35.00</span>
                    </div>
                </div>
                <div class="product-box">
                    <div class="product-img">
                        <a href="shop-detail.html"><img src="images/pizza-2.png" alt="Item Image"></a>
                    </div>
                    <div class="product-detail">
                        <a href="shop-detail.html" class="pro-title">Seafood pizza</a>
                        <span class="price">$65.00</span>
                    </div>
                </div>
                <div class="product-box">
                    <div class="product-img">
                        <a href="shop-detail.html"><img src="images/pizza-3.png" alt="Item Image"></a>
                    </div>
                    <div class="product-detail">
                        <a href="shop-detail.html" class="pro-title">Cheese pizza</a>
                        <span class="price">$75.00</span>
                    </div>
                </div>
            </div>
            <div class="blog-tags mb-50">
                <h2 class="shop-title">Tags Cloud</h2>
                <ul>
                    <li><a href="javascript:void(0)">Restaurent</a></li>
                    <li><a href="javascript:void(0)">Seafoods</a></li>
                    <li><a href="javascript:void(0)">Burger</a></li>
                    <li><a href="javascript:void(0)">Pizza</a></li>
                    <li><a href="javascript:void(0)">Bread</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Of Shop Sidebar -->


    <!-- Start Of Js -->
    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animation.js"></script>
    <script src="js/pizzon.js"></script>
</body>

</html>