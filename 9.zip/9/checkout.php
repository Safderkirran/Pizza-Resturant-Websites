<?php

session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions.php");
include("includes/main.php");

?>


  <!-- MAIN -->
  <main>
    <!-- HERO -->
    <section class="sub-banner bg-yellow overflow-h position-r">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-xl-6 col-lg-6 col-md-12">
        <div class="sub-banner-content wow fadeInLeft">
          <h1 class="sub-banner-title">Checkout</h1>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
        </div>
      </div>

      <div class="col-xl-6 col-lg-6 col-md-12">
        <div class="bread-crumb wow fadeInRight">
          <ul>
            <li><a href="index.html">Home</a></li>
            <li>Checkout</li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <div class="black-jamun wow fadeInLeft animation-delay-5">
    <img src="./m/images/black-jamun.png" alt="black-jamun">
  </div>

  <div class="onion-img wow fadeInUp animation-delay-6">
    <img src="./m/images/onion.png" alt="onion">
  </div>

  <div class="tamato-img wow fadeInUp animation-delay-7">
    <img src="./m/images/tamato.png" alt="tamato">
  </div>

  <div class="leaf-img wow fadeInRight animation-delay-8">
    <img src="./admin_area/product_images/book-leaf.png" alt="banner-leaf">
  </div>
</section>



<div id="content" ><!-- content Starts -->
<div class="container" ><!-- container Starts -->




<div class="col-md-12" ><!-- col-md-12 Starts -->

<?php

if(!isset($_SESSION['customer_email'])){

include("customer/customer_login.php");


}else{

include("payment_options.php");

}



?>


</div><!-- col-md-12 Ends -->


</div><!-- container Ends -->
</div><!-- content Ends -->





<script src="js/jquery.min.js"> </script>

<script src="js/bootstrap.min.js"></script>

</body>
</html>
